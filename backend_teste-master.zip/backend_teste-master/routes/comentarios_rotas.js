const express = require('express');
const router = express.Router();
const comentariosPublicacoesController = require('../controlers/comentarios_funcoes'); // Verifique e ajuste o caminho para o controlador
const authenticateJWT = require('../middlewares/authenticateJWT'); 

// Listar todos os comentários de uma publicação específica
router.get('/todospubcomentarios/:publicacao_id', authenticateJWT, comentariosPublicacoesController.listarComentariosPorPublicacao);

// Criar um novo comentário em uma publicação
router.post('/criarpubcomentario', authenticateJWT, comentariosPublicacoesController.create);

// Obter detalhes de um comentário específico
router.get('/detalhespubcomentario/:id', authenticateJWT, comentariosPublicacoesController.detail);

// Atualizar um comentário em uma publicação
router.put('/atualizarpubcomentario/:id', authenticateJWT, comentariosPublicacoesController.update);

// Excluir um comentário em uma publicação
router.delete('/apagarpubcomentario/:id', authenticateJWT, comentariosPublicacoesController.delete);

// Listar todos os comentários de publicações de um centro específico
router.get('/comentariosdepubde1centro/:centro_id', authenticateJWT, comentariosPublicacoesController.listarComentariosPorCentro);

// Listar todos os comentários de publicações de um centro específico e um autor específico
router.get('/comentariospubdeambos/centro/:centro_id/autor/:user_id', authenticateJWT, comentariosPublicacoesController.listarComentariosPorCentroEAutor);

// Obter média das avaliações e número total de comentários de uma publicação específica
router.get('/mediapubavaliacoes/:publicacao_id', authenticateJWT, comentariosPublicacoesController.obterMediaAvaliacoes);

module.exports = router;
