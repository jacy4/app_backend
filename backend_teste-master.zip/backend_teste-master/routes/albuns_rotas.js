const express = require('express');
const router = express.Router();
const albumController = require('../controlers/albuns_funcoes'); // Verifique se o caminho está correto
const authenticateJWT = require('../middlewares/authenticateJWT'); // Middleware para autenticação JWT, caso você tenha um

// Criar um novo álbum
router.post('/create', authenticateJWT, albumController.create);

router.get('/partilhasde1centro/:centroId', authenticateJWT, albumController.listarpartilhasporcentroAPP);
// Listar todos os álbuns de um centro
router.get('/list/:centroId', authenticateJWT, albumController.list);

// Listar todos os álbuns de uma área específica
router.get('/listByArea/:areaId', authenticateJWT, albumController.listByArea);


// Obter detalhes de um álbum específico
router.get('/detail/:id', authenticateJWT, albumController.detail);

// Atualizar um álbum
router.put('/update/:id', authenticateJWT, albumController.update);

// Excluir um álbum
router.delete('/delete/:id', authenticateJWT, albumController.delete);

module.exports = router;
