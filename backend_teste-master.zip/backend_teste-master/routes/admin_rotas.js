const express = require('express');
const adminController = require('../controlers/admin_funcoes');

const router = express.Router();

router.post('/create', adminController.create);
router.get('/listarAdmins', adminController.list);
router.get('/detalharAdmin/:id', adminController.detail);
router.put('/atualizarAdmin/:id', adminController.update);
router.delete('/deletarAdmin/:id', adminController.delete);
router.post('/login', adminController.login);

module.exports = router;
