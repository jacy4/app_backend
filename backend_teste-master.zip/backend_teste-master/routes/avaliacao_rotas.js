const express = require('express');
const router = express.Router();
const AvaliacaoController = require('../controlers/avaliacao_funcoes'); // Verifique se o caminho está correto
const authenticateJWT = require('../middlewares/authenticateJWT.js');

router.post('/create', authenticateJWT,AvaliacaoController.create);
router.get('/average/:publicacao_id', authenticateJWT,AvaliacaoController.getAverage);

module.exports = router;
