const express = require('express');
const centroController = require('../controlers/centro_funcoes.js');
const authenticateJWT = require('../middlewares/authenticateJWT.js'); // Importar o middleware de autenticação

const router = express.Router();

// Rotas para centros
router.get('/listarCentros', authenticateJWT, centroController.list);
router.post('/criarCentro', authenticateJWT, centroController.create);
router.get('/obter1Centro/:id', authenticateJWT, centroController.detail);
router.put('/atualizar1Centro/:id', authenticateJWT, centroController.update);
router.delete('/apagar1Centro/:id', authenticateJWT, centroController.delete);
router.get('/obternomecentro/:id', authenticateJWT, centroController.getCentroById);

module.exports = router;
