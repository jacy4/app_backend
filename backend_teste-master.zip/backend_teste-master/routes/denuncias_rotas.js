const express = require('express');
const router = express.Router();
const denunciaController = require('../controlers/denuncias_funcoes'); // Verifique o caminho para o controlador
const authenticateJWT = require('../middlewares/authenticateJWT.js');

// Listar denúncias por publicação
router.get('/listarDenunciasPorPublicacao/:publicacaoId', authenticateJWT, denunciaController.listarDenuncias);

// Criar uma nova denúncia
router.post('/create', authenticateJWT,denunciaController.create);

// Buscar uma denúncia por ID
router.get('/detail/:id', authenticateJWT,denunciaController.detail);

// Atualizar uma denúncia
router.put('/update/:id', authenticateJWT,denunciaController.update);

// Excluir uma denúncia
router.delete('/delete/:id', authenticateJWT,denunciaController.delete);

module.exports = router;
