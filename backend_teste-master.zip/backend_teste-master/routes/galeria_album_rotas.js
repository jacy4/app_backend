const express = require('express');
const galeriaAlbumController = require('../controlers/galeria_album_funcoes');
const router = express.Router();
const authenticateJWT = require('../middlewares/authenticateJWT');

// Adicionar uma imagem a um álbum
router.post('/adicionar_imagem', authenticateJWT, galeriaAlbumController.create);

router.post('/criar_partilhaAPP', authenticateJWT, galeriaAlbumController.createPartilhaAPP);
// Adicionar várias imagens a um álbum
router.post('/criar_varias_imagens', authenticateJWT, galeriaAlbumController.criarVarias);

// Listar todas as imagens de um álbum específico
router.get('/listar_todas_imagens/:album_id', authenticateJWT, galeriaAlbumController.listarImagensPorAlbum);

// Listar todas as imagens de um álbum específico com mais detalhes
router.get('/listar_imagens_v2/:album_id', galeriaAlbumController.listarImagensPorAlbumV2);

// Listar todas as imagens de álbuns de um centro específico
router.get('/listar_todas_imagens_de_centro/:centro_id', authenticateJWT, galeriaAlbumController.listarImagensPorCentro);

router.get('/listar_imagens_por_centro_APP/:centro_id', authenticateJWT, galeriaAlbumController.listarImagensPorCentroAPP);
// Listar todas as imagens de álbuns de um centro e um autor específico
router.get('/listar_imagens_por_centro_autor/centro/:centro_id/autor/:autor_id', authenticateJWT, galeriaAlbumController.listarImagensPorCentroEAutor);

// Deletar uma imagem específica
router.delete('/apagar_imagem/:id', authenticateJWT, galeriaAlbumController.delete);

// Atualizar uma imagem específica
router.put('/atualizar_imagem/:id', authenticateJWT, galeriaAlbumController.update);

// Remover todas as imagens de um álbum específico
router.delete('/remover_todas_imagens/:album_id', authenticateJWT, galeriaAlbumController.removerTodasImagensDoAlbum);

router.get('/contar/:areaId', galeriaAlbumController.countByArea);

module.exports = router;
