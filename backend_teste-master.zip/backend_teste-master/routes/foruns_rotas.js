const express = require('express');
const router = express.Router();
const forumController = require('../controlers/forum_funcoes'); // Verifique se o caminho está correto
const authenticateJWT = require('../middlewares/authenticateJWT'); // Middleware para autenticação JWT, caso você tenha um

// Criar um novo fórum
router.post('/create', authenticateJWT, forumController.create);

// Listar todos os fóruns
router.get('/list/:areaId', authenticateJWT, forumController.list);

router.get('/listarporcentroAPP/:centroId',authenticateJWT, forumController.listByCentroAPP);

// Obter detalhes de um fórum específico
router.get('/detail/:id', authenticateJWT, forumController.detail);

// Atualizar um fórum
router.put('/update/:id', authenticateJWT, forumController.update);

// Excluir um fórum
router.delete('/delete/:id', authenticateJWT, forumController.delete);

module.exports = router;
