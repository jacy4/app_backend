const express = require('express');
const router = express.Router();
const denunciasEventosController = require('../controlers/denuncias_de_eventos_funcoes');

// Rota para criar uma nova denúncia sobre um evento
router.post('/criar', denunciasEventosController.create);

// Rota para listar todas as denúncias de um evento específico
router.get('/listar/:id_evento_denunciado', denunciasEventosController.listarDenunciasDeEvento);

// Rota para deletar uma denúncia específica
router.delete('/deletar/:id', denunciasEventosController.deleteDenuncia);

// Rota para deletar todas as denúncias de um evento específico
router.delete('/deletar_todas/:id_evento_denunciado', denunciasEventosController.deleteAllDenunciasDeEvento);

module.exports = router;
