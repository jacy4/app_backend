const express = require('express');
const router = express.Router();
const denunciaMensagemForumController = require('../controlers/denuncias_mensagens_forum_funcoes.js'); // Verifique o caminho para o controlador
const authenticateJWT = require('../middlewares/authenticateJWT.js');

// Criar uma nova denúncia
router.post('/create', authenticateJWT, denunciaMensagemForumController.create);

// Listar denúncias por mensagem de fórum
router.get('/mensagem/:mensagemForumId', authenticateJWT, denunciaMensagemForumController.listarDenunciasPorMensagem);

// Listar denúncias por fórum
router.get('/forum/:forumId', authenticateJWT, denunciaMensagemForumController.listarDenunciasPorForum);

// Buscar uma denúncia por ID
router.get('/detail/:id', authenticateJWT, denunciaMensagemForumController.detail);

// Atualizar uma denúncia
router.put('/update/:id', authenticateJWT, denunciaMensagemForumController.update);

// Excluir uma denúncia
router.delete('/delete/:id', authenticateJWT, denunciaMensagemForumController.delete);

module.exports = router;
