const express = require('express');
const router = express.Router();
const denunciasComentariosAlbunsController = require('../controlers/denuncias_comentarios_de_albuns_funcoes'); 
const authenticateJWT = require('../middlewares/authenticateJWT'); 

// Criar uma nova denúncia de um comentário em álbum
router.post('/criarDenuncia', authenticateJWT, denunciasComentariosAlbunsController.create);

// Listar todas as denúncias de um álbum específico
router.get('/denunciasPorAlbum/:id_album', authenticateJWT, denunciasComentariosAlbunsController.listarDenunciasDeAlbum);

// Excluir uma denúncia específica
router.delete('/apagarDenuncia/:id', authenticateJWT, denunciasComentariosAlbunsController.deleteDenuncia);

// Excluir todas as denúncias de um álbum específico
router.delete('/apagarTodasDenuncias/:id_album', authenticateJWT, denunciasComentariosAlbunsController.deleteAllDenunciasDeAlbum);

// Atualizar uma denúncia específica
router.put('/update/:id', authenticateJWT, denunciasComentariosAlbunsController.update);

module.exports = router;
