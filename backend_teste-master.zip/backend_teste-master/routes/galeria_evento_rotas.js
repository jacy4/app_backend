const express = require('express');
const galeriaEventoController=require('../controlers/galeria_evento_funcoes');
const router = express.Router();
const authenticateJWT = require('../middlewares/authenticateJWT'); 

router.post('/adiconar_imagem', authenticateJWT,galeriaEventoController.create);
router.post('/criarvarias', galeriaEventoController.criarVarias);
router.get('/listar_todas_imagens/:evento_id', authenticateJWT,galeriaEventoController.listarImagensPorEvento);
router.get('/listar_imagens_v2/:evento_id', galeriaEventoController.listarImagensPorEventoV2);
router.get('/listar_todas_imagens_de_1_centro/:centro_id', authenticateJWT,galeriaEventoController.listarImagensPorCentro);
router.get('/listar_toas_imagens_ambos/centro/:centro_id/autor/:autor_id', authenticateJWT, galeriaEventoController.listarImagensPorCentroEAutor);

router.delete('/apagar_uma_imagem/:id', authenticateJWT,galeriaEventoController.delete);
router.put('/atualizarimagem/:id', authenticateJWT,galeriaEventoController.update);
router.delete('/remover_todas_as_imagens/:evento_id',authenticateJWT, galeriaEventoController.removerTodasImagensDoEvento);

module.exports = router;