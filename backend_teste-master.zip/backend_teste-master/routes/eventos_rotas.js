const express = require('express');
const router = express.Router();
const eventoController = require('../controlers/eventos_funcoes');
const authenticateJWT = require('../middlewares/authenticateJWT.js');

router.get('/listarEventos/:areaId', authenticateJWT,eventoController.list);
router.get('/calendar_list', authenticateJWT,eventoController.list_calendar);
router.post('/create', authenticateJWT,eventoController.create);
router.get('/detail/:id', authenticateJWT,eventoController.detail);  
router.put('/update/:id', authenticateJWT,eventoController.update);
router.get('/eventosdousuario/:usuarioId', authenticateJWT,eventoController.getEventosPorUsuario);
router.get('/listarEventosAPP/:centroId', authenticateJWT,eventoController.listAPP);
router.delete('/delete/:id', authenticateJWT,eventoController.delete);
router.put('/updateVisibility/:id', authenticateJWT,eventoController.updateVisibility);
router.get('/modelcount', authenticateJWT,eventoController.getModelCounts);
router.get('/monthlycounts', authenticateJWT,eventoController.getMonthlyEventCounts);
///comentatio
router.put('/aprovarevento_admin/:id', authenticateJWT, eventoController.aprovarEventoPeloAdmin);
router.get('/contar/:areaId', eventoController.countAll);
router.get('/contar/poraprovar/:areaId', eventoController.countPendingApprovalByArea);

router.get('/commaiscomentarios/:areaId', eventoController.getEventoComMaisComentariosPorArea);

module.exports = router;
