const express = require('express');
const router = express.Router();
const comentariosEventosController = require('../controlers/comentarios_eventos_funcoes'); // Verifique e ajuste o caminho para o controlador
const authenticateJWT = require('../middlewares/authenticateJWT'); 

// Listar todos os comentários de um evento específico
router.get('/todoscomentarios/:evento_id', authenticateJWT, comentariosEventosController.listarComentariosPorEvento);

// Criar um novo comentário em um evento
router.post('/criarcomentario', authenticateJWT, comentariosEventosController.create);

// Obter detalhes de um comentário específico
router.get('/detalhescomentario/:id', authenticateJWT, comentariosEventosController.detail);

// Atualizar um comentário em um evento
router.put('/atualizarcomentario/:id', authenticateJWT, comentariosEventosController.update);

// Excluir um comentário em um evento
router.delete('/apagarcomentario/:id', authenticateJWT, comentariosEventosController.delete);

router.get('/comentariosdeeventosde1centro/:centro_id', authenticateJWT, comentariosEventosController.listarComentariosPorCentro);

router.get('/comentariosdeambos/centro/:centro_id/autor/:autor_id', authenticateJWT, comentariosEventosController.listarComentariosPorCentroEAutor);

// Obter média das avaliações e número total de comentários de um evento específico
router.get('/mediaavaliacoes/:evento_id', authenticateJWT, comentariosEventosController.obterMediaAvaliacoes);


module.exports = router;
