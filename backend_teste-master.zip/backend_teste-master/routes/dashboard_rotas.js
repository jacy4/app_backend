const express = require('express');
const dashboardController = require('../controlers/dashboard');
const authenticateJWT = require('../middlewares/authenticateJWT.js');

const router = express.Router();

router.get('/modelcount', authenticateJWT,dashboardController.getModelCounts);

module.exports = router;