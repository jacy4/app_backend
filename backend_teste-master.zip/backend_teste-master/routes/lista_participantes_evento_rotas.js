const express = require('express');
const router = express.Router();
const participantesEventosController = require('../controlers/lista_participantes_evento_funcoes'); 
const authenticateJWT = require('../middlewares/authenticateJWT'); 

router.get('/listartudo',authenticateJWT,participantesEventosController.listarTodosParticipantes);
router.get('/listartudode1centro/:centro_id',authenticateJWT,participantesEventosController.listarParticipantesPorCentro);
router.get('/listarparticipanteambos/:centro_id/autor/:autor_id',authenticateJWT, participantesEventosController.listarParticipantesPorCentroEAutor);
router.post('/adicionar_participante', authenticateJWT, participantesEventosController.adicionarParticipante);
router.delete('/remover_participante/:usuario_id/:evento_id', authenticateJWT, participantesEventosController.removerParticipante);
router.delete('/remover_todos_participantes/:evento_id', authenticateJWT, participantesEventosController.removerTodosParticipantes);
router.get('/evento/:evento_id', participantesEventosController.listarParticipantesPorEvento);

module.exports = router;
