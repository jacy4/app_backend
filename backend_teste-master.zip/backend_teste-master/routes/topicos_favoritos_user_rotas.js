const express = require('express');
const router = express.Router();
const topicosFavoritosController = require('../controlers/topicos_favoritos_user_funcoes');
const authenticateJWT = require('../middlewares/authenticateJWT');

router.post('/topicos_favoritos/create', authenticateJWT, topicosFavoritosController.create);

router.get('/topicos_favoritos/:usuario_id', authenticateJWT, topicosFavoritosController.list);
router.get('/topicos_favoritos_todos',authenticateJWT ,topicosFavoritosController.listAll);
router.delete('/topicos_favoritos/delete', authenticateJWT, topicosFavoritosController.delete);

module.exports = router;
