const express = require('express');
const router = express.Router();
const comentariosAlbunsController = require('../controlers/comentarios_albuns_funcoes'); // Verifique e ajuste o caminho para o controlador
const authenticateJWT = require('../middlewares/authenticateJWT'); 

// Listar todos os comentários de um álbum específico
router.get('/todoscomentarios/:album_id', authenticateJWT, comentariosAlbunsController.listarComentariosPorAlbum);
router.get('/todoscomentariosAPP/:id_galeria', authenticateJWT, comentariosAlbunsController.listarComentariosPorGaleriaAPP);
// Criar um novo comentário em um álbum
router.post('/criarcomentario', authenticateJWT, comentariosAlbunsController.create);
router.post('/criarcomentarioAPP', authenticateJWT, comentariosAlbunsController.createComentarioGaleriaAPP);
// Obter detalhes de um comentário específico
router.get('/detalhescomentario/:id', authenticateJWT, comentariosAlbunsController.detail);

// Atualizar um comentário em um álbum
router.put('/atualizarcomentario/:id', authenticateJWT, comentariosAlbunsController.update);

// Excluir um comentário em um álbum
router.delete('/apagarcomentario/:id', authenticateJWT, comentariosAlbunsController.delete);

// Listar todos os comentários de álbuns de um centro específico
router.get('/comentariosdealbunsde1centro/:centro_id', authenticateJWT, comentariosAlbunsController.listarComentariosPorCentro);

// Listar todos os comentários de álbuns de um centro e autor específicos
router.get('/comentariosdeambos/centro/:centro_id/autor/:autor_id', authenticateJWT, comentariosAlbunsController.listarComentariosPorCentroEAutor);

// Obter média das avaliações e número total de comentários de um álbum específico
router.get('/mediaavaliacoes/:album_id', authenticateJWT, comentariosAlbunsController.obterMediaAvaliacoes);

module.exports = router;
