const express = require('express');
const router = express.Router();
const likesComentariosAlbunsController = require('../controlers/likes_comentarios_albuns_funcoes');
const authenticateJWT = require('../middlewares/authenticateJWT');  // Middleware de autenticação

// Rota para criar um like em um comentário de um álbum
router.post('/like', authenticateJWT, likesComentariosAlbunsController.create);

// Rota para remover um like de um comentário de um álbum
router.delete('/unlike', authenticateJWT, likesComentariosAlbunsController.delete);

// Rota para verificar se um usuário curtiu um comentário de um álbum
router.get('/check', authenticateJWT, likesComentariosAlbunsController.checkLike);

module.exports = router;
