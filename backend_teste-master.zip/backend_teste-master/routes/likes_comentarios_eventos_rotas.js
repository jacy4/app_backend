const express = require('express');
const router = express.Router();
const likesComentariosEventosController = require('../controlers/likes_comentarios_eventos_funcoes');
const authenticateJWT = require('../middlewares/authenticateJWT');  // Middleware de autenticação

// Rota para criar um like em um comentário de um evento
router.post('/like', authenticateJWT, likesComentariosEventosController.create);

// Rota para remover um like de um comentário de um evento
router.delete('/unlike', authenticateJWT, likesComentariosEventosController.delete);

// Rota para verificar se um usuário curtiu um comentário de um evento
router.get('/check', authenticateJWT, likesComentariosEventosController.checkLike);

module.exports = router;
