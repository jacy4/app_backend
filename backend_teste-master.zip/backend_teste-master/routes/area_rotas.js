const express = require('express');
const areaController = require('../controlers/area_funcoes');
const router = express.Router();
const authenticateJWT = require('../middlewares/authenticateJWT.js');

// Rotas para operações de CRUD
router.get('/listarAreas', authenticateJWT,areaController.list);
router.post('/createArea', authenticateJWT,areaController.create);
router.get('/detalheArea/:id', authenticateJWT,areaController.detail);
router.put('/atualizarArea/:id', authenticateJWT,areaController.update);
router.delete('/apagarArea/:id', authenticateJWT,areaController.delete);

module.exports = router;
