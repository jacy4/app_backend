const express = require('express');
const router = express.Router();
const likesComentariosPublicacoesController = require('../controlers/likes_comentarios_publicacoes_funcoes');
const authenticateJWT = require('../middlewares/authenticateJWT');  // Middleware de autenticação

// Rota para criar um like em um comentário de uma publicação
router.post('/like', authenticateJWT, likesComentariosPublicacoesController.create);

// Rota para remover um like de um comentário de uma publicação
router.delete('/unlike', authenticateJWT, likesComentariosPublicacoesController.delete);

// Rota para verificar se um usuário curtiu um comentário de uma publicação
router.get('/check', authenticateJWT, likesComentariosPublicacoesController.checkLike);

module.exports = router;
