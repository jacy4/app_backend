const express = require('express');
const router = express.Router();
const notificacaoController = require('../controlers/notificacoes_funcoes');
const authenticateJWT = require('../middlewares/authenticateJWT.js');

router.post('/create', authenticateJWT,notificacaoController.create);
router.get('/usuario/:usuarioId', authenticateJWT,notificacaoController.listarNotificacoes);
router.put('/marcar_como_lida/:id', authenticateJWT,notificacaoController.marcarComoLida);
router.delete('/delete/:id', authenticateJWT,notificacaoController.delete);

module.exports = router;
