const express = require('express');
const usuarioController = require('../controlers/user_funcoes');
const authenticateJWT = require('../middlewares/authenticateJWT.js');

const router = express.Router();

router.post('/create', authenticateJWT,usuarioController.create);
router.get('/listarUsers', authenticateJWT,usuarioController.list);
router.get('/listarallUsers', authenticateJWT,usuarioController.listall);
router.get('/verificar_email', authenticateJWT,usuarioController.checkEmailAndPassword);
router.get('/detalhes_user/:id', authenticateJWT,usuarioController.detail);
router.get('/user/:id', authenticateJWT,usuarioController.getUserById); 
router.get('/user/ativar/:id', authenticateJWT,usuarioController.ativar); 
router.get('/user/desativar/:id', authenticateJWT,usuarioController.desativar); 
router.get('/verificar_email_google',authenticateJWT, usuarioController.verifyGoogleEmail);
router.put('/update/:id', authenticateJWT, usuarioController.update);


// Outras rotas conforme necessário...

module.exports = router;
