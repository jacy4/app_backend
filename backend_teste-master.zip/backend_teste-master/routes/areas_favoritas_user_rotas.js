const express = require('express');
const router = express.Router();
const authenticateJWT = require('../middlewares/authenticateJWT');
const areafavoritasuserController = require('../controlers/areas_favoritas_user_funcoes');


router.post('/add_area_favorita', authenticateJWT, areafavoritasuserController.create);


router.get('/listar_areas_favoritas/:usuario_id', authenticateJWT, areafavoritasuserController.list);

router.get('/listar_areas_favoritas_toadas', authenticateJWT, areafavoritasuserController.listAll);
router.delete('/apagar_area_favorita', authenticateJWT, areafavoritasuserController.delete);

module.exports = router;
