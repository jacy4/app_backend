const express = require('express');
const router = express.Router();
const publicacaoController = require('../controlers/publicacoes_funcoes');
const authenticateJWT = require('../middlewares/authenticateJWT.js');

router.get('/listarPublicacoes/:areaId', authenticateJWT,publicacaoController.list);
router.get('/listarPublicacoesAPP/:centroId', authenticateJWT,publicacaoController.listporcentroAPP);//DA APP
router.post('/createAPP', authenticateJWT,publicacaoController.createAPP);

router.post('/create', authenticateJWT,publicacaoController.create);
router.get('/detail/:id', authenticateJWT,publicacaoController.detail);
router.put('/update/:id', authenticateJWT,publicacaoController.update);
router.delete('/delete/:id', authenticateJWT,publicacaoController.delete);
router.put('/updateVisibility/:id', authenticateJWT,publicacaoController.updateVisibility);
router.get('/contar/:areaId', publicacaoController.countByArea);


module.exports = router;
