const express = require('express');
const router = express.Router();
const grupoController = require('../controlers/grupos_funcoes');
const authenticateJWT = require('../middlewares/authenticateJWT.js');

// Rota para listar todos os grupos para um determinado centro
router.get('/listarGrupos/:areaId', authenticateJWT, grupoController.list);

// Rota para criar um novo grupo
router.post('/create', authenticateJWT, grupoController.create);

// Rota para obter detalhes de um grupo específico
router.get('/detail/:id', authenticateJWT, grupoController.detail);

// Rota para atualizar um grupo específico
router.put('/update/:id', authenticateJWT, grupoController.update);

// Rota para deletar um grupo específico
router.delete('/delete/:id', authenticateJWT, grupoController.delete);

module.exports = router;
