const express = require('express');
const topicoController = require('../controlers/topicos_funcoes');
const router = express.Router();
const authenticateJWT = require('../middlewares/authenticateJWT.js');

// Rotas para operações de CRUD
router.get('/listarTopicos', authenticateJWT,topicoController.list);
router.post('/createTopico', authenticateJWT,topicoController.create);
router.get('/detail/:id', authenticateJWT,topicoController.detail);
router.put('/atualizar/:id', authenticateJWT,topicoController.update);
router.delete('/apagar/:id', authenticateJWT,topicoController.delete);
router.get('/topicosdeumaarea/:area_id', authenticateJWT,topicoController.listByArea);
module.exports = router;
