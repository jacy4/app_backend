const express = require('express');
const router = express.Router();
const denunciaGrupoController = require('../controlers/denuncias_grupos_funcoes.js'); // Verifique o caminho para o controlador
const authenticateJWT = require('../middlewares/authenticateJWT.js');

// Listar denúncias por grupo
router.get('/grupo/:grupoId', authenticateJWT, denunciaGrupoController.listarDenuncias);

// Criar uma nova denúncia de grupo
router.post('/create', authenticateJWT, denunciaGrupoController.create);

// Buscar uma denúncia de grupo por ID
router.get('/detail/:id', authenticateJWT, denunciaGrupoController.detail);

// Atualizar uma denúncia de grupo
router.put('/update/:id', authenticateJWT, denunciaGrupoController.update);

// Excluir uma denúncia de grupo
router.delete('/delete/:id', authenticateJWT, denunciaGrupoController.delete);

module.exports = router;
