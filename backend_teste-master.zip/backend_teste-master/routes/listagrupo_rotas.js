const express = require('express');
const router = express.Router();
const listaGrupoController = require('../controlers/listagrupo_funcoes.js');
const authenticateJWT = require('../middlewares/authenticateJWT.js');

router.get('/listarMembros/:grupo_id', authenticateJWT, listaGrupoController.listarMembrosPorGrupo);
router.post('/adicionarMembro', authenticateJWT, listaGrupoController.adicionarMembroAoGrupo);
router.delete('/removerMembro', authenticateJWT, listaGrupoController.removerMembroDoGrupo);
router.get('/listarGrupos/:usuario_id', authenticateJWT, listaGrupoController.listarGruposPorUsuario);

module.exports = router;
