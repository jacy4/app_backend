const express = require('express');
const router = express.Router();
const denunciasComentariosEventosController = require('../controlers/denuncias_comentarios_de_eventos_funcoes'); 
const authenticateJWT = require('../middlewares/authenticateJWT'); 

// Criar uma nova denúncia de um comentário
router.post('/criarDenuncia', authenticateJWT, denunciasComentariosEventosController.create);

// Listar todas as denúncias de um evento específico
router.get('/denunciasPorEvento/:id_evento', authenticateJWT, denunciasComentariosEventosController.listarDenunciasDeEvento);

// Excluir uma denúncia específica
router.delete('/apagarDenuncia/:id', authenticateJWT, denunciasComentariosEventosController.deleteDenuncia);

// Excluir todas as denúncias de um evento específico
router.delete('/apagarTodasDenuncias/:id_evento', authenticateJWT, denunciasComentariosEventosController.deleteAllDenunciasDeEvento);

router.put('/update/:id', denunciasComentariosEventosController.update);

module.exports = router;
