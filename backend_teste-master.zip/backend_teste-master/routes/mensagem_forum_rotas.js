const express = require('express');
const router = express.Router();
const mensagemForumController = require('../controlers/mensagem_forum.js'); // Certifique-se de ajustar o caminho conforme necessário
const authenticateJWT = require('../middlewares/authenticateJWT.js'); // Supondo que você esteja usando autenticação JWT

// Criar uma nova mensagem no fórum
router.post('/create', authenticateJWT, mensagemForumController.create);

// Listar todas as mensagens de um fórum específico
router.get('/forum/:forum_id', authenticateJWT, mensagemForumController.listarMensagensPorForum);

// Buscar uma mensagem específica por ID
router.get('/detail/:id', authenticateJWT, mensagemForumController.detail);

// Atualizar uma mensagem
router.put('/update/:id', authenticateJWT, mensagemForumController.update);

// Excluir uma mensagem
router.delete('/delete/:id', authenticateJWT, mensagemForumController.delete);

router.get('/contar/:areaId', mensagemForumController.countByArea);

module.exports = router;
