const express = require('express');
const router = express.Router();
const tipoEventoFuncoes = require('../controlers/tipo_de_evento');
const authenticateJWT = require('../middlewares/authenticateJWT');


router.get('/listarTipos', authenticateJWT, tipoEventoFuncoes.list);

// Criar um novo tipo de evento
router.post('/criartipoevento', authenticateJWT, tipoEventoFuncoes.create);

// Obter detalhes de um tipo de evento
router.get('/detalhestipo/:id', authenticateJWT, tipoEventoFuncoes.detail);

// Atualizar um tipo de evento
router.put('/atualizartipo/:id', authenticateJWT, tipoEventoFuncoes.update);

// Deletar um tipo de evento
router.delete('/apagartipo/:id', authenticateJWT, tipoEventoFuncoes.delete);

module.exports = router;
