const Sequelize = require('sequelize');
const sequelize = require('../database'); 
const Usuario = require('./user'); 
const Forum = require('./forum'); 

const MensagemForum = sequelize.define('mensagem_forum', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    forum_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: Forum,
            key: 'id'
        }
    },
    user_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: Usuario,
            key: 'id'
        }
    },
    texto_mensagem: {
        type: Sequelize.TEXT,
        allowNull: false
    },
    createdat: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW
    }
}, {
    tableName: 'mensagem_forum',
    timestamps: false // Se você não tem colunas de timestamp, como updatedAt
});

// Definindo as associações para facilitar os joins
MensagemForum.belongsTo(Usuario, { foreignKey: 'user_id', as: 'usuario' });
MensagemForum.belongsTo(Forum, { foreignKey: 'forum_id', as: 'forum' });

module.exports = MensagemForum;
