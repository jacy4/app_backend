const Sequelize = require('sequelize');
const sequelize = require('../database');
const Publicacao = require('./publicacoes');
const User = require('./user');

const Avaliacao = sequelize.define('avaliacao', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  publicacao_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: Publicacao,
      key: 'id'
    }
  },
  autor_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: 'id'
    }
  },
  estrelas: {
    type: Sequelize.INTEGER,
    allowNull: false,
    validate: {
      min: 1,
      max: 5
    }
  },
  createdAt: {
    type: Sequelize.DATE,
    defaultValue: Sequelize.NOW
  }
}, {
  tableName: 'avaliacoes',
  timestamps: false,
  indexes: [
    {
      unique: true,
      fields: ['publicacao_id', 'autor_id']
    }
  ]
});

Avaliacao.belongsTo(Publicacao, { foreignKey: 'publicacao_id' });
Avaliacao.belongsTo(User, { foreignKey: 'autor_id', as: 'autor' });

module.exports = Avaliacao;
