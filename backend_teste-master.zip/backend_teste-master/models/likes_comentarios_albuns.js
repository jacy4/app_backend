const Sequelize = require('sequelize');
const sequelize = require('../database');
const ComentarioAlbum = require('./comentarios_albuns');  // Certifique-se de que o modelo 'comentarios_albuns' exista
const User = require('./user');

const LikeComentarioAlbum = sequelize.define('like_comentario_album', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  comentario_album_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: ComentarioAlbum,
      key: 'id'
    }
  },
  user_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: 'id'
    }
  },
  like: {
    type: Sequelize.BOOLEAN,
    allowNull: false,
    defaultValue: true
  },
  createdat: {
    type: Sequelize.DATE,
    allowNull: false,
    defaultValue: Sequelize.NOW
  }
}, {
  tableName: 'likes_comentarios_albuns',
  timestamps: false
});

LikeComentarioAlbum.belongsTo(ComentarioAlbum, { foreignKey: 'comentario_album_id' });
LikeComentarioAlbum.belongsTo(User, { foreignKey: 'user_id' });

module.exports = LikeComentarioAlbum;
