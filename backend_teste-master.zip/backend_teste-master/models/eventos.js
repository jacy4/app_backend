const Sequelize = require('sequelize');
const sequelize = require('../database');

const Eventos = sequelize.define('evento', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  nome: {
    type: Sequelize.STRING,
    allowNull: false
  },
  descricao: {
    type: Sequelize.STRING(1000),
    allowNull: true
  },
  topico_id: {
    type: Sequelize.INTEGER,
    allowNull: false
  },
  datainicioatividade: {
    type: Sequelize.DATE,
    allowNull: true,
  },
  datafimatividade: {
    type: Sequelize.DATE,
    allowNull: true,
  },
  estado: {
    type: Sequelize.ENUM('Ativa', 'Denunciada', 'Por validar','Finalizada'),
    defaultValue: 'Ativa'
  },
  centro_id: {
    type: Sequelize.INTEGER,
    allowNull: false
  },
  autor_id: {
    type: Sequelize.INTEGER,
    allowNull: false
  },
  capa_imagem_evento: {
    type: Sequelize.STRING,
    allowNull: true
  },
  latitude: {
    type: Sequelize.FLOAT,
    allowNull: true
  },
  longitude: {
    type: Sequelize.FLOAT,
    allowNull: true
  },
  localizacao: {
    type: Sequelize.STRING,
    allowNull: true
  },
  area_id: {
    type: Sequelize.INTEGER,
    allowNull: false
  },
  tipodeevento_id: {
    type: Sequelize.INTEGER,
    allowNull: false
  }
}, {
  tableName: 'eventos',
  timestamps: true
});

module.exports = Eventos;
