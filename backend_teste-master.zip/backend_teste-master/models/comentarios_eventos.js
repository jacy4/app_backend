const Sequelize = require('sequelize');
const sequelize = require('../database');

const ComentariosEventos = sequelize.define('comentario_evento', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  user_id: {
    type: Sequelize.INTEGER,
    allowNull: false
  },
  likes: {  // Novo campo adicionado para armazenar o número de likes
    type: Sequelize.INTEGER,
    allowNull: false,
    defaultValue: 0
  },
  evento_id: {
    type: Sequelize.INTEGER,
    allowNull: false
  },
  data_comentario: {
    type: Sequelize.DATE,
    allowNull: false,
    defaultValue: Sequelize.NOW
  },
  createdat: {  // Aqui foi alterado de 'createdAt' para 'createdat'
    type: Sequelize.DATE,
    defaultValue: Sequelize.NOW
  },
  classificacao: {
    type: Sequelize.INTEGER,
  },
  texto_comentario: {
    type: Sequelize.TEXT,
    allowNull: false
  }
}, {
  tableName: 'comentarios_eventos',
  timestamps: false
});

module.exports = ComentariosEventos;
