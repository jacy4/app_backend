const Sequelize = require('sequelize');
const sequelize = require('../database');
const User = require('./user');
const Area = require('./areas'); 

const Albuns = sequelize.define('album', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  nome: {
    type: Sequelize.STRING,
    allowNull: false
  },
  area_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: Area,
      key: 'id'
    }
  },
  descricao: {
    type: Sequelize.STRING(1000),
    allowNull: true // Descrição pode ser null
  },
  capa_imagem_album: {
    type: Sequelize.STRING,
    allowNull: true // Capa da imagem pode ser null
  },
  
  estado: {
    type: Sequelize.ENUM('Ativa', 'Denunciada', 'Por validar','Finalizada'),
    defaultValue: 'Ativa'
  },
  centro_id: {
    type: Sequelize.INTEGER,
    allowNull: false // Centro é obrigatório
  },
  area_id: {
    type: Sequelize.INTEGER,
    allowNull: false // Área é obrigatória
  },
  autor_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: 'id'
    },
  },
}, {
  tableName: 'albuns', // Nome da tabela no banco de dados
  timestamps: true // Para adicionar createdAt e updatedAt
});


Albuns.belongsTo(User, { foreignKey: 'autor_id', as: 'autor' }); // Relaciona o álbum com o autor (usuário)
Albuns.belongsTo(Area, { foreignKey: 'area_id', as: 'area' });

module.exports = Albuns;
