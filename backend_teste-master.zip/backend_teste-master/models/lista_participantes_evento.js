const Sequelize = require('sequelize');
const sequelize = require('../database'); 
const Usuario = require('./user'); 
const Evento = require('./eventos'); 

const ListaParticipantesEvento = sequelize.define('lista_participantes_evento', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    usuario_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: Usuario,
            key: 'id'
        }
    },
    evento_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: Evento,
            key: 'id'
        }
    }
}, {
    tableName: 'lista_participantes_evento',
    timestamps: false // Se você não tem colunas de timestamp, como createdAt e updatedAt
});

// Isso assume que você tem a associação definida no modelo Usuario e Evento para poder utilizar em joins
ListaParticipantesEvento.belongsTo(Usuario, { foreignKey: 'usuario_id', as: 'usuario' });
ListaParticipantesEvento.belongsTo(Evento, { foreignKey: 'evento_id', as: 'evento' });

module.exports = ListaParticipantesEvento;
