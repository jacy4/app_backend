const Sequelize = require('sequelize');
const sequelize = require('../database');
const ComentarioAlbum = require('./comentarios_albuns'); // Assumindo que você já tem o modelo de ComentariosAlbuns
const Album = require('./albuns'); // Assumindo que você já tem o modelo de Albuns
const User = require('./user'); // Assumindo que você já tem o modelo de User

const DenunciasComentariosDeAlbuns = sequelize.define('denuncias_comentarios_de_albuns', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  resolvida: {
    type: Sequelize.BOOLEAN,
    defaultValue: false,
    allowNull: true
  },
  id_comentario_denunciado: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'comentarios_albuns', // Nome da tabela relacionada, que contém os comentários dos álbuns
      key: 'id'
    }
  },
  id_album: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'albuns', // Nome da tabela relacionada, ajuste conforme necessário
      key: 'id'
    }
  },
  id_denunciador: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'users', 
      key: 'id'
    }
  },
  data_denuncia: {
    type: Sequelize.DATE,
    allowNull: false,
    defaultValue: Sequelize.NOW
  },
  motivo_denuncia: {
    type: Sequelize.STRING(255), 
    allowNull: false
  },
  descricao_denuncia: {
    type: Sequelize.TEXT,
    allowNull: true 
  }
}, {
  tableName: 'denuncias_comentarios_de_albuns',
  timestamps: false
});

// Associações
DenunciasComentariosDeAlbuns.belongsTo(ComentarioAlbum, { foreignKey: 'id_comentario_denunciado', as: 'comentario' });
DenunciasComentariosDeAlbuns.belongsTo(Album, { foreignKey: 'id_album', as: 'album' });
DenunciasComentariosDeAlbuns.belongsTo(User, { foreignKey: 'id_denunciador', as: 'denunciador' });

module.exports = DenunciasComentariosDeAlbuns;
