const Sequelize = require('sequelize');
const sequelize = require('../database');
const Area = require('./areas');
const Topico = require('./topicos');
const User = require('./user');
const Centro = require('./centro'); 
const Evento = require('./eventos'); // Supondo que 'lista_grupo' seja o nome do modelo que você usa para a lista de membros

const Grupo = sequelize.define('grupo', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  nome: {
    type: Sequelize.STRING,
    allowNull: false
  },
  area_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: Area,
      key: 'id'
    }
  },
  
  centro_id: {  // Novo campo
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: Centro, // Modelo de Centro
      key: 'id'
    }
  },
  topico_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: Topico,
      key: 'id'
    }
  },
  descricao: {
    type: Sequelize.STRING(1000),
    allowNull: true
  },
  autor_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: 'id'
    }
  },
  createdAt: {
    type: Sequelize.DATE,
    defaultValue: Sequelize.NOW
  },
  capa: {
    type: Sequelize.STRING,
    allowNull: true
  },
  estado: {  // Novo campo
    type: Sequelize.ENUM('Ativo', 'Inativo', 'Denunciado'),
    defaultValue: 'Ativo',
    allowNull: false
  },
  
  evento_id: {
    type: Sequelize.INTEGER,
    allowNull: true, // Opcional
    references: {
      model: Evento, // Modelo de Eventos
      key: 'id'
    }}
}, {
  tableName: 'grupos',
  timestamps: true // Se precisar dos campos createdAt e updatedAt
});

// Definir relacionamentos
Grupo.belongsTo(Area, { foreignKey: 'area_id', as: 'area' });
Grupo.belongsTo(Topico, { foreignKey: 'topico_id', as: 'topico' });
Grupo.belongsTo(User, { foreignKey: 'autor_id', as: 'autor' });
Grupo.belongsTo(Evento, { foreignKey: 'evento_id', as: 'evento' });
Grupo.belongsTo(Centro, { foreignKey: 'centro_id', as: 'centro' });  

module.exports = Grupo;
