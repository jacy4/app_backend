const Sequelize = require('sequelize');
const sequelize = require('../database');

const Area = sequelize.define('area', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    nome: Sequelize.STRING
}, {
    tableName: 'areas'
});

module.exports = Area;
