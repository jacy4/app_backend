const Sequelize = require('sequelize');
const sequelize = require('../database');
const Topico = require('./topicos');
const Area = require('./areas');
const User = require('./user'); 

const Publicacao = sequelize.define('publicacao', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  titulo: {
    type: Sequelize.STRING,
    allowNull: false
  },
  latitude: {
    type: Sequelize.FLOAT,
    allowNull: true
  },
  longitude: {
    type: Sequelize.FLOAT,
    allowNull: true
  },
  topico_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: Topico,
      key: 'id'
    }
  },
  createdAt: {
    type: Sequelize.DATE,
    defaultValue: Sequelize.NOW
  },
  estado: {
    type: Sequelize.ENUM('Ativa', 'Denunciada', 'Por validar'),
    defaultValue: 'Ativa'
  },
  centro_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'centros',
      key: 'id'
    }
  },
  galeria: {
    type: Sequelize.JSON,
    allowNull: true
  },
  descricao: {
    type: Sequelize.STRING(1000),
    allowNull: true
  },
  horario: {
    type: Sequelize.JSON,
    allowNull: true
  },
  localizacao: {
    type: Sequelize.STRING,
    allowNull: true
  },
  paginaweb: {
    type: Sequelize.STRING,
    allowNull: true
  },
  telemovel: {
    type: Sequelize.STRING(9),
    allowNull: true
  },
  email: {
    type: Sequelize.STRING,
    allowNull: true
  },
  visivel: {
    type: Sequelize.BOOLEAN,
    defaultValue: true
  },
  autor_id: { 
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: User, 
      key: 'id'
    }
  },
  area_id: { // Novo campo para associar a uma área
    type: Sequelize.INTEGER,
    allowNull: true,
    references: {
      model: Area, // Supondo que a tabela de áreas seja 'areas'
      key: 'id'
    }
  }
  
}, {
  tableName: 'publicacoes',
  timestamps: true
});

// Definir relacionamento
//Publicacao.belongsTo(Topico, { foreignKey: 'topico_id', as: 'topico' });
//Publicacao.belongsTo(User, { foreignKey: 'autor_id', as: 'autor' });
//Publicacao.belongsTo(Area, { foreignKey: 'area_id', as: 'area' });

module.exports = Publicacao;

