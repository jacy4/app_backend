const Sequelize = require('sequelize');
const sequelize = require('../database'); // Ajuste este caminho conforme necessário
const Evento = require('./eventos'); // Certifique-se de que o modelo do Evento está corretamente importado

const GaleriaEvento = sequelize.define('galeria_evento', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    caminho_imagem: {
        type: Sequelize.TEXT,
        allowNull: false
    },
    evento_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: Evento,
            key: 'id'
        }
    }
}, {
    tableName: 'galeria_evento', 
    timestamps: false // Remova se você estiver utilizando campos de timestamp (createdAt, updatedAt)
});

module.exports = GaleriaEvento;
