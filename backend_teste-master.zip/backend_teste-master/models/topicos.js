const Sequelize = require('sequelize');
const sequelize = require('../database');
const Area = require('./areas');

const Topico = sequelize.define('topico', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    nome: {
        type: Sequelize.STRING,
        allowNull: false
    },
    topico_icon: {
        type: Sequelize.STRING,
        allowNull: true
    },
    area_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: Area,
            key: 'id'
        }
    }
});

// Definir relacionamento
Topico.belongsTo(Area, { foreignKey: 'area_id', as: 'area' });

module.exports = Topico;
