const Sequelize = require('sequelize');
const sequelize = require('../database');
const Albuns = require('./albuns');  // Modelo de Álbuns
const User = require('./user');  // Modelo de Usuário
const GaleriaAlbum=require('./galeria_album');

const ComentariosAlbuns = sequelize.define('comentario_album', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  user_id: {
    type: Sequelize.INTEGER,
    allowNull: false
  },
  likes: {  // Campo para armazenar o número de likes
    type: Sequelize.INTEGER,
    allowNull: false,
    defaultValue: 0
  },
  album_id: {  // Referência ao álbum
    type: Sequelize.INTEGER,
    allowNull: false
  },
  id_galeria: {  // Novo campo de referência para a galeria de álbuns
    type: Sequelize.INTEGER,
    allowNull: true,  // Permitir nulo se não for obrigatório
    references: {
      model: GaleriaAlbum,  // Referência ao modelo GaleriaAlbum
      key: 'id'
    }
  },
  data_comentario: {
    type: Sequelize.DATE,
    allowNull: false,
    defaultValue: Sequelize.NOW
  },
  createdat: {  // Campo para armazenar a data de criação
    type: Sequelize.DATE,
    defaultValue: Sequelize.NOW
  },
  classificacao: {
    type: Sequelize.INTEGER,
    defaultValue: 0
  },
  texto_comentario: {
    type: Sequelize.TEXT,
    allowNull: false
  }
}, {
  tableName: 'comentarios_albuns',
  timestamps: false
});

// Associações
ComentariosAlbuns.belongsTo(Albuns, { foreignKey: 'album_id', as: 'album' });  // Associação com Álbuns
ComentariosAlbuns.belongsTo(User, { foreignKey: 'user_id', as: 'usuario' });  // Associação com Usuários
ComentariosAlbuns.belongsTo(GaleriaAlbum, { foreignKey: 'id_galeria', as: 'galeria' });

module.exports = ComentariosAlbuns;
