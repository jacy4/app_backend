const Sequelize = require('sequelize');
const sequelize = require('../database'); 
const Usuario = require('./user'); 
const Grupo = require('./grupos'); 

const ListaGrupo = sequelize.define('listagrupo', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    usuario_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: Usuario,
            key: 'id'
        }
    },
    grupo_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: Grupo,
            key: 'id'
        }
    }
}, {
    tableName: 'listagrupo',
    timestamps: false // Se você não tem colunas de timestamp, como createdAt e updatedAt
});

// Isso assume que você tem a associação definida no modelo Usuario e Evento para poder utilizar em joins
ListaGrupo.belongsTo(Usuario, { foreignKey: 'usuario_id', as: 'usuario' });
ListaGrupo.belongsTo(Grupo, { foreignKey: 'grupo_id', as: 'grupo' });

module.exports = ListaGrupo;
