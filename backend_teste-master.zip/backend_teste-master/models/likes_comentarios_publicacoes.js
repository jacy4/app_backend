const Sequelize = require('sequelize');
const sequelize = require('../database');
const ComentarioPublicacao = require('./comentarios');
const User = require('./user');

const LikeComentarioPublicacao = sequelize.define('like_comentario_publicacao', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  comentario_publicacao_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: ComentarioPublicacao,
      key: 'id'
    }
  },
  user_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: 'id'
    }
  },
  like: {
    type: Sequelize.BOOLEAN,
    allowNull: false,
    defaultValue: true
  },
  createdat: {
    type: Sequelize.DATE,
    allowNull: false,
    defaultValue: Sequelize.NOW
  }
}, {
  tableName: 'likes_comentarios_publicacoes',
  timestamps: false
});

LikeComentarioPublicacao.belongsTo(ComentarioPublicacao, { foreignKey: 'comentario_publicacao_id' });
LikeComentarioPublicacao.belongsTo(User, { foreignKey: 'user_id' });

module.exports = LikeComentarioPublicacao;
