const Sequelize = require('sequelize');
const sequelize = require('../database');
const MensagemForum = require('./mensagem_forum'); // Importando o modelo de mensagens de fóruns
const Forum = require('./forum'); // Importando o modelo de fóruns
const User = require('./user'); // Importando o modelo de usuários

const DenunciaMensagemForum = sequelize.define('denuncia_mensagem_forum', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  mensagem_forum_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: MensagemForum,
      key: 'id'
    }
  },
  forum_id: { // Novo campo adicionado
    type: Sequelize.INTEGER,
    allowNull: true,
    references: {
      model: Forum,
      key: 'id'
    }
  },
  denunciante_id: { 
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: User, 
      key: 'id'
    }
  },
  motivo: {
    type: Sequelize.STRING(500),
    allowNull: false
  },
  informacao_adicional: {
    type: Sequelize.STRING(1000),
    allowNull: true
  },
  resolvida: {
    type: Sequelize.BOOLEAN,
    defaultValue: false,
    allowNull: false
  },
  createdAt: {  
    type: Sequelize.DATE,
    defaultValue: Sequelize.NOW
  }
}, {
  tableName: 'denuncias_mensagens_forum',
  timestamps: false // Se não quiser os campos updatedAt
});

// Definir relacionamentos
DenunciaMensagemForum.belongsTo(MensagemForum, { foreignKey: 'mensagem_forum_id' });
DenunciaMensagemForum.belongsTo(Forum, { foreignKey: 'forum_id' });
DenunciaMensagemForum.belongsTo(User, { foreignKey: 'denunciante_id', as: 'denunciante' });

module.exports = DenunciaMensagemForum;
