const Sequelize = require('sequelize');
const sequelize = require('../database');

const User = sequelize.define('user', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    nome: Sequelize.STRING,
    sobrenome: Sequelize.STRING,
    caminho_foto: {
        type: Sequelize.STRING,
        allowNull: true
    },
    caminho_fundo: {
        type: Sequelize.STRING,
        allowNull: true
    },
    email: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true
    },
    password: {
        type: Sequelize.STRING,
        allowNull: true
    },
    sobre_min: Sequelize.STRING,
    centro_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: 'centros',
            key: 'id'
        }
    },
    active: {
        type: Sequelize.BOOLEAN,
        default: true
    }
}, {
    tableName: 'users', // Especifica o nome da tabela existente
    timestamps: true // Se a tabela não tem os campos createdAt e updatedAt
});


module.exports = User;
