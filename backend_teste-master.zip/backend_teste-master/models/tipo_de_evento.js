const Sequelize = require('sequelize');
const sequelize = require('../database');

// Definição do modelo TipoEvento
const TipoEvento = sequelize.define('tipo_evento', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    nome_tipo: {
        type: Sequelize.STRING,
        allowNull: false
    },
    caminho_imagem: {
        type: Sequelize.STRING,
        allowNull: true
    }
}, {
    tableName: 'tipos_de_evento',
    timestamps: false 
});

module.exports = TipoEvento;
