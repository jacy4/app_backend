const Sequelize = require('sequelize');
const sequelize = require('../database');
const Centro = require('./centro');
const User = require('./user');

const Administradores = sequelize.define('administradores', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    administrador: Sequelize.STRING,
    email: Sequelize.STRING,
    pass: Sequelize.STRING,
    centro_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: Centro,
            key: 'id'
        }
    },
    user_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: User,
            key: 'id'
        }
    }
});

Administradores.belongsTo(Centro, { foreignKey: 'centro_id', as: 'centro' });
Administradores.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

module.exports = Administradores;
