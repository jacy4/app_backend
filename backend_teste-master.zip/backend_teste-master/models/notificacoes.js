const Sequelize = require('sequelize');
const sequelize = require('../database');
const User = require('./user'); // Assumindo que já existe um modelo de usuário definido

const Notificacao = sequelize.define('notificacao', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  usuario_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: User, // Referencia o modelo de usuário
      key: 'id'
    }
  },
  tipo: {
    type: Sequelize.STRING(100),
    allowNull: false
  },
  mensagem: {
    type: Sequelize.STRING(1000),
    allowNull: false
  },
  lida: {
    type: Sequelize.BOOLEAN,
    defaultValue: false
  },
  createdat: {
    type: Sequelize.DATE,
    defaultValue: Sequelize.NOW
  }
}, {
  tableName: 'notificacoes',
  timestamps: false
});

Notificacao.belongsTo(User, { foreignKey: 'usuario_id', as: 'usuario' });

module.exports = Notificacao;
