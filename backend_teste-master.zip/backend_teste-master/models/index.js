const sequelize = require('../database');
const Eventos = require('./eventos');
const ComentariosEventos = require('./comentarios_eventos');
const User = require('./user');
const Area = require('./areas');
const TipoEvento = require('./tipo_de_evento');
const Topico = require('./topicos');
const Centro = require('./centro');
const GaleriaEvento = require('./galeria_evento');
const DenunciasComentariosDeEventos = require('./denuncias_comentarios_de_eventos');
const DenunciasDeEventos = require('./denuncias_de_eventos');
const Administradores = require('./administradores');
const TopicosFavoritosUser = require('./topicos_favoritos_user');
const AreasFavoritasUser = require('./areas_favoritas_user');
const Publicacao = require('./publicacoes'); // Adicionando o modelo de Publicações
const Comentario = require('./comentarios');
const GaleriaAlbum = require('./galeria_album'); // Importando o modelo GaleriaAlbum
const Album = require('./albuns'); // Importando o modelo Album
// Associações

User.belongsToMany(Topico, {
  through: TopicosFavoritosUser,
  foreignKey: 'usuario_id',
  otherKey: 'topico_id',
  as: 'topicos_favoritos'
});

Topico.belongsToMany(User, {
  through: TopicosFavoritosUser,
  foreignKey: 'topico_id',
  otherKey: 'usuario_id',
  as: 'usuarios_favoritos'
});


User.belongsToMany(Area, {
  through: AreasFavoritasUser,  
  foreignKey: 'usuario_id',    
  otherKey: 'area_id',         
  as: 'areas_favoritas'        
});

// Uma área pode ser favorita de vários usuários
Area.belongsToMany(User, {
  through: AreasFavoritasUser,  
  foreignKey: 'area_id',        
  otherKey: 'usuario_id',       
  as: 'usuarios_favoritos'     
});

console.log(AreasFavoritasUser.associations);


Administradores.belongsTo(User, { foreignKey: 'user_id', as: 'usuario' });
User.hasOne(Administradores, { foreignKey: 'user_id', as: 'administrador' });


Eventos.hasMany(ComentariosEventos, { foreignKey: 'evento_id', as: 'comentarios' });
ComentariosEventos.belongsTo(Eventos, { foreignKey: 'evento_id', as: 'evento' });
ComentariosEventos.belongsTo(User, { foreignKey: 'user_id', as: 'usuario' });

Eventos.belongsTo(Area, { foreignKey: 'area_id', as: 'area' });
Eventos.belongsTo(TipoEvento, { foreignKey: 'tipodeevento_id', as: 'tipo_evento' });
Eventos.belongsTo(Topico, { foreignKey: 'topico_id', as: 'topico' });
Eventos.belongsTo(User, { foreignKey: 'autor_id', as: 'user' });
Eventos.belongsTo(Centro, { foreignKey: 'centro_id', as: 'centro' });
Eventos.hasMany(GaleriaEvento, {
  foreignKey: 'evento_id',
  as: 'imagens'
});
GaleriaEvento.belongsTo(Eventos, { foreignKey: 'evento_id', as: 'evento' });

DenunciasComentariosDeEventos.belongsTo(ComentariosEventos, { foreignKey: 'id_comentario_denunciado', as: 'comentario_denunciado' });
DenunciasComentariosDeEventos.belongsTo(User, { foreignKey: 'id_denunciador', as: 'denunciador' });

ComentariosEventos.hasMany(DenunciasComentariosDeEventos, { foreigfnKey: 'id_comentario_denunciado', as: 'denuncias' });

DenunciasDeEventos.belongsTo(Eventos, { foreignKey: 'id_evento_denunciado', as: 'evento_denunciado' });
DenunciasDeEventos.belongsTo(User, { foreignKey: 'id_denunciador', as: 'denunciador' });

Eventos.hasMany(DenunciasDeEventos, { foreignKey: 'id_evento_denunciado', as: 'denuncias' });

// Associações para Publicação e Comentários de Publicações
Publicacao.belongsTo(Topico, { foreignKey: 'topico_id', as: 'topico' });
Publicacao.belongsTo(User, { foreignKey: 'autor_id', as: 'autor' });
Publicacao.belongsTo(Area, { foreignKey: 'area_id', as: 'area' });
Publicacao.hasMany(Comentario, { foreignKey: 'publicacao_id', as: 'comentarios' });
Publicacao.belongsTo(Centro, { foreignKey: 'centro_id', as: 'centro' });

Comentario.belongsTo(Publicacao, { foreignKey: 'publicacao_id', as: 'publicacao' });
Comentario.belongsTo(User, { foreignKey: 'user_id', as: 'usuario' });


// Associação de Album com GaleriaAlbum
Album.hasMany(GaleriaAlbum, { foreignKey: 'album_id', as: 'imagens' });
GaleriaAlbum.belongsTo(Album, { foreignKey: 'album_id', as: 'album' });

GaleriaAlbum.belongsTo(Area, { foreignKey: 'area_id', as: 'area' });
GaleriaAlbum.belongsTo(Centro, { foreignKey: 'centro_id', as: 'centro' });
GaleriaAlbum.belongsTo(User, { foreignKey: 'id_user', as: 'usuario' });

module.exports = {
  sequelize,
  Eventos,
  ComentariosEventos,
  User,
  Area,
  AreasFavoritasUser,
  TipoEvento,
  Topico,
  TopicosFavoritosUser,
  Centro,
  GaleriaEvento,
  DenunciasComentariosDeEventos,
  DenunciasDeEventos,
  Publicacao,  // Exportando o modelo de Publicações
  Comentario,
  GaleriaAlbum,
  Album

};
// serve para fazer as atribuições entre evento e comentarios ,para nao cair em loop