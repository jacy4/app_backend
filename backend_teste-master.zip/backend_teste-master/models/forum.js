const Sequelize = require('sequelize');
const sequelize = require('../database');
const Centro = require('./centro');
const Area = require('./areas'); // Certifique-se de que o caminho está correto

const Forum = sequelize.define('forum', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  area_id: { 
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: Area, // Relacionamento com a tabela Area
      key: 'id'
    }
  },
  
  centro_id: {  // Novo campo
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: Centro, // Modelo de Centro
      key: 'id'
    }
  },
  
  nome: {
    type: Sequelize.STRING,
    allowNull: false
  },
  
  estado: {  // Novo campo
    type: Sequelize.ENUM('Ativo', 'Inativo', 'Denunciado'),
    defaultValue: 'Ativo',
    allowNull: false
  },
}, {
  tableName: 'forum', // Nome da tabela no banco de dados
  timestamps: false // Desabilita timestamps, se não precisar de createdAt/updatedAt
});

// Definir relacionamento com a tabela Area
Forum.belongsTo(Area, { foreignKey: 'area_id', as: 'area' });
Forum.belongsTo(Centro, { foreignKey: 'centro_id', as: 'centro' });

module.exports = Forum;
