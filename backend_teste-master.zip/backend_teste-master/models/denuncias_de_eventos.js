const Sequelize = require('sequelize');
const sequelize = require('../database');

const DenunciasDeEventos = sequelize.define('denuncias_de_eventos', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  id_evento_denunciado: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'eventos', // Nome da tabela relacionada
      key: 'id'
    }
  },
  id_denunciador: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'users', // Nome da tabela relacionada
      key: 'id'
    }
  },
  data_denuncia: {
    type: Sequelize.DATE,
    allowNull: false,
    defaultValue: Sequelize.NOW
  },
  motivo_denuncia: {
    type: Sequelize.STRING(255), 
    allowNull: false
  },
  descricao_denuncia: {
    type: Sequelize.TEXT,
    allowNull: true // Este campo pode ser opcional
  }
}, {
  tableName: 'denuncias_de_eventos',
  timestamps: false
});

module.exports = DenunciasDeEventos;
