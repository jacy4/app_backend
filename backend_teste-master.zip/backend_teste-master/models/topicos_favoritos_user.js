const Sequelize = require('sequelize');
const sequelize = require('../database');
const User = require('./user');
const Topico = require('./topicos');

const TopicosFavoritosUser = sequelize.define('topicos_favoritos_user', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    usuario_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: User,
            key: 'id'
        },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE'
    },
    topico_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: Topico,
            key: 'id'
        },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE'
    }
}, {
    tableName: 'topicos_favoritos_user',
    timestamps: false
});

module.exports = TopicosFavoritosUser;
