const Sequelize = require('sequelize');
const sequelize = require('../database'); // Certifique-se de que está importando o arquivo correto

const Centro = sequelize.define('centro', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    nome: {
        type: Sequelize.STRING, 
        allowNull: true
    },
    morada: Sequelize.STRING,
    imagem: {
        type: Sequelize.STRING, 
        allowNull: true 
    }
});

module.exports = Centro;
