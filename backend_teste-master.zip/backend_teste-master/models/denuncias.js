const Sequelize = require('sequelize');
const sequelize = require('../database');
const Publicacao = require('./publicacoes');
const ComentarioPublicacao = require('./comentarios');
const User = require('./user'); 

const Denuncia = sequelize.define('denuncia', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  comentario_publicacao_id: { // Alterado para referenciar o comentário
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: ComentarioPublicacao, // Referência ao modelo de comentário
      key: 'id'
    }
  },
  denunciante_id: { 
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: User, 
      key: 'id'
    }
  },
  motivo: {
    type: Sequelize.STRING(500),
    allowNull: false
  },
  informacao_adicional: {
    type: Sequelize.STRING(1000),
    allowNull: false
  },
  resolvida: {
    type: Sequelize.BOOLEAN,
    defaultValue: false,
    allowNull: false
  },
  createdat: {  
    type: Sequelize.DATE,
    defaultValue: Sequelize.NOW
  }
}, {
  tableName: 'denuncias',
  timestamps: false
});

Denuncia.belongsTo(ComentarioPublicacao, { foreignKey: 'comentario_publicacao_id' })
Denuncia.belongsTo(User, { foreignKey: 'denunciante_id', as: 'denunciante' });


module.exports = Denuncia;
