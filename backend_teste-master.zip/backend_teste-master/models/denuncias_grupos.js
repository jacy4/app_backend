const Sequelize = require('sequelize');
const sequelize = require('../database');
const Grupo = require('./grupos'); // Importando o modelo de grupos
const User = require('./user'); // Importando o modelo de usuários

const DenunciaGrupo = sequelize.define('denuncia_grupo', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  grupo_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: Grupo,
      key: 'id'
    }
  },
  denunciante_id: { 
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: User, 
      key: 'id'
    }
  },
  motivo: {
    type: Sequelize.STRING(500),
    allowNull: false
  },
  informacao_adicional: {
    type: Sequelize.STRING(1000),
    allowNull: true
  },
  resolvida: {
    type: Sequelize.BOOLEAN,
    defaultValue: false,
    allowNull: false
  },
  createdAt: {  
    type: Sequelize.DATE,
    defaultValue: Sequelize.NOW
  }
}, {
  tableName: 'denuncias_grupos',
  timestamps: false // Se não quiser os campos updatedAt
});

// Definir relacionamentos
DenunciaGrupo.belongsTo(Grupo, { foreignKey: 'grupo_id' });
DenunciaGrupo.belongsTo(User, { foreignKey: 'denunciante_id', as: 'denunciante' });

module.exports = DenunciaGrupo;
