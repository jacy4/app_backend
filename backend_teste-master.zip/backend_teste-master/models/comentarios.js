const Sequelize = require('sequelize');
const sequelize = require('../database');
const Publicacao = require('./publicacoes');
const User = require('./user'); 

const Comentario = sequelize.define('comentario', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  publicacao_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: Publicacao,
      key: 'id'
    }
  },
  data_comentario: {
    type: Sequelize.DATE,
    allowNull: false,
    defaultValue: Sequelize.NOW
  },
  likes: {  // Novo campo adicionado para armazenar o número de likes
    type: Sequelize.INTEGER,
    allowNull: false,
    defaultValue: 0
  },
  classificacao: {
    type: Sequelize.INTEGER,
  },
  user_id: { 
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: User, 
      key: 'id'
    }
  },
  conteudo: {
    type: Sequelize.STRING(1000),
    allowNull: false
  },
  createdat: {  // Aqui foi alterado de 'createdAt' para 'createdat'
    type: Sequelize.DATE,
    defaultValue: Sequelize.NOW
  }
}, {
  tableName: 'comentarios',
  timestamps: false
});

//Comentario.belongsTo(Publicacao, { foreignKey: 'publicacao_id' });
//Comentario.belongsTo(User, { foreignKey: 'user_id', as: 'usuario' });

module.exports = Comentario;
