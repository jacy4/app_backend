const Sequelize = require('sequelize');
const sequelize = require('../database');

const AreasFavoritasUser = sequelize.define('areas_favoritas_user', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    usuario_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: 'user', // Nome do modelo User
            key: 'id'
        },
        onDelete: 'CASCADE', // Opcional, define o comportamento de exclusão em cascata
        onUpdate: 'CASCADE'  // Opcional, define o comportamento de atualização em cascata
    },
    area_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: 'area', // Nome do modelo Area
            key: 'id'
        },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE'
    }
}, {
    tableName: 'areas_favoritas_user',
    timestamps: false
});

module.exports = AreasFavoritasUser;
