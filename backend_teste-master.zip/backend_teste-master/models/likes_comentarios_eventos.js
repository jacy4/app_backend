const Sequelize = require('sequelize');
const sequelize = require('../database');
const ComentarioEvento = require('./comentarios_eventos');  // Certifique-se de que este modelo existe
const User = require('./user');

const LikeComentarioEvento = sequelize.define('like_comentario_evento', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  comentario_evento_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: ComentarioEvento,
      key: 'id'
    }
  },
  user_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: 'id'
    }
  },
  like: {
    type: Sequelize.BOOLEAN,
    allowNull: false,
    defaultValue: true
  },
  createdat: {
    type: Sequelize.DATE,
    allowNull: false,
    defaultValue: Sequelize.NOW
  }
}, {
  tableName: 'likes_comentarios_eventos',
  timestamps: false
});

LikeComentarioEvento.belongsTo(ComentarioEvento, { foreignKey: 'comentario_evento_id' });
LikeComentarioEvento.belongsTo(User, { foreignKey: 'user_id' });

module.exports = LikeComentarioEvento;
