const Sequelize = require('sequelize');
const sequelize = require('../database'); // Ajuste este caminho conforme necessário
const Album = require('./albuns'); // Certifique-se de que o modelo do Album está corretamente importado
const Area = require('./areas'); // Importar o modelo de Áreas
const Centro = require('./centro'); // Importar o modelo de Centros
const User = require('./user');

const GaleriaAlbum = sequelize.define('galeria_album', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    caminho_imagem: {
        type: Sequelize.TEXT,
        allowNull: false
    },
    album_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: Album,
            key: 'id'
        }
    },
    descricao: {
        type: Sequelize.TEXT,
        allowNull: true
    },
    titulo: {
        type: Sequelize.STRING,
        allowNull: false
    },
    area_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: Area,  // Refere-se ao modelo Area
            key: 'id'
        }
    },
    centro_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: Centro,  // Refere-se ao modelo Centro
            key: 'id'
        }
    },
    id_user: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: User,  // Refere-se ao modelo User
            key: 'id'
        }
    }
}, {
    tableName: 'galeria_album', 
     
});


module.exports = GaleriaAlbum;
