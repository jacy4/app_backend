const Sequelize = require('sequelize');
const sequelize = require('../database');

const DenunciasComentariosDeEventos = sequelize.define('denuncias_comentarios_de_eventos', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  resolvida: {
    type: Sequelize.BOOLEAN,
    defaultValue: false,
    allowNull: true
  },
  id_comentario_denunciado: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'comentarios_eventos', // Nome da tabela relacionada
      key: 'id'
    }
  },
  id_evento: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'eventos', // Nome da tabela relacionada, ajuste conforme necessário
      key: 'id'
    }
  },
  id_denunciador: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'users', 
      key: 'id'
    }
  },
  data_denuncia: {
    type: Sequelize.DATE,
    allowNull: false,
    defaultValue: Sequelize.NOW
  },
  motivo_denuncia: {
    type: Sequelize.STRING(255), 
    allowNull: false
  },
  descricao_denuncia: {
    type: Sequelize.TEXT,
    allowNull: true 
  }
}, {
  tableName: 'denuncias_comentarios_de_eventos',
  timestamps: false
});

module.exports = DenunciasComentariosDeEventos;
