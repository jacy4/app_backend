require('dotenv').config();
const express = require('express');
var bodyParser = require('body-parser');
const { sequelize } = require('./models'); // Importe a instância Sequelize
const centroRoutes = require('./routes/centro_rotas');
const userRoutes = require('./routes/users_rotas');
const adminRoutes = require('./routes/admin_rotas');
const areaRoutes = require('./routes/area_rotas');
const topicoRoutes = require('./routes/topicos_rotas');
const publicacaoRoutes = require('./routes/publicacoes_rotas');
const comentarioRouter = require('./routes/comentarios_rotas');
const avaliacaoRouter = require('./routes/avaliacao_rotas');
const denunciasRouter = require('./routes/denuncias_rotas');
const eventosRouter = require('./routes/eventos_rotas');
const notificacaoRouter = require('./routes/notificacoes_rotas');
const tipoeventoRouter= require('./routes/tipo_de_evento');
const comentariosEventosRouter=require('./routes/comentarios_eventos_rotas');
const ListaParticipantesEventoRouter=require('./routes/lista_participantes_evento_rotas');
const GaleriaEventoRouter=require('./routes/galeria_evento_rotas');
const DenunciasComentariosDeEventos=require('./routes/denuncias_comentarios_de_eventos');
const DenunciasDeEventos=require('./routes/denucias_de_eventos_rotas');
const AreasFavoritasUser=require('./routes/areas_favoritas_user_rotas');
const TopicosFavoritosUser=require('./routes/topicos_favoritos_user_rotas');
const DenunciasMensagensForunsRouter=require('./routes/denuncias_mensagens_forum_rotas');
const likescomentariospublicacoesRouter=require('./routes/likes_comentarios_publicacoes_rotas');
const gruposRouter=require('./routes/grupos_rotas');
const listaGrupoRouter=require('./routes/listagrupo_rotas');
const denuncias_gruposRouter=require('./routes/denuncias_grupos_rotas');
const forumRouter=require('./routes/foruns_rotas');
const mensagem_forumRouter=require('./routes/mensagem_forum_rotas');
const likescomentarioseventosRouter=require('./routes/likes_comentarios_eventos_rotas');
const dashboardRouter=require('./routes/dashboard_rotas');
const albunsRouter=require('./routes/albuns_rotas');
const GaleriaAlbumRouter=require('./routes/galeria_album_rotas');
const ComentariosAlbumRouter=require('./routes/comentarios_albuns_rotas');
const likescomentariosalbunsRouter=require('./routes/likes_comentarios_albuns_rotas');
const denunciascomentariosalbunsRouter=require('./routes/denuncias_comentarios_de_albuns_rotas');

const authenticateJWT = require('./middlewares/authenticateJWT'); 
const cron = require('node-cron');
const app = express();
const port = process.env.PORT || 3000;
const cors = require('cors');


// Configurar CORS
app.use(cors());
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
  res.header('Allow', 'GET, POST, OPTIONS, PUT, DELETE');
  next();
});

// Middlewares
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());

// Rotas

app.get('/', (req, res) => {
  res.send('PAGINA DO BACKENDEND');
});

// Rota para obter todos os centros
app.use('/centros', authenticateJWT, centroRoutes);
app.use('/users', authenticateJWT,userRoutes);
app.use('/admin', adminRoutes); // A rota de login não precisa de autenticação
app.use('/areas', authenticateJWT,areaRoutes);
app.use('/topicos', authenticateJWT,topicoRoutes);
app.use('/publicacoes', authenticateJWT, publicacaoRoutes);
app.use('/comentarios', authenticateJWT,comentarioRouter);
app.use('/avaliacao', authenticateJWT,avaliacaoRouter);
app.use('/denuncias', authenticateJWT,denunciasRouter);
app.use('/eventos', authenticateJWT,eventosRouter);
app.use('/notificacoes', authenticateJWT,notificacaoRouter);
app.use('/tipodeevento',authenticateJWT,tipoeventoRouter);
app.use('/comentarios_eventos',authenticateJWT,comentariosEventosRouter);
app.use('/listaparticipantes_evento',authenticateJWT,ListaParticipantesEventoRouter);
app.use('/galeria_evento',authenticateJWT,GaleriaEventoRouter);
app.use('/denuncias_comentarios_eventos',authenticateJWT,DenunciasComentariosDeEventos);
app.use('/denuncias_de_eventos',authenticateJWT,DenunciasDeEventos);
app.use('/areasfavoritas',authenticateJWT,AreasFavoritasUser);
app.use('/topicosfavoritos',authenticateJWT,TopicosFavoritosUser);
app.use('/galeria_album',authenticateJWT,GaleriaAlbumRouter);
app.use('/albuns',authenticateJWT,albunsRouter);
app.use('/denuncias_mensagens_forum',authenticateJWT,DenunciasMensagensForunsRouter);
app.use('/comentarios_albuns',authenticateJWT,ComentariosAlbumRouter);
app.use('/comentarios_albuns',authenticateJWT,ComentariosAlbumRouter);
app.use('/likes_comentarios_albuns',authenticateJWT,likescomentariosalbunsRouter);
app.use('/denuncias_comentarios_de_albuns',authenticateJWT,denunciascomentariosalbunsRouter);
app.use('/grupos',authenticateJWT,gruposRouter);
app.use('/listagrupo',authenticateJWT,listaGrupoRouter);
app.use('/denuncias_grupos',authenticateJWT,denuncias_gruposRouter);
app.use('/forum',authenticateJWT,forumRouter);
app.use('/mensagem_forum',authenticateJWT,mensagem_forumRouter);

app.use('/likescomentariospublicacoes',authenticateJWT,likescomentariospublicacoesRouter);
app.use('/likescomentarioseventos',authenticateJWT,likescomentarioseventosRouter);
app.use('/dsb',authenticateJWT,dashboardRouter);
//Testar Github

sequelize.sync()
  .then(() => {
    // console.log('Tabelas sincronizadas com sucesso.');
  })
  .catch(err => {
    console.error('Erro ao sincronizar tabelas:', err);
  });

// Log informativo ao iniciar o servidor
// console.log('O cron job está configurado para rodar a cada 30 minutos.');

// Configuração do cron job
cron.schedule('*/30 * * * *', async () => {
  // console.log('Iniciando a verificação de eventos para finalização...');
  try {
    const now = new Date();
    const [results, metadata] = await sequelize.query(
      `UPDATE public.eventos
       SET estado = 'Finalizada'
       WHERE datafimatividade <= :now AND estado = 'Ativa'`,
      { replacements: { now: now } }
    );
    // console.log(`Eventos finalizados: ${metadata.rowCount}`);
    // console.log('A verificação de eventos para finalização foi concluída.');
  } catch (error) {
    console.error('Erro ao finalizar eventos:', error);
  }
});

app.listen(port, () => {
  // console.log(`server do backendd a correr na porta->${port}`);
});
