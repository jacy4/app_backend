const MensagemForum = require('../models/mensagem_forum'); 
const DenunciaMensagemForum = require('../models/denuncias_mensagens_forum');
const Usuario = require('../models/user');
const Forum = require('../models/forum');

const mensagemForumController = {};

// Criar uma nova mensagem no fórum
mensagemForumController.create = async (req, res) => {
    const { forum_id, user_id, texto_mensagem } = req.body;

    try {
        const novaMensagem = await MensagemForum.create({
            forum_id,
            user_id,
            texto_mensagem,
            createdat: new Date()
        });

        res.status(201).json(novaMensagem);
    } catch (error) {
        console.error('Erro ao criar mensagem no fórum:', error);
        res.status(500).json({ error: 'Erro ao criar mensagem no fórum' });
    }
};

// Listar todas as mensagens de um fórum específico
mensagemForumController.listarMensagensPorForum = async (req, res) => {
    const { forum_id } = req.params;

    try {
        const mensagens = await MensagemForum.findAll({
            where: { forum_id },
            include: [
                {
                    model: Usuario,
                    as: 'usuario',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                }
            ],
            order: [['createdat', 'ASC']]
        });

        if (mensagens.length > 0) {
            res.json(mensagens);
        } else {
            res.status(404).json({ message: 'Nenhuma mensagem encontrada para este fórum' });
        }
    } catch (error) {
        console.error('Erro ao listar mensagens do fórum:', error);
        res.status(500).json({ error: 'Erro ao listar mensagens do fórum' });
    }
};

// Buscar uma mensagem específica por ID
mensagemForumController.detail = async (req, res) => {
    const { id } = req.params;

    try {
        const mensagem = await MensagemForum.findByPk(id, {
            include: [
                {
                    model: Usuario,
                    as: 'usuario',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                },
                {
                    model: Forum,
                    as: 'forum',
                    attributes: ['id', 'area_id']
                }
            ]
        });

        if (mensagem) {
            res.json(mensagem);
        } else {
            res.status(404).json({ error: 'Mensagem não encontrada' });
        }
    } catch (error) {
        console.error('Erro ao buscar mensagem:', error);
        res.status(500).json({ error: 'Erro ao buscar mensagem' });
    }
};

// Atualizar uma mensagem
mensagemForumController.update = async (req, res) => {
    const { id } = req.params;

    try {
        const [updated] = await MensagemForum.update(req.body, {
            where: { id }
        });

        if (updated) {
            res.json({ message: 'Mensagem atualizada com sucesso' });
        } else {
            res.status(404).json({ error: 'Mensagem não encontrada' });
        }
    } catch (error) {
        console.error('Erro ao atualizar mensagem:', error);
        res.status(500).json({ error: 'Erro ao atualizar mensagem' });
    }
};

// Excluir uma mensagem
mensagemForumController.delete = async (req, res) => {
    const { id } = req.params;

    try {
        // Primeiro, excluir todas as denúncias relacionadas à mensagem
        await DenunciaMensagemForum.destroy({
            where: { mensagem_forum_id: id }
        });

        // Em seguida, excluir a mensagem do fórum
        const deleted = await MensagemForum.destroy({
            where: { id }
        });

        if (deleted) {
            res.json({ message: 'Mensagem excluída com sucesso' });
        } else {
            res.status(404).json({ error: 'Mensagem não encontrada' });
        }
    } catch (error) {
        console.error('Erro ao excluir mensagem:', error);
        res.status(500).json({ error: 'Erro ao excluir mensagem' });
    }
};

mensagemForumController.countByArea = async (req, res) => {
    const { areaId } = req.params; // Obtém o ID da área a partir dos parâmetros da requisição
    try {
      // Faz a contagem de mensagens de fórum associadas à área
      const count = await MensagemForum.count({
        include: [{
          model: Forum, // Faz o join com a tabela de fóruns
          as: 'forum',
          where: {
            area_id: areaId // Filtra os fóruns pela área
          }
        }]
      });
  
      // Retorna a contagem das mensagens
      res.json({ areaId, totalMensagens: count });
    } catch (error) {
      console.error('Erro ao contar mensagens de fórum por área:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  };

module.exports = mensagemForumController;
