const LikeComentarioAlbum = require('../models/likes_comentarios_albuns');
const ComentarioAlbum = require('../models/comentarios_albuns');
const User = require('../models/user');

const likesComentariosAlbunsController = {};

// Criar um like em um comentário de um álbum
likesComentariosAlbunsController.create = async (req, res) => {
    const { comentario_album_id, user_id } = req.body;

    try {
        // Verifica se o like já existe para evitar duplicação
        const existingLike = await LikeComentarioAlbum.findOne({
            where: { comentario_album_id, user_id }
        });

        if (existingLike) {
            return res.status(400).json({ error: 'Você já curtiu este comentário.' });
        }

        // Criar o registro de like
        await LikeComentarioAlbum.create({
            comentario_album_id,
            user_id,
            like: true
        });

        // Incrementar o número de likes no comentário
        const comentario = await ComentarioAlbum.findByPk(comentario_album_id);
        comentario.likes += 1;  // Assumindo que o campo `likes` existe no modelo de `ComentarioAlbum`
        await comentario.save();

        res.status(201).json({ message: 'Like adicionado com sucesso.', likes: comentario.likes });
    } catch (error) {
        console.error('Erro ao criar like no comentário do álbum:', error);
        res.status(500).json({ error: 'Erro ao criar like no comentário do álbum' });
    }
};

// Remover um like de um comentário de um álbum
likesComentariosAlbunsController.delete = async (req, res) => {
    const { comentario_album_id, user_id } = req.body;

    try {
        const like = await LikeComentarioAlbum.findOne({
            where: { comentario_album_id, user_id }
        });

        if (!like) {
            return res.status(404).json({ error: 'Like não encontrado.' });
        }

        await LikeComentarioAlbum.destroy({
            where: { comentario_album_id, user_id }
        });

        // Decrementar o número de likes no comentário
        const comentario = await ComentarioAlbum.findByPk(comentario_album_id);
        comentario.likes -= 1;
        await comentario.save();

        res.json({ message: 'Like removido com sucesso.', likes: comentario.likes });
    } catch (error) {
        console.error('Erro ao remover like no comentário do álbum:', error);
        res.status(500).json({ error: 'Erro ao remover like no comentário do álbum' });
    }
};

// Verificar se um usuário curtiu um comentário de um álbum
likesComentariosAlbunsController.checkLike = async (req, res) => {
    const { comentario_album_id, user_id } = req.query;

    try {
        const like = await LikeComentarioAlbum.findOne({
            where: { comentario_album_id, user_id }
        });

        if (!like) {
            return res.status(404).json({ liked: false });
        }

        res.json({ liked: true });
    } catch (error) {
        console.error('Erro ao verificar like no comentário do álbum:', error);
        res.status(500).json({ error: 'Erro ao verificar like no comentário do álbum' });
    }
};

module.exports = likesComentariosAlbunsController;
