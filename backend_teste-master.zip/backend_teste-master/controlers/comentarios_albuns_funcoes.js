const ComentariosAlbuns = require('../models/comentarios_albuns');
const User = require('../models/user');
const Albuns = require('../models/albuns');
const comentariosAlbunsController = {};
const notificacaoController = require('../controlers/notificacoes_funcoes'); 
const GaleriaAlbum=require('../models/galeria_album');
// Criar um comentário em um álbum
comentariosAlbunsController.create = async (req, res) => {
    const { album_id, user_id, texto_comentario, classificacao } = req.body;

    try {
        if (classificacao > 0) {
            await ComentariosAlbuns.update(
                { classificacao },
                { where: { album_id, user_id } }
            );
        }

        const comentarioAlbum = await ComentariosAlbuns.create({
            album_id,
            user_id,
            texto_comentario,
            classificacao,
            data_comentario: new Date() 
        });

        const album = await Albuns.findByPk(album_id);
        if (!album) {
            return res.status(404).json({ error: 'Álbum não encontrado' });
        }

        // Aqui você pode enviar notificações, se necessário

        res.status(201).json({
            message: "Comentário feito com sucesso",
            comentario: comentarioAlbum
        });
    } catch (error) {
        console.error('Erro ao criar comentário de álbum:', error);
        res.status(500).json({ error: 'Erro ao criar comentário de álbum' });
    }
};

comentariosAlbunsController.createComentarioGaleriaAPP = async (req, res) => {
    const { user_id, texto_comentario, data_comentario, id_galeria } = req.body;

    try {
        // Verificar se a galeria existe
        const galeria = await GaleriaAlbum.findByPk(id_galeria);
        if (!galeria) {
            return res.status(404).json({ error: 'Galeria não encontrada' });
        }
        const album_id = galeria.area_id;
        // Criar o comentário associado à galeria
        const comentarioGaleria = await ComentariosAlbuns.create({
            user_id,
            texto_comentario,
            data_comentario: data_comentario || new Date(), // Usar a data fornecida ou a data atual
            id_galeria ,
            album_id
        });

        res.status(201).json({
            message: "Comentário adicionado com sucesso à galeria",
            comentario: comentarioGaleria
        });
    } catch (error) {
        console.error('Erro ao criar comentário de galeria:', error);
        res.status(500).json({ error: 'Erro ao criar comentário de galeria' });
    }
};

// Listar comentários de um álbum específico
comentariosAlbunsController.listarComentariosPorAlbum = async (req, res) => {
    const { album_id } = req.params;

    try {
        const comentarios = await ComentariosAlbuns.findAll({
            where: { album_id },
            include: [
                {
                    model: User,
                    as: 'usuario',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                },
                {
                    model: Albuns,
                    as: 'album',
                    attributes: ['id', 'nome']
                }
            ]
        });
        res.json(comentarios);
    } catch (error) {
        console.error('Erro ao listar comentários do álbum:', error);
        res.status(500).json({ error: 'Erro ao buscar comentários do álbum' });
    }
};
comentariosAlbunsController.listarComentariosPorGaleriaAPP = async (req, res) => {
    const { id_galeria } = req.params; // Substitua por id_galeria

    try {
        const comentarios = await ComentariosAlbuns.findAll({
            where: { id_galeria },  // Usar id_galeria para filtrar os comentários
            include: [
                {
                    model: User,
                    as: 'usuario',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                },
                {
                    model: Albuns,
                    as: 'album',
                    attributes: ['id', 'nome']
                }
            ]
        });
        res.json(comentarios);
    } catch (error) {
        console.error('Erro ao listar comentários da galeria:', error);
        res.status(500).json({ error: 'Erro ao buscar comentários da galeria' });
    }
};

// Detalhe de um comentário específico
comentariosAlbunsController.detail = async (req, res) => {
    const { id } = req.params;

    try {
        const comentario = await ComentariosAlbuns.findByPk(id, {
            include: [
                {
                    model: User,
                    as: 'usuario',
                    attributes: ['nome', 'sobrenome']
                }
            ]
        });

        if (comentario) {
            res.json(comentario);
        } else {
            res.status(404).json({ error: 'Comentário de álbum não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao obter detalhes do comentário do álbum:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Atualizar um comentário de álbum
comentariosAlbunsController.update = async (req, res) => {
    const { id } = req.params;
    const { texto_comentario, classificacao } = req.body;

    try {
        const [updated] = await ComentariosAlbuns.update({
            texto_comentario,
            classificacao
        }, {
            where: { id }
        });

        if (updated) {
            res.json({ message: 'Comentário de álbum atualizado com sucesso' });
        } else {
            res.status(404).json({ error: 'Comentário de álbum não encontrado para atualizar' });
        }
    } catch (error) {
        console.error('Erro ao atualizar comentário de álbum:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

const LikesComentariosAlbuns = require('../models/likes_comentarios_albuns'); // Importe o modelo de Likes de Comentários de Álbum
const DenunciasComentariosAlbuns = require('../models/denuncias_comentarios_de_albuns'); // Importe o modelo de Denúncias de Comentários de Álbum

// Deletar um comentário de álbum
comentariosAlbunsController.delete = async (req, res) => {
    const { id } = req.params;

    try {
        // Primeiro, deletar os likes associados ao comentário do álbum
        await LikesComentariosAlbuns.destroy({ where: { comentario_album_id: id } });

        // Depois, deletar as denúncias associadas ao comentário do álbum
        await DenunciasComentariosAlbuns.destroy({ where: { id_comentario_denunciado: id } });

        // Agora, deletar o próprio comentário do álbum
        const deleted = await ComentariosAlbuns.destroy({ where: { id } });

        if (deleted) {
            res.json({ message: 'Comentário de álbum excluído com sucesso' });
        } else {
            res.status(404).json({ error: 'Comentário de álbum não encontrado para exclusão' });
        }
    } catch (error) {
        console.error('Erro ao deletar comentário de álbum:', error);
        res.status(500).json({ error: 'Erro interno ao tentar deletar comentário' });
    }
};


// Listar comentários de todos os álbuns de um centro
comentariosAlbunsController.listarComentariosPorCentro = async (req, res) => {
    const { centro_id } = req.params;

    try {
        const albuns = await Albuns.findAll({
            where: { centro_id },
            include: [{
                model: ComentariosAlbuns,
                as: 'comentarios',
                include: [{
                    model: User,
                    as: 'usuario',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                }]
            }]
        });

        const comentarios = albuns.flatMap(album =>
            album.comentarios.map(comentario => ({
                ...comentario.dataValues,
                album: {
                    id: album.id,
                    nome: album.nome
                },
                usuario: comentario.usuario
            }))
        );

        if (comentarios.length > 0) {
            res.json(comentarios);
        } else {
            res.status(404).json({ error: 'Nenhum comentário encontrado para o centro especificado' });
        }
    } catch (error) {
        console.error('Erro ao listar comentários por centro:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Listar comentários de álbuns por centro e autor
comentariosAlbunsController.listarComentariosPorCentroEAutor = async (req, res) => {
    const { centro_id, autor_id } = req.params;

    try {
        const albunsCentro = await Albuns.findAll({
            where: { centro_id },
            include: [{
                model: ComentariosAlbuns,
                as: 'comentarios',
                include: [{
                    model: User,
                    as: 'usuario',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                }]
            }]
        });

        const albunsAutor = await Albuns.findAll({
            where: { autor_id },
            include: [{
                model: ComentariosAlbuns,
                as: 'comentarios',
                include: [{
                    model: User,
                    as: 'usuario',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                }]
            }]
        });

        const comentariosMap = new Map();

        albunsCentro.forEach(album => {
            album.comentarios.forEach(comentario => {
                comentariosMap.set(comentario.id, {
                    ...comentario.dataValues,
                    album: { id: album.id, nome: album.nome },
                    usuario: comentario.usuario
                });
            });
        });

        albunsAutor.forEach(album => {
            album.comentarios.forEach(comentario => {
                comentariosMap.set(comentario.id, {
                    ...comentario.dataValues,
                    album: { id: album.id, nome: album.nome },
                    usuario: comentario.usuario
                });
            });
        });

        const resultadoFinal = Array.from(comentariosMap.values());

        if (resultadoFinal.length > 0) {
            res.json(resultadoFinal);
        } else {
            res.status(404).json({ message: 'Nenhum comentário encontrado para este centro ou autor' });
        }
    } catch (error) {
        console.error('Erro ao listar comentários por centro e autor:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao listar comentários' });
    }
};

// Obter a média das avaliações de um álbum
comentariosAlbunsController.obterMediaAvaliacoes = async (req, res) => {
    const { album_id } = req.params;

    try {
        const comentarios = await ComentariosAlbuns.findAll({
            where: { album_id },
            include: [{ model: User, as: 'usuario', attributes: ['id'] }]
        });

        const avaliacaoPorUsuario = new Map();

        comentarios.forEach(comentario => {
            avaliacaoPorUsuario.set(comentario.usuario.id, comentario.classificacao);
        });

        const avaliacoes = Array.from(avaliacaoPorUsuario.values()).filter(c => c > 0);
        const totalAvaliacoes = avaliacoes.length;
        const somaAvaliacoes = avaliacoes.reduce((acc, val) => acc + val, 0);
        const media = totalAvaliacoes > 0 ? somaAvaliacoes / totalAvaliacoes : 0;

        res.json({ media, total: totalAvaliacoes });
    } catch (error) {
        console.error('Erro ao calcular a média das avaliações:', error);
        res.status(500).json({ error: 'Erro ao calcular a média das avaliações' });
    }
};

module.exports = comentariosAlbunsController;
