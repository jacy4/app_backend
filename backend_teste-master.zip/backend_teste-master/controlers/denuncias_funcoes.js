const Denuncia = require('../models/denuncias');
const ComentarioPublicacao = require('../models/comentarios'); // Importar o modelo de comentário
const User = require('../models/user');
const Publicacao = require('../models/publicacoes');
const denunciaController = {};

// Criar uma nova denúncia
denunciaController.create = async (req, res) => {
  const { comentario_publicacao_id, denunciante_id, motivo, informacao_adicional } = req.body;
  
  try {
    const denuncia = await Denuncia.create({
      comentario_publicacao_id,
      denunciante_id,
      motivo,
      informacao_adicional,
      resolvida: false,
      createdat: new Date()
    });

    // Buscar o comentário associado ao comentario_publicacao_id
    const comentario = await ComentarioPublicacao.findByPk(comentario_publicacao_id);

    // Se o comentário foi encontrado, atualize o estado da publicação associada
    if (comentario) {
      await Publicacao.update(
        { estado: 'Denunciada' },  // Atualiza o campo estado para 'Denunciada'
        { where: { id: comentario.publicacao_id } }  // Usa o publicacao_id do comentário
      );
    }


    
    res.status(201).json(denuncia);
  } catch (error) {
    console.error('Erro ao criar denúncia:', error);
    res.status(500).json({ error: 'Erro ao criar denúncia' });
  }
};

// Listar denúncias por publicação
denunciaController.listarDenuncias = async (req, res) => {
  try {
    // console.log('Publicacao ID:', req.params.publicacaoId); // Log para ver o ID da publicação
    const denuncias = await Denuncia.findAll({
      include: [
        {
          model: ComentarioPublicacao,
          attributes: ['id', 'conteudo'], // Inclua os atributos que deseja dos comentários
          where: { publicacao_id: req.params.publicacaoId }, // Filtra por ID da publicação
          required: true // Garante que somente as denúncias de comentários associados à publicação sejam retornadas
        },
        {
          model: User,
          as: 'denunciante',
          attributes: ['id', 'nome', 'sobrenome','caminho_foto']
        }
      ]
    });
    
    
    res.json(denuncias);
  } catch (error) {
    console.error('Erro ao buscar denúncias:', error); // Log do erro completo
    res.status(500).json({ error: 'Erro ao buscar denúncias' });
  }
};

// Buscar uma denúncia por ID
denunciaController.detail = async (req, res) => {
  try {
    const denuncia = await Denuncia.findByPk(req.params.id, {
      include: [
        {
          model: User,
          as: 'denunciante',
          attributes: ['id', 'nome', 'sobrenome','caminho_foto']
        },
        {
          model: ComentarioPublicacao, // Alterar para referenciar ComentarioPublicacao
          attributes: ['id', 'conteudo'] // Exemplo de atributo, altere conforme necessário
        }
      ]
    });
    if (denuncia) {
      res.json(denuncia);
    } else {
      res.status(404).json({ error: 'Denúncia não encontrada' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar denúncia' });
  }
};

// Atualizar uma denúncia
denunciaController.update = async (req, res) => {
  try {
    await Denuncia.update(req.body, { where: { id: req.params.id } });
    res.json({ message: 'Denúncia atualizada com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao atualizar denúncia' });
  }
};

// Excluir uma denúncia
denunciaController.delete = async (req, res) => {
  try {
    await Denuncia.destroy({ where: { id: req.params.id } });
    res.json({ message: 'Denúncia excluída com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao excluir denúncia' });
  }
};

module.exports = denunciaController;
