const ComentariosPublicacoes = require('../models/comentarios');
const User = require('../models/user');
const Publicacao = require('../models/publicacoes');
const comentariosPublicacoesController = {};
const notificacaoController = require('../controlers/notificacoes_funcoes');
const LikeComentarioPublicacao = require('../models/likes_comentarios_publicacoes');

// Criar um comentário em uma publicação
comentariosPublicacoesController.create = async (req, res) => {
    const { publicacao_id, user_id, conteudo, classificacao } = req.body;

    try {
        if (classificacao > 0) {
            await ComentariosPublicacoes.update(
                { classificacao },
                { where: { publicacao_id, user_id } }
            );
        }

        const comentarioPublicacao = await ComentariosPublicacoes.create({
            publicacao_id,
            user_id,
            conteudo,
            classificacao,
            data_comentario: new Date()
        });

        const publicacao = await Publicacao.findByPk(publicacao_id);
        if (!publicacao) {
            return res.status(404).json({ error: 'Publicação não encontrada' });
        }

        // Notificar autor da publicação
        const reqNotificacao = {
            body: {
                usuario_id: publicacao.autor_id,
                tipo: 'Novo Comentário em sua Publicação',
                mensagem: `Um novo comentário foi adicionado à sua publicação "${publicacao.titulo}". Confira agora!`,
            }
        };

        const notificacao = await notificacaoController.create(reqNotificacao);

        res.status(201).json({
            message: "Comentário feito com sucesso e notificação enviada",
            comentario: comentarioPublicacao,
            notificacao
        });
    } catch (error) {
        console.error('Erro ao criar comentário na publicação:', error);
        res.status(500).json({ error: 'Erro ao criar comentário na publicação' });
    }
};

// Listar comentários de uma publicação específica
comentariosPublicacoesController.listarComentariosPorPublicacao = async (req, res) => {
    const { publicacao_id } = req.params;

    try {
        const comentarios = await ComentariosPublicacoes.findAll({
            where: { publicacao_id },
            include: [
                {
                    model: User,
                    as: 'usuario', // Use 'autor' conforme definido na associação
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                },
                {
                    model: Publicacao,
                    as: 'publicacao', // Use 'publicacao' conforme definido na associação
                    attributes: ['id', 'titulo']
                }
            ]
        });
        res.json(comentarios);
    } catch (error) {
        console.error('Erro ao listar comentários da publicação:', error);
        res.status(500).json({ error: 'Erro ao buscar comentários da publicação' });
    }
};

// Detalhe de um comentário específico
comentariosPublicacoesController.detail = async (req, res) => {
    const { id } = req.params;

    try {
        const comentario = await ComentariosPublicacoes.findByPk(id, {
            include: [
                {
                    model: User,
                    as: 'user',
                    attributes: ['nome', 'sobrenome']
                }
            ]
        });

        if (comentario) {
            res.json(comentario);
        } else {
            res.status(404).json({ error: 'Comentário da publicação não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao obter detalhes do comentário da publicação:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Atualizar um comentário de publicação
comentariosPublicacoesController.update = async (req, res) => {
    const { id } = req.params;
    const { conteudo, classificacao } = req.body;

    try {
        const [updated] = await ComentariosPublicacoes.update({
            conteudo,
            classificacao
        }, {
            where: { id }
        });

        if (updated) {
            res.json({ message: 'Comentário da publicação atualizado com sucesso' });
        } else {
            res.status(404).json({ error: 'Comentário da publicação não encontrado para atualização' });
        }
    } catch (error) {
        console.error('Erro ao atualizar comentário da publicação:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Excluir um comentário de publicação
comentariosPublicacoesController.delete = async (req, res) => {
  const { id } = req.params;

  try {
      // Primeiro, excluir todos os likes associados a este comentário
      await LikeComentarioPublicacao.destroy({ where: { comentario_publicacao_id: id } });

      // Em seguida, excluir o comentário
      const deleted = await ComentariosPublicacoes.destroy({ where: { id } });

      if (deleted) {
          res.json({ message: 'Comentário da publicação excluído com sucesso' });
      } else {
          res.status(404).json({ error: 'Comentário da publicação não encontrado para exclusão' });
      }
  } catch (error) {
      console.error('Erro ao deletar comentário da publicação:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
  }
};


// Listar comentários de todas as publicações de um centro específico
comentariosPublicacoesController.listarComentariosPorCentro = async (req, res) => {
    const { centro_id } = req.params;

    try {
        const publicacoes = await Publicacao.findAll({
            where: { centro_id },
            include: [{
                model: ComentariosPublicacoes,
                as: 'comentarios',
                include: [{
                    model: User,
                    as: 'usuario',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                }]
            }]
        });

        const comentarios = publicacoes.flatMap(publicacao => 
            publicacao.comentarios.map(comentario => ({
                ...comentario.dataValues,
                publicacao: {
                    id: publicacao.id,
                    titulo: publicacao.titulo
                },
                autor: comentario.autor
            }))
        );

        if (comentarios.length > 0) {
            res.json(comentarios);
        } else {
            res.status(404).json({ error: 'Nenhum comentário encontrado para o centro especificado' });
        }
    } catch (error) {
        console.error('Erro ao listar comentários por centro:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Listar comentários de publicações de um centro específico e um autor específico
comentariosPublicacoesController.listarComentariosPorCentroEAutor = async (req, res) => {
    const { centro_id, user_id } = req.params;

    try {
        const publicacoesCentro = await Publicacao.findAll({
            where: { centro_id },
            include: [{
                model: ComentariosPublicacoes,
                as: 'comentarios',
                include: [{
                    model: User,
                    as: 'usuario',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                }]
            }]
        });

        const publicacoesAutor = await Publicacao.findAll({
            where: { autor_id: user_id },
            include: [{
                model: ComentariosPublicacoes,
                as: 'comentarios',
                include: [{
                    model: User,
                    as: 'usuario',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                }]
            }]
        });

        const comentariosMap = new Map();

        publicacoesCentro.forEach(publicacao => {
            publicacao.comentarios.forEach(comentario => {
                comentariosMap.set(comentario.id, {
                    ...comentario.dataValues,
                    publicacao: { id: publicacao.id, titulo: publicacao.titulo },
                    usuario: comentario.usuario
                });
            });
        });

        publicacoesAutor.forEach(publicacao => {
            publicacao.comentarios.forEach(comentario => {
                comentariosMap.set(comentario.id, {
                    ...comentario.dataValues,
                    publicacao: { id: publicacao.id, titulo: publicacao.titulo },
                    usuario: comentario.usuario
                });
            });
        });

        const resultadoFinal = Array.from(comentariosMap.values());

        if (resultadoFinal.length > 0) {
            res.json(resultadoFinal);
        } else {
            res.status(404).json({ message: 'Nenhum comentário encontrado para este centro ou autor' });
        }
    } catch (error) {
        console.error('Erro ao listar comentários por centro e autor:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao listar comentários' });
    }
};

// Obter a média das avaliações de uma publicação
comentariosPublicacoesController.obterMediaAvaliacoes = async (req, res) => {
    const { publicacao_id } = req.params;

    try {
        const comentarios = await ComentariosPublicacoes.findAll({
            where: { publicacao_id },
            include: [{ model: User, as: 'usuario', attributes: ['id'] }]
        });

        const avaliacaoPorUsuario = new Map();

        comentarios.forEach(comentario => {
            avaliacaoPorUsuario.set(comentario.usuario.id, comentario.classificacao);
        });

        const avaliacoes = Array.from(avaliacaoPorUsuario.values()).filter(c => c > 0);
        const totalAvaliacoes = avaliacoes.length;
        const somaAvaliacoes = avaliacoes.reduce((acc, val) => acc + val, 0);
        const media = totalAvaliacoes > 0 ? somaAvaliacoes / totalAvaliacoes : 0;

        res.json({ media, total: totalAvaliacoes });
    } catch (error) {
        console.error('Erro ao calcular a média das avaliações:', error);
        res.status(500).json({ error: 'Erro ao calcular a média das avaliações' });
    }
};

module.exports = comentariosPublicacoesController;
