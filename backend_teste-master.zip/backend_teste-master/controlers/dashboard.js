const dashboardController = {};
const Eventos = require('../models/eventos');
const Topico = require('../models/topicos');
const User = require('../models/user');
const Area = require('../models/areas'); 
const Foruns = require('../models/forum'); 
const Grupos = require('../models/grupos'); 
const Publicacoes = require('../models/publicacoes'); 


dashboardController.getModelCounts = async (req, res) => {
    try {
        
      const models = [
        { name: "Eventos", model: Eventos },
        { name: "Tópicos", model: Topico },
        { name: "Users", model: User },
        { name: "Áreas", model: Area },
        { name: "FÓruns", model: Foruns },
        { name: "Grupos", model: Grupos },
        { name: "Publicações", model: Publicacoes }
      ];
  
      const modelNames = [];
      const modelCounts = [];
  
      for (const entry of models) {
        const count = await entry.model.count(); 
        modelNames.push(entry.name); 
        modelCounts.push(count); 
      }
  
      res.json({ labels: modelNames, values: modelCounts });
  
    } catch (error) {
      console.error('Erro ao obter contagem de models:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  };
  
  module.exports = dashboardController;