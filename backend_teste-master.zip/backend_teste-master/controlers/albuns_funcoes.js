const Album = require('../models/albuns'); // Importe o modelo Albuns
const Area = require('../models/areas'); // Importe o modelo Area
const User = require('../models/user'); // Importe o modelo User


const GaleriaAlbum = require('../models/galeria_album');
const ComentariosAlbuns = require('../models/comentarios_albuns');
const LikeComentarioAlbum = require('../models/likes_comentarios_albuns');
const DenunciasComentariosAlbuns = require('../models/denuncias_comentarios_de_albuns'); // Supondo que você tenha uma galeria de imagens do álbum
const albumController = {};

// Listar todos os álbuns de uma área específica
albumController.listByArea = async (req, res) => {
    const { areaId } = req.params;
  
    try {
      const albuns = await Album.findAll({
        where: { area_id: areaId },
        include: [
          { model: Area, as: 'area', attributes: ['id', 'nome'] },
          { model: User, as: 'autor', attributes: ['id', 'nome', 'sobrenome', 'caminho_foto'] }
        ]
      });
  
      if (albuns.length > 0) {
        res.json(albuns);
      } else {
        res.status(404).json({ error: 'Nenhum álbum encontrado para esta área' });
      }
    } catch (error) {
      console.error('Erro ao listar álbuns por área:', error);
      res.status(500).json({ error: 'Erro ao listar álbuns' });
    }
  };
  

albumController.listarpartilhasporcentroAPP = async (req, res) => {
  try {
    const { centroId } = req.params; // Pegando o ID do centro da requisição

    // Buscar todas as partilhas relacionadas ao centro
    const partilhas = await Album.findAll({
      where: { centro_id: centroId },
      include: [
        { model: User, as: 'autor', attributes: ['id', 'nome'] },
        { model: Area, as: 'area', attributes: ['id', 'nome'] }
      ]
    });

    if (partilhas.length === 0) {
      return res.status(404).json({ message: 'Nenhuma partilha encontrada para o centro.' });
    }

    // Enviar a resposta como JSON
    res.status(200).json(partilhas);
  } catch (error) {
    console.error('Erro ao buscar as partilhas:', error);
    res.status(500).json({ error: 'Erro ao buscar as partilhas.' });
  }
};
 

// Criar um novo álbum
albumController.create = async (req, res) => {
  const { nome, descricao, capa_imagem_album, centro_id, area_id, autor_id, estado } = req.body;

  try {
    const novoAlbum = await Album.create({
      nome,
      descricao,
      capa_imagem_album,
      centro_id,
      area_id,
      autor_id,
      estado
    });

    res.status(201).json(novoAlbum);
  } catch (error) {
    console.error('Erro ao criar álbum:', error);
    res.status(500).json({ error: 'Erro ao criar álbum' });
  }
};

// Listar todos os álbuns
albumController.list = async (req, res) => {
  const { centroId } = req.params;
  try {
    const albuns = await Album.findAll({
      where: { centro_id: centroId },
      include: [
        { model: Area, as: 'area', attributes: ['id', 'nome'] },
        { model: User, as: 'autor', attributes: ['id', 'nome', 'sobrenome'] }
      ]
    });

    res.json(albuns);
  } catch (error) {
    console.error('Erro ao listar álbuns:', error);
    res.status(500).json({ error: 'Erro ao listar álbuns' });
  }
};

// Obter detalhes de um álbum específico
albumController.detail = async (req, res) => {
  const { id } = req.params;

  try {
    const album = await Album.findByPk(id, {
      include: [
        { model: Area, as: 'area', attributes: ['id', 'nome'] },
        { model: User, as: 'autor', attributes: ['id', 'nome', 'sobrenome'] },
        // { model: GaleriaAlbum, as: 'imagens', attributes: ['caminho_imagem'] } // Supondo que há uma galeria de imagens
      ]
    });

    if (album) {
      res.json(album);
    } else {
      res.status(404).json({ error: 'Álbum não encontrado' });
    }
  } catch (error) {
    console.error('Erro ao obter detalhes do álbum:', error);
    res.status(500).json({ error: 'Erro ao obter detalhes do álbum' });
  }
};

// Atualizar um álbum
albumController.update = async (req, res) => {
  const { id } = req.params;
  const { nome, descricao, capa_imagem_album, area_id } = req.body;

  try {
    const [updated] = await Album.update(
      { nome, descricao, capa_imagem_album, area_id },
      { where: { id } }
    );

    if (updated) {
      const albumAtualizado = await Album.findByPk(id);
      res.json(albumAtualizado);
    } else {
      res.status(404).json({ error: 'Álbum não encontrado' });
    }
  } catch (error) {
    console.error('Erro ao atualizar álbum:', error);
    res.status(500).json({ error: 'Erro ao atualizar álbum' });
  }
};



// Excluir um álbum
albumController.delete = async (req, res) => {
  const { id } = req.params;

  try {
    // Buscar todas as mensagens/comentários associados ao álbum
    const comentarios = await ComentariosAlbuns.findAll({ where: { album_id: id } });

    if (comentarios.length > 0) {
      // Para cada comentário, excluir os likes associados
      for (let comentario of comentarios) {
        await LikeComentarioAlbum.destroy({ where: { comentario_album_id: comentario.id } });

        // Excluir todas as denúncias associadas ao comentário
        await DenunciasComentariosAlbuns.destroy({ where: { comentario_album_id: comentario.id } });
      }

      // Depois, excluir todos os comentários associados ao álbum
      await ComentariosAlbuns.destroy({ where: { album_id: id } });
    }

    // Deletar todas as imagens da galeria associadas ao álbum
    await GaleriaAlbum.destroy({ where: { album_id: id } });

    // Por fim, excluir o álbum
    const deleted = await Album.destroy({
      where: {
        id
      }
    });

    if (deleted) {
      res.json({ message: 'Álbum excluído com sucesso' });
    } else {
      res.status(404).json({ error: 'Álbum não encontrado' });
    }
  } catch (error) {
    console.error('Erro ao excluir álbum:', error);
    res.status(500).json({ error: 'Erro ao excluir álbum' });
  }
};


module.exports = albumController;
