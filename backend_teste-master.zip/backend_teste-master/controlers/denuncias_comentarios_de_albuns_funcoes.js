const DenunciasComentariosDeAlbuns = require('../models/denuncias_comentarios_de_albuns');
const ComentariosAlbuns = require('../models/comentarios_albuns');
const User = require('../models/user');
const Album = require('../models/albuns'); // Certifique-se de que o caminho está correto
const denunciasComentariosAlbunsController = {};

// Criar uma denúncia de comentário de álbum
denunciasComentariosAlbunsController.create = async (req, res) => {
    const { id_comentario_denunciado, resolvida, id_album, id_denunciador, motivo_denuncia, descricao_denuncia } = req.body;

    try {
        const denuncia = await DenunciasComentariosDeAlbuns.create({
            id_comentario_denunciado,
            resolvida,
            id_album,
            id_denunciador,
            motivo_denuncia,
            descricao_denuncia,
            data_denuncia: new Date() // Ou usar defaultValue no modelo
        });
        
        await Album.update(
            { estado: 'Denunciada' },  // Atualiza o campo estado para 'Denunciada'
            { where: { id: id_album } }  // Atualiza o álbum associado à denúncia
        );

        res.status(201).json({
            message: "Denúncia de comentário de álbum criada com sucesso",
            denuncia: denuncia
        });
    } catch (error) {
        console.error('Erro ao criar denúncia de comentário de álbum:', error);
        res.status(500).json({ error: 'Erro ao criar denúncia' });
    }
};

// Listar denúncias de comentários de um álbum específico
denunciasComentariosAlbunsController.listarDenunciasDeAlbum = async (req, res) => {
    const { id_album } = req.params;

    try {
        const denuncias = await DenunciasComentariosDeAlbuns.findAll({
            where: { id_album },
            include: [
                {
                    model: ComentariosAlbuns,
                    as: 'comentario_denunciado',
                    attributes: ['id', 'texto_comentario', 'classificacao']
                },
                {
                    model: User,
                    as: 'denunciador',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                }
            ]
        });

        if (denuncias.length > 0) {
            res.json(denuncias);
        } else {
            res.status(404).json({ error: 'Nenhuma denúncia encontrada para o álbum especificado' });
        }
    } catch (error) {
        console.error('Erro ao listar denúncias do álbum:', error);
        res.status(500).json({ error: 'Erro ao buscar denúncias do álbum' });
    }
};

// Excluir uma denúncia de comentário de álbum
denunciasComentariosAlbunsController.deleteDenuncia = async (req, res) => {
    const { id } = req.params;

    try {
        const deleted = await DenunciasComentariosDeAlbuns.destroy({ where: { id } });
        if (deleted) {
            res.json({ message: 'Denúncia excluída com sucesso' });
        } else {
            res.status(404).json({ error: 'Denúncia não encontrada para exclusão' });
        }
    } catch (error) {
        console.error('Erro ao deletar denúncia:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Atualizar uma denúncia de comentário de álbum
denunciasComentariosAlbunsController.update = async (req, res) => {
    try {
        await DenunciasComentariosDeAlbuns.update(req.body, { where: { id: req.params.id } });
        res.json({ message: 'Denúncia de comentário de álbum atualizada com sucesso' });
    } catch (error) {
        console.error('Erro ao atualizar denúncia de comentário de álbum:', error);
        res.status(500).json({ error: 'Erro ao atualizar denúncia de comentário de álbum' });
    }
};

// Excluir todas as denúncias de um álbum específico
denunciasComentariosAlbunsController.deleteAllDenunciasDeAlbum = async (req, res) => {
    const { id_album } = req.params;

    try {
        const deleted = await DenunciasComentariosDeAlbuns.destroy({ where: { id_album } });
        if (deleted) {
            res.json({ message: 'Todas as denúncias do álbum foram excluídas com sucesso' });
        } else {
            res.status(404).json({ error: 'Nenhuma denúncia encontrada para o álbum especificado' });
        }
    } catch (error) {
        console.error('Erro ao deletar denúncias do álbum:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

module.exports = denunciasComentariosAlbunsController;
