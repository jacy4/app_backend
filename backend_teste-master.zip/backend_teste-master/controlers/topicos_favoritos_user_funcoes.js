const TopicosFavoritosUser = require('../models/topicos_favoritos_user');
const User = require('../models/user');
const Topico = require('../models/topicos');

const topicosFavoritosController = {};

topicosFavoritosController.create = async (req, res) => {
    const { usuario_id, topico_id } = req.body;

    try {
        // Verifica se o usuário e o tópico existem
        const userExists = await User.findByPk(usuario_id);
        const topicoExists = await Topico.findByPk(topico_id);

        if (!userExists || !topicoExists) {
            return res.status(404).json({ message: 'Usuário ou tópico não encontrados' });
        }

        // Verifica se a combinação já existe (para evitar duplicatas)
        const alreadyFavorite = await TopicosFavoritosUser.findOne({
            where: { usuario_id, topico_id }
        });

        if (alreadyFavorite) {
            return res.status(400).json({ message: 'O tópico já está definido como favorito para este usuário.' });
        }

        // Cria o registro na tabela topicos_favoritos_user
        await TopicosFavoritosUser.create({ usuario_id, topico_id });

        // Responde com uma mensagem de sucesso
        res.status(201).json({ message: 'Tópico definido como favorito com sucesso.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Erro ao adicionar tópico favorito.' });
    }
};


topicosFavoritosController.list = async (req, res) => {
    const { usuario_id } = req.params;

    try {
        // Verifica se o usuário existe
        const userExists = await User.findByPk(usuario_id);

        if (!userExists) {
            return res.status(404).json({ message: 'Usuário não encontrado' });
        }

        // Consulta para buscar os tópicos favoritos do usuário
        const favoriteTopicos = await User.findOne({
            where: { id: usuario_id },
            attributes: ['id'], // Retorna apenas o id do usuário
            include: [{
                model: Topico,
                as: 'topicos_favoritos',
                attributes: ['id', 'nome']
            }]
        });

        // Verifica se o usuário possui tópicos favoritos
        if (!favoriteTopicos || favoriteTopicos.topicos_favoritos.length === 0) {
            return res.status(200).json({ message: 'Usuário não tem tópicos favoritos.' });
        }

        res.status(200).json(favoriteTopicos);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Erro ao listar tópicos favoritos.' });
    }
};

topicosFavoritosController.listAll = async (req, res) => {
    try {
        // Consulta todas as linhas da tabela topicos_favoritos_user
        const allFavoriteTopicos = await TopicosFavoritosUser.findAll({
            attributes: ['id', 'usuario_id', 'topico_id'], // Seleciona apenas os atributos desejados
        });

        if (allFavoriteTopicos.length === 0) {
            return res.status(200).json({ message: 'Nenhum tópico favorito encontrado.' });
        }

        res.status(200).json(allFavoriteTopicos);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Erro ao listar todos os tópicos favoritos.' });
    }
};


topicosFavoritosController.delete = async (req, res) => {
    const { usuario_id, topico_id } = req.body;

    try {
        // Verifica se o usuário e o tópico existem
        const userExists = await User.findByPk(usuario_id);
        const topicoExists = await Topico.findByPk(topico_id);

        if (!userExists || !topicoExists) {
            return res.status(404).json({ message: 'Usuário ou tópico não encontrados' });
        }

        // Verifica se o tópico é realmente um favorito do usuário
        const favorite = await TopicosFavoritosUser.findOne({
            where: { usuario_id, topico_id }
        });

        if (!favorite) {
            return res.status(404).json({ message: 'Tópico favorito não encontrado para este usuário.' });
        }

        // Apaga o registro na tabela topicos_favoritos_user
        await favorite.destroy();

        // Responde com uma mensagem de sucesso
        res.status(200).json({ message: 'Tópico favorito removido com sucesso.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Erro ao remover tópico favorito.' });
    }
};


module.exports = topicosFavoritosController;


