const Area = require('../models/areas');
const areaController = {};

// Listar todas as áreas
areaController.list = async (req, res) => {
    try {
        const areas = await Area.findAll();
        if (areas.length === 0) {
            res.status(404).json({ message: 'Nenhuma área encontrada' });
        } else {
            res.json(areas);
        }
    } catch (error) {
        console.error('Erro ao listar áreas:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Criar uma nova área
areaController.create = async (req, res) => {
    const { nome } = req.body;
    try {
        const area = await Area.create({ nome });
        if (area) {
            res.status(200).json({
                success: true,
                message: "Área registrada com sucesso",
                data: area
            });
        }
    } catch (error) {
        console.error('Erro ao criar área:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Obter detalhes de uma área específica
areaController.detail = async (req, res) => {
    const { id } = req.params;
    try {
        const area = await Area.findByPk(id);
        if (area) {
            res.json(area);
        } else {
            res.status(404).json({ error: 'Área não encontrada' });
        }
    } catch (error) {
        console.error('Erro ao obter área:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Atualizar uma área existente
areaController.update = async (req, res) => {
    const { id } = req.params;
    try {
        const [updated] = await Area.update(req.body, {
            where: { id }
        });
        if (updated) {
            res.json({ message: 'Área atualizada com sucesso' });
        } else {
            res.status(404).json({ error: 'Área não encontrada' });
        }
    } catch (error) {
        console.error('Erro ao atualizar área:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Deletar uma área
areaController.delete = async (req, res) => {
    const { id } = req.params;
    try {
        const deleted = await Area.destroy({
            where: { id }
        });
        if (deleted) {
            res.json({ message: 'Área deletada com sucesso' });
        } else {
            res.status(404).json({ error: 'Área não encontrada' });
        }
    } catch (error) {
        console.error('Erro ao deletar área:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

module.exports = areaController;
