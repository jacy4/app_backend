const TipoEvento = require('../models/tipo_de_evento');

const tipoEventoFuncoes = {};

// Listar todos os tipos de evento
tipoEventoFuncoes.list = async (req, res) => {
    try {
        const tiposEvento = await TipoEvento.findAll();
        if (tiposEvento.length === 0) {
            res.status(404).json({ message: 'Nenhum tipo de evento encontrado' });
        } else {
            res.json(tiposEvento);
        }
    } catch (error) {
        console.error('Erro ao listar tipos de evento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Criar um novo tipo de evento
tipoEventoFuncoes.create = async (req, res) => {
    const { nome_tipo, caminho_imagem } = req.body;
    try {
        const tipoEvento = await TipoEvento.create({
            nome_tipo,
            caminho_imagem
        });
        res.status(201).json(tipoEvento);
    } catch (error) {
        console.error('Erro ao criar tipo de evento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Obter detalhes de um tipo de evento
tipoEventoFuncoes.detail = async (req, res) => {
    const { id } = req.params;
    try {
        const tipoEvento = await TipoEvento.findByPk(id);
        if (!tipoEvento) {
            res.status(404).json({ message: 'Tipo de evento não encontrado' });
        } else {
            res.json(tipoEvento);
        }
    } catch (error) {
        console.error('Erro ao obter tipo de evento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Atualizar um tipo de evento
tipoEventoFuncoes.update = async (req, res) => {
    const { id } = req.params;
    const { nome_tipo, caminho_imagem } = req.body;
    try {
        const [updated] = await TipoEvento.update({ nome_tipo, caminho_imagem }, {
            where: { id }
        });
        if (updated) {
            res.json({ message: 'Tipo de evento atualizado com sucesso' });
        } else {
            res.status(404).json({ message: 'Tipo de evento não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao atualizar tipo de evento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Deletar um tipo de evento
tipoEventoFuncoes.delete = async (req, res) => {
    const { id } = req.params;
    try {
        const deleted = await TipoEvento.destroy({
            where: { id }
        });
        if (deleted) {
            res.json({ message: 'Tipo de evento deletado com sucesso' });
        } else {
            res.status(404).json({ message: 'Tipo de evento não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao deletar tipo de evento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

module.exports = tipoEventoFuncoes;
