const Avaliacao = require('../models/avaliacao');
const sequelize = require('../database'); // Adicione esta linh
const AvaliacaoController = {};

AvaliacaoController.create = async (req, res) => {
  const { publicacao_id, autor_id, estrelas } = req.body;

  try {
    const [avaliacao, created] = await Avaliacao.upsert(
      { publicacao_id, autor_id, estrelas },
      { where: { publicacao_id, autor_id } }
    );
    res.status(201).json(avaliacao);
  } catch (error) {
    console.error('Erro ao criar avaliação:', error);
    res.status(500).json({ error: 'Erro ao criar avaliação' });
  }
};

AvaliacaoController.getAverage = async (req, res) => {
  const { publicacao_id } = req.params;
  
  try {
    const result = await Avaliacao.findAll({
      where: { publicacao_id },
      attributes: [[sequelize.fn('avg', sequelize.col('estrelas')), 'media']],
      raw: true
    });
    const media = parseFloat(result[0].media).toFixed(1);
    const total = await Avaliacao.count({ where: { publicacao_id } });
    res.status(200).json({ media, total });
  } catch (error) {
    console.error('Erro ao buscar média de avaliações:', error);
    res.status(500).json({ error: 'Erro ao buscar média de avaliações' });
  }
};

module.exports = AvaliacaoController;
