const DenunciasComentariosDeEventos = require('../models/denuncias_comentarios_de_eventos');
const ComentariosEventos=require('../models/comentarios_eventos');
const User = require('../models/user');
const Eventos = require('../models/eventos');
const denunciasComentariosEventosController = {};

denunciasComentariosEventosController.create = async (req, res) => {
    const { id_comentario_denunciado, resolvida, id_evento, id_denunciador, motivo_denuncia, descricao_denuncia } = req.body;

    try {
        const denuncia = await DenunciasComentariosDeEventos.create({
            id_comentario_denunciado,
            resolvida,
            id_evento,
            id_denunciador,
            motivo_denuncia,
            descricao_denuncia,
            data_denuncia: new Date() // Ou usar defaultValue no modelo
        });

        await Eventos.update(
            { estado: 'Denunciada' },  // Atualiza o campo estado para 'Denunciada'
            { where: { id: id_evento } }  // Condição para encontrar o evento pelo ID
        );

        res.status(201).json({
            message: "Denúncia criada com sucesso",
            denuncia: denuncia
        });
    } catch (error) {
        console.error('Erro ao criar denúncia:', error);
        res.status(500).json({ error: 'Erro ao criar denúncia' });
    }
};

denunciasComentariosEventosController.listarDenunciasDeEvento = async (req, res) => {
    const { id_evento } = req.params;

    try {
        const denuncias = await DenunciasComentariosDeEventos.findAll({
            where: { id_evento },
            include: [
                {
                    model: ComentariosEventos,
                    as: 'comentario_denunciado', 
                    attributes: ['id', 'texto_comentario', 'classificacao']
                },
                {
                    model: User,
                    as: 'denunciador', 
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                }
            ]
        });

        if (denuncias.length > 0) {
            res.json(denuncias);
        } else {
            res.status(404).json({ error: 'Nenhuma denúncia encontrada para o evento especificado' });
        }
    } catch (error) {
        console.error('Erro ao listar denúncias do evento:', error);
        res.status(500).json({ error: 'Erro ao buscar denúncias do evento' });
    }
};
denunciasComentariosEventosController.deleteDenuncia = async (req, res) => {
    const { id } = req.params;

    try {
        const deleted = await DenunciasComentariosDeEventos.destroy({ where: { id } });
        if (deleted) {
            res.json({ message: 'Denúncia excluída com sucesso' });
        } else {
            res.status(404).json({ error: 'Denúncia não encontrada para exclusão' });
        }
    } catch (error) {
        console.error('Erro ao deletar denúncia:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Atualizar uma denúncia de comentário de evento
denunciasComentariosEventosController.update = async (req, res) => {
    try {
      await DenunciasComentariosDeEventos.update(req.body, { where: { id: req.params.id } });
      res.json({ message: 'Denúncia de comentário de evento atualizada com sucesso' });
    } catch (error) {
      console.error('Erro ao atualizar denúncia de comentário de evento:', error);
      res.status(500).json({ error: 'Erro ao atualizar denúncia de comentário de evento' });
    }
  };
  

denunciasComentariosEventosController.deleteAllDenunciasDeEvento = async (req, res) => {
    const { id_evento } = req.params;

    try {
        const deleted = await DenunciasComentariosDeEventos.destroy({ where: { id_evento } });
        if (deleted) {
            res.json({ message: 'Todas as denúncias do evento foram excluídas com sucesso' });
        } else {
            res.status(404).json({ error: 'Nenhuma denúncia encontrada para o evento especificado' });
        }
    } catch (error) {
        console.error('Erro ao deletar denúncias do evento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};
module.exports = denunciasComentariosEventosController;
