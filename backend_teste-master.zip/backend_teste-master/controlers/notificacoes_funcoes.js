const Notificacao = require('../models/notificacoes');
const User = require('../models/user');
const notificacaoController = {};



notificacaoController.create = async (req, res = null) => {
  const { usuario_id, tipo, mensagem } = req.body;
  
  try {
    const notificacao = await Notificacao.create({
      usuario_id,
      tipo,
      mensagem,
      createdat: new Date()
    });

    if (res) {
      // Se `res` for fornecido, envie a resposta HTTP normalmente
      return res.status(201).json(notificacao);
    } else {
      // Se `res` não for fornecido (como no caso de chamadas internas), retorne a notificação criada
      return notificacao;
    }
  } catch (error) {
    console.error('Erro ao criar notificação:', error);

    if (res) {
      return res.status(500).json({ error: 'Erro ao criar notificação' });
    } else {
      // Lança o erro para ser tratado no contexto chamador
      throw error;
    }
  }
};


// Listar notificações por usuário
notificacaoController.listarNotificacoes = async (req, res) => {
  try {
    const notificacoes = await Notificacao.findAll({
      where: { usuario_id: req.params.usuarioId },
      include: [
        {
          model: User,
          as: 'usuario',
          attributes: ['id', 'nome', 'sobrenome']
        }
      ]
    });
    res.json(notificacoes);
  } catch (error) {
    console.error('Erro ao buscar notificações:', error);
    res.status(500).json({ error: 'Erro ao buscar notificações' });
  }
};

// Marcar uma notificação como lida
notificacaoController.marcarComoLida = async (req, res) => {
  try {
    await Notificacao.update({ lida: true }, { where: { id: req.params.id } });
    res.json({ message: 'Notificação marcada como lida' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao atualizar notificação' });
  }
};

// Excluir uma notificação
notificacaoController.delete = async (req, res) => {
  try {
    await Notificacao.destroy({ where: { id: req.params.id } });
    res.json({ message: 'Notificação excluída com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao excluir notificação' });
  }
};

module.exports = notificacaoController;
