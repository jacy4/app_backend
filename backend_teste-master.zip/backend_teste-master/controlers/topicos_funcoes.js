const Topico = require('../models/topicos');
const Area = require('../models/areas');
const topicoController = {};

// Listar todos os tópicos
topicoController.list = async (req, res) => {
    try {
        const topicos = await Topico.findAll({ include: [{ model: Area, as: 'area' }] });
        if (topicos.length === 0) {
            res.status(404).json({ message: 'Nenhum tópico encontrado' });
        } else {
            res.json(topicos);
        }
    } catch (error) {
        console.error('Erro ao listar tópicos:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Criar um novo tópico
topicoController.create = async (req, res) => {
    const { nome, topico_icon, area_id } = req.body;
    try {
        const topico = await Topico.create({ nome, topico_icon, area_id });
        if (topico) {
            res.status(201).json({
                success: true,
                message: "Tópico registrado com sucesso",
                data: topico
            });
        }
    } catch (error) {
        console.error('Erro ao criar tópico:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Obter detalhes de um tópico específico
topicoController.detail = async (req, res) => {
    const { id } = req.params;
    try {
        const topico = await Topico.findByPk(id, { include: [{ model: Area, as: 'area' }] });
        if (topico) {
            res.json(topico);
        } else {
            res.status(404).json({ error: 'Tópico não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao obter tópico:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Atualizar um tópico existente
topicoController.update = async (req, res) => {
    const { id } = req.params;
    try {
        const [updated] = await Topico.update(req.body, {
            where: { id }
        });
        if (updated) {
            res.json({ message: 'Tópico atualizado com sucesso' });
        } else {
            res.status(404).json({ error: 'Tópico não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao atualizar tópico:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Deletar um tópico
topicoController.delete = async (req, res) => {
    const { id } = req.params;
    try {
        const deleted = await Topico.destroy({
            where: { id }
        });
        if (deleted) {
            res.json({ message: 'Tópico deletado com sucesso' });
        } else {
            res.status(404).json({ error: 'Tópico não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao deletar tópico:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Listar tópicos por área
topicoController.listByArea = async (req, res) => {
    const { area_id } = req.params;
    try {
        const topicos = await Topico.findAll({
            where: { area_id },
            include: [{ model: Area, as: 'area' }]
        });
        if (topicos.length === 0) {
            res.status(404).json({ message: 'Nenhum tópico encontrado para essa área' });
        } else {
            res.json(topicos);
        }
    } catch (error) {
        console.error('Erro ao listar tópicos por área:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

module.exports = topicoController;


// Listar todos os tópicos
topicoController.list = async (req, res) => {
    try {
        const topicos = await Topico.findAll({ include: [{ model: Area, as: 'area' }] });
        if (topicos.length === 0) {
            res.status(404).json({ message: 'Nenhum tópico encontrado' });
        } else {
            res.json(topicos);
        }
    } catch (error) {
        console.error('Erro ao listar tópicos:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Criar um novo tópico
topicoController.create = async (req, res) => {
    const { nome, topico_icon, area_id } = req.body;
    try {
        const topico = await Topico.create({ nome, topico_icon, area_id });
        if (topico) {
            res.status(201).json({
                success: true,
                message: "Tópico registrado com sucesso",
                data: topico
            });
        }
    } catch (error) {
        console.error('Erro ao criar tópico:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Obter detalhes de um tópico específico
topicoController.detail = async (req, res) => {
    const { id } = req.params;
    try {
        const topico = await Topico.findByPk(id, { include: [{ model: Area, as: 'area' }] });
        if (topico) {
            res.json(topico);
        } else {
            res.status(404).json({ error: 'Tópico não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao obter tópico:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Atualizar um tópico existente
topicoController.update = async (req, res) => {
    const { id } = req.params;
    try {
        const [updated] = await Topico.update(req.body, {
            where: { id }
        });
        if (updated) {
            res.json({ message: 'Tópico atualizado com sucesso' });
        } else {
            res.status(404).json({ error: 'Tópico não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao atualizar tópico:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Deletar um tópico
topicoController.delete = async (req, res) => {
    const { id } = req.params;
    try {
        const deleted = await Topico.destroy({
            where: { id }
        });
        if (deleted) {
            res.json({ message: 'Tópico deletado com sucesso' });
        } else {
            res.status(404).json({ error: 'Tópico não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao deletar tópico:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Listar tópicos por área
topicoController.listByArea = async (req, res) => {
    const { area_id } = req.params;
    try {
        const topicos = await Topico.findAll({
            where: { area_id },
            include: [{ model: Area, as: 'area' }]
        });
        if (topicos.length === 0) {
            res.status(404).json({ message: 'Nenhum tópico encontrado para essa área' });
        } else {
            res.json(topicos);
        }
    } catch (error) {
        console.error('Erro ao listar tópicos por área:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

module.exports = topicoController;
