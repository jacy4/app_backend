const ComentariosEventos = require('../models/comentarios_eventos');
const User = require('../models/user');
const Evento = require('../models/eventos');
const comentariosEventosController = {};
const notificacaoController = require('../controlers/notificacoes_funcoes'); 
const Participantes = require('../models/lista_participantes_evento');

const LikeComentarioEvento = require('../models/likes_comentarios_eventos');
// Criar um comentário em um evento
comentariosEventosController.create = async (req, res) => {
    const { evento_id, user_id, texto_comentario, classificacao } = req.body;

    try {
        if (classificacao > 0) {
           
            await ComentariosEventos.update(
                { classificacao },
                { where: { evento_id, user_id } }
            );
        }

        const comentarioEvento = await ComentariosEventos.create({
            evento_id,
            user_id,
            texto_comentario,
            classificacao,
            data_comentario: new Date() 
        });

       
        const evento = await Evento.findByPk(evento_id);
        if (!evento) {
            return res.status(404).json({ error: 'Evento não encontrado' });
        }

       
        const participantes = await Participantes.findAll({
            where: { evento_id }
        });

        
        const notificacoesCriadas = [];

       
        for (let participante of participantes) {
            const reqNotificacao = {
                body: {
                    usuario_id: participante.usuario_id,
                    tipo: 'Novo Comentário Num Evento',
                    mensagem: `Um novo comentário foi adicionado ao evento "${evento.nome}". Confira agora!`,
                }
            };

           
            const notificacao = await notificacaoController.create(reqNotificacao);
            notificacoesCriadas.push(notificacao);
        }

  
        res.status(201).json({
            message: "Comentário feito com sucesso e notificações enviadas",
            comentario: comentarioEvento,
            notificacoes: notificacoesCriadas
        });
    } catch (error) {
        console.error('Erro ao criar comentário de evento:', error);
        res.status(500).json({ error: 'Erro ao criar comentário de evento' });
    }
};

// Listar comentários de um evento específico
comentariosEventosController.listarComentariosPorEvento = async (req, res) => {
    const { evento_id } = req.params;

    try {
        const comentarios = await ComentariosEventos.findAll({
            where: { evento_id },
            include: [
                {
                    model: User,
                    as: 'usuario', // Use 'usuario' conforme definido na associação
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                },
                {
                    model: Evento,
                    as: 'evento', // Use 'evento' conforme definido na associação
                    attributes: ['id', 'nome']
                }
            ]
        });
        res.json(comentarios);
    } catch (error) {
        console.error('Erro ao listar comentários do evento:', error);
        res.status(500).json({ error: 'Erro ao buscar comentários do evento' });
    }
};

// Detalhe de um comentário específico
comentariosEventosController.detail = async (req, res) => {
    const { id } = req.params;

    try {
        const comentario = await ComentariosEventos.findByPk(id, {
            include: [
                {
                    model: User,
                    as: 'user',
                    attributes: ['nome', 'sobrenome']
                }
            ]
        });

        if (comentario) {
            res.json(comentario);
        } else {
            res.status(404).json({ error: 'Comentário de evento não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao obter detalhes do comentário do evento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Atualizar um comentário de evento
comentariosEventosController.update = async (req, res) => {
    const { id } = req.params;
    const { texto_comentario, classificacao } = req.body;

    try {
        const [updated] = await ComentariosEventos.update({
            texto_comentario,
            classificacao
        }, {
            where: { id }
        });

        if (updated) {
            res.json({ message: 'Comentário de evento atualizado com sucesso' });
        } else {
            res.status(404).json({ error: 'Comentário de evento não encontrado para atualizar' });
        }
    } catch (error) {
        console.error('Erro ao atualizar comentário de evento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};


comentariosEventosController.delete = async (req, res) => {
    const { id } = req.params;

    try {
        // Primeiro, deletar os likes associados ao comentário do evento
        await LikeComentarioEvento.destroy({ where: { comentario_evento_id: id } });

        // Agora, deletar o próprio comentário do evento
        const deleted = await ComentariosEventos.destroy({ where: { id } });
        if (deleted) {
            res.json({ message: 'Comentário de evento excluído com sucesso' });
        } else {
            res.status(404).json({ error: 'Comentário de evento não encontrado para exclusão' });
        }
    } catch (error) {
        console.error('Erro ao deletar comentário de evento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};




comentariosEventosController.listarComentariosPorCentro = async (req, res) => {
    const { centro_id } = req.params; // centro_id passado como parâmetro na URL

    try {
        const eventos = await Evento.findAll({
            where: { centro_id },
            include: [{
                model: ComentariosEventos,
                as: 'comentarios', // Use 'comentarios' conforme definido na associação
                include: [{
                    model: User,
                    as: 'usuario', // Use 'usuario' conforme definido na associação
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                }]
            }]
        });

        const comentarios = eventos.flatMap(evento => 
            evento.comentarios.map(comentario => ({
                ...comentario.dataValues,
                evento: {
                    id: evento.id,
                    nome: evento.nome
                },
                usuario: comentario.usuario
            }))
        );

        if (comentarios.length > 0) {
            res.json(comentarios);
        } else {
            res.status(404).json({ error: 'Nenhum comentário encontrado para o centro especificado' });
        }
    } catch (error) {
        console.error('Erro ao listar comentários por centro:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};
comentariosEventosController.listarComentariosPorCentroEAutor = async (req, res) => {
    const { centro_id, autor_id } = req.params;

    try {
        // Consulta 1: Comentários de eventos de um centro específico
        const eventosCentro = await Evento.findAll({
            where: { centro_id },
            include: [{
                model: ComentariosEventos,
                as: 'comentarios',
                include: [{
                    model: User,
                    as: 'usuario',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                }]
            }]
        });

        // Consulta 2: Comentários de eventos criados por um autor específico
        const eventosAutor = await Evento.findAll({
            where: { autor_id },
            include: [{
                model: ComentariosEventos,
                as: 'comentarios',
                include: [{
                    model: User,
                    as: 'usuario',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                }]
            }]
        });

        // Combinar os resultados dos comentários de eventos por centro e por autor
        const comentariosMap = new Map();

        eventosCentro.forEach(evento => {
            evento.comentarios.forEach(comentario => {
                comentariosMap.set(comentario.id, {
                    ...comentario.dataValues,
                    evento: { id: evento.id, nome: evento.nome },
                    usuario: comentario.usuario
                });
            });
        });

        eventosAutor.forEach(evento => {
            evento.comentarios.forEach(comentario => {
                comentariosMap.set(comentario.id, {
                    ...comentario.dataValues,
                    evento: { id: evento.id, nome: evento.nome },
                    usuario: comentario.usuario
                });
            });
        });

        // Converter o map para um array
        const resultadoFinal = Array.from(comentariosMap.values());

        // Verifica se há resultados e responde
        if (resultadoFinal.length > 0) {
            res.json(resultadoFinal);
        } else {
            res.status(404).json({ message: 'Nenhum comentário encontrado para este centro ou autor' });
        }
    } catch (error) {
        console.error('Erro ao listar comentários por centro e autor:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao listar comentários' });
    }
};

// Obter a média das avaliações de um evento
comentariosEventosController.obterMediaAvaliacoes = async (req, res) => {
    const { evento_id } = req.params;

    try {
        const comentarios = await ComentariosEventos.findAll({
            where: { evento_id },
            include: [{ model: User, as: 'usuario', attributes: ['id'] }]
        });

        const avaliacaoPorUsuario = new Map();

        comentarios.forEach(comentario => {
            avaliacaoPorUsuario.set(comentario.usuario.id, comentario.classificacao);
        });

        const avaliacoes = Array.from(avaliacaoPorUsuario.values()).filter(c => c > 0);
        const totalAvaliacoes = avaliacoes.length;
        const somaAvaliacoes = avaliacoes.reduce((acc, val) => acc + val, 0);
        const media = totalAvaliacoes > 0 ? somaAvaliacoes / totalAvaliacoes : 0;

        res.json({ media, total: totalAvaliacoes });
    } catch (error) {
        console.error('Erro ao calcular a média das avaliações:', error);
        res.status(500).json({ error: 'Erro ao calcular a média das avaliações' });
    }
};


module.exports = comentariosEventosController;
