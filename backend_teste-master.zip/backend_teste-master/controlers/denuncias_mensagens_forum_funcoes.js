const DenunciaMensagemForum = require('../models/denuncias_mensagens_forum');
const MensagemForum = require('../models/mensagem_forum');
const User = require('../models/user');
const Forum = require('../models/forum');

const denunciaMensagemForumController = {};

// Criar uma nova denúncia
denunciaMensagemForumController.create = async (req, res) => {
    const { mensagem_forum_id, forum_id, denunciante_id, motivo, informacao_adicional } = req.body;
  
    try {
      // Criação da denúncia
      const denuncia = await DenunciaMensagemForum.create({
        mensagem_forum_id,
        forum_id,
        denunciante_id,
        motivo,
        informacao_adicional,
        resolvida: false,
        createdAt: new Date()
      });
  
      // Atualização do estado do fórum para "Denunciado" se houver pelo menos uma denúncia
      const forum = await Forum.findByPk(forum_id);
      if (forum && forum.estado !== 'Denunciado') {
        forum.estado = 'Denunciado';
        await forum.save();
      }
  
      res.status(201).json(denuncia);
    } catch (error) {
      console.error('Erro ao criar denúncia de mensagem de fórum:', error);
      res.status(500).json({ error: 'Erro ao criar denúncia' });
    }
  };
// Listar denúncias por mensagem de fórum
denunciaMensagemForumController.listarDenunciasPorMensagem = async (req, res) => {
  try {
    const denuncias = await DenunciaMensagemForum.findAll({
      where: { mensagem_forum_id: req.params.mensagemForumId },
      include: [
        {
          model: User,
          as: 'denunciante',
          attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
        },
        {
          model: Forum,
          attributes: ['id', 'nome']
        }
      ]
    });
    res.json(denuncias);
  } catch (error) {
    console.error('Erro ao buscar denúncias:', error);
    res.status(500).json({ error: 'Erro ao buscar denúncias' });
  }
};

// Listar denúncias por fórum
denunciaMensagemForumController.listarDenunciasPorForum = async (req, res) => {
  try {
    const denuncias = await DenunciaMensagemForum.findAll({
      where: { forum_id: req.params.forumId },
      include: [
        {
          model: User,
          as: 'denunciante',
          attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
        },
        {
          model: MensagemForum,
          attributes: ['id', 'texto_mensagem']
        }
      ]
    });
    res.json(denuncias);
  } catch (error) {
    console.error('Erro ao buscar denúncias:', error);
    res.status(500).json({ error: 'Erro ao buscar denúncias' });
  }
};

// Buscar uma denúncia por ID
denunciaMensagemForumController.detail = async (req, res) => {
  try {
    const denuncia = await DenunciaMensagemForum.findByPk(req.params.id, {
      include: [
        {
          model: User,
          as: 'denunciante',
          attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
        },
        {
          model: MensagemForum,
          attributes: ['id', 'texto_mensagem']
        },
        {
          model: Forum,
          attributes: ['id', 'nome']
        }
      ]
    });
    if (denuncia) {
      res.json(denuncia);
    } else {
      res.status(404).json({ error: 'Denúncia não encontrada' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar denúncia' });
  }
};

// Atualizar uma denúncia
denunciaMensagemForumController.update = async (req, res) => {
  try {
    await DenunciaMensagemForum.update(req.body, { where: { id: req.params.id } });
    res.json({ message: 'Denúncia atualizada com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao atualizar denúncia' });
  }
};

// Excluir uma denúncia
denunciaMensagemForumController.delete = async (req, res) => {
  try {
    await DenunciaMensagemForum.destroy({ where: { id: req.params.id } });
    res.json({ message: 'Denúncia excluída com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao excluir denúncia' });
  }
};

module.exports = denunciaMensagemForumController;
