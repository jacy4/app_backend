const ListaGrupo = require('../models/listagrupo');
const User = require('../models/user');
const Grupo = require('../models/grupos');
const listaGrupoController = {};

// Listar todos os membros de um grupo específico
listaGrupoController.listarMembrosPorGrupo = async (req, res) => {
    const { grupo_id } = req.params;

    try {
        const membros = await ListaGrupo.findAll({
            where: { grupo_id },
            include: [
                {
                    model: User,
                    as: 'usuario',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                },
                {
                    model: Grupo,
                    as: 'grupo',
                    attributes: ['id', 'nome']
                }
            ]
        });
        
        if (membros.length > 0) {
            res.json(membros);
        } else {
            res.status(404).json({ error: 'Nenhum membro encontrado para o grupo especificado' });
        }
    } catch (error) {
        console.error('Erro ao listar membros do grupo:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao listar membros do grupo' });
    }
};
listaGrupoController.adicionarMembroAoGrupo = async (req, res) => {
    const { usuario_id, grupo_id } = req.body;

    try {
        const novoMembro = await ListaGrupo.create({
            usuario_id,
            grupo_id
        });

        res.status(201).json(novoMembro);
    } catch (error) {
        console.error('Erro ao adicionar membro ao grupo:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao adicionar membro ao grupo' });
    }
};
listaGrupoController.removerMembroDoGrupo = async (req, res) => {
    const { usuario_id, grupo_id } = req.body;

    try {
        const membroRemovido = await ListaGrupo.destroy({
            where: {
                usuario_id,
                grupo_id
            }
        });

        if (membroRemovido) {
            res.json({ message: 'Membro removido com sucesso do grupo' });
        } else {
            res.status(404).json({ error: 'Membro não encontrado no grupo especificado' });
        }
    } catch (error) {
        console.error('Erro ao remover membro do grupo:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao remover membro do grupo' });
    }
};
listaGrupoController.listarGruposPorUsuario = async (req, res) => {
    const { usuario_id } = req.params;

    try {
        const grupos = await ListaGrupo.findAll({
            where: { usuario_id },
            include: [
                {
                    model: Grupo,
                    as: 'grupo',
                    attributes: ['id', 'nome']
                }
            ]
        });

        if (grupos.length > 0) {
            res.json(grupos);
        } else {
            res.status(404).json({ error: 'Nenhum grupo encontrado para o usuário especificado' });
        }
    } catch (error) {
        console.error('Erro ao listar grupos do usuário:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao listar grupos do usuário' });
    }
};

module.exports = listaGrupoController;