const { Sequelize } = require('sequelize');
const Usuario = require('../models/user');
const usuarioController = {};

usuarioController.list = async (req, res) => {
    try {
      const users = await Usuario.findAll();
      if (users.length === 0) {
        res.status(404).json({ message: 'Nenhum usuário encontrado' });
      } else {
        res.json(users);
      }
    } catch (error) {
      console.error('Erro ao listar usuários:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  };

  usuarioController.listall = async (req, res) => {
    // console.log('Recebendo requisição para listar todos os usuários');
    try {
        const users = await Usuario.findAll();
        if (users.length === 0) {
            res.status(404).json({ message: 'Nenhum usuário encontrado' });
        } else {
            res.json(users);
        }
    } catch (error) {
        console.error('Erro ao listar usuários:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

  

usuarioController.create = async (req, res) => {
    const { nome, sobrenome, caminho_foto, caminho_fundo, sobre_min, centro_id,imagem,email,pass } = req.body;
      
    try {
        const usuario = await Usuario.create({
            nome: nome,
            sobrenome: sobrenome,
            caminho_foto: caminho_foto,
            caminho_fundo: caminho_fundo,
            sobre_min: sobre_min,
            imagem: imagem,
            centro_id: centro_id,
            email:email,
            password:pass,
        });
        if (usuario) {
            res.status(200).json({
                success: true,
                message: "Usuário registrado",
                data: usuario
            });
        }
    } catch (error) {
        console.error('Erro ao criar usuário:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// As demais funções (detail, update, delete) podem seguir o mesmo padrão usado para os centros
// Detalhe do usuário
usuarioController.detail = async (req, res) => {
    const { id } = req.params;
    try {
        const usuario = await Usuario.findByPk(id);
        if (usuario) {
            res.json(usuario);
        } else {
            res.status(404).json({ error: 'Usuário não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao obter usuário:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Atualização do usuário
usuarioController.update = async (req, res) => {
    const { id } = req.params;
    try {
        const [updated] = await Usuario.update(req.body, {
            where: { id }
        });
        if (updated) {
            res.json({ message: 'Usuário atualizado com sucesso' });
        } else {
            res.status(404).json({ error: 'Usuário não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao atualizar usuário:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Exclusão do usuário
usuarioController.delete = async (req, res) => {
    const { id } = req.params;
    try {
        const deleted = await Usuario.destroy({
            where: { id }
        });
        if (deleted) {
            res.json({ message: 'Usuário deletado com sucesso' });
        } else {
            res.status(404).json({ error: 'Usuário não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao deletar usuário:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

usuarioController.checkEmailAndPassword = async (req, res) => {
    const { email, password } = req.query; 
    try {
        const usuario = await Usuario.findOne({ where: { email } });
        if (usuario) {
            if(usuario.active === false) {
               res.json({ message: `Utilizador desativado!` });
            } else { 
                if (password === usuario.password) {
                    res.json({
                        message: 'Email e senha corretos',
                        userId: usuario.id,
                        userName: usuario.nome,
                    });
                } else {
                    res.json({ message: `Senha incorreta para o email ${email}` });
                }
            }
        } else {
            res.json({ message: `Não existe um utilizador para o email ${email}` });
        }
    } catch (error) {
        console.error('Erro ao verificar email e senha:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

usuarioController.desativar = async (req, res) => {
    const { id } = req.params;
    try {
        // console.log(id)
        const usuario = await Usuario.findByPk(id);
    
        if (usuario) {
          await Usuario.update({ active: false }, { where: { id } });
    
          res.json({ message: `Usuário com ID ${id} foi desativado com sucesso.` });
        } else {
          res.json({ error: `Não existe um utilizador com o ID ${id}` });
        }
      } catch (error) {
        console.error('Erro ao desativar o usuário:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
      }
};

usuarioController.ativar = async (req, res) => {
    const { id } = req.params;
    try {
        // console.log(id)
        const usuario = await Usuario.findByPk(id);
    
        if (usuario) {
          await Usuario.update({ active: true }, { where: { id } });
    
          res.json({ message: `Usuário com ID ${id} foi ativado com sucesso.` });
        } else {
          res.json({ error: `Não existe um utilizador com o ID ${id}` });
        }
      } catch (error) {
        console.error('Erro ao ativar o usuário:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
      }
};

usuarioController.getUserById = async (req, res) => {
  const { id } = req.params;
  
  try {
    const user = await Usuario.findByPk(id, {
      attributes: ['nome', 'sobrenome', 'caminho_foto']
    });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.status(200).json(user);
  } catch (error) {
    console.error('Error fetching user:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Função para verificar se o email do Google está registrado
usuarioController.verifyGoogleEmail = async (req, res) => {
    const { email } = req.query;  

    try {
        // Procura um usuário pelo email
        const usuario = await Usuario.findOne({
            where: { email }
        });

        
        if (usuario) {
            res.json({
                message: 'Conta email registada',
                userId: usuario.id
            });
        } else {
            res.status(404).json({ message: 'Email não registrado' });
        }
    } catch (error) {
        console.error('Erro ao verificar email:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};



module.exports = usuarioController;
