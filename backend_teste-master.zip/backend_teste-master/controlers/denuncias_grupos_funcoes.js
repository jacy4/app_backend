const DenunciaGrupo = require('../models/denuncias_grupos'); // Modelo de denúncias de grupos
const Grupo = require('../models/grupos'); // Modelo de grupos
const User = require('../models/user'); // Modelo de usuários

const denunciaGrupoController = {};

// Criar uma nova denúncia de grupo
denunciaGrupoController.create = async (req, res) => {
  const { grupo_id, denunciante_id, motivo, informacao_adicional } = req.body;
  
  try {
    const denuncia = await DenunciaGrupo.create({
      grupo_id,
      denunciante_id,
      motivo,
      informacao_adicional,
      resolvida: false,
      createdAt: new Date()
    });
    res.status(201).json(denuncia);
  } catch (error) {
    console.error('Erro ao criar denúncia:', error);
    res.status(500).json({ error: 'Erro ao criar denúncia' });
  }
};

// Listar denúncias por grupo
denunciaGrupoController.listarDenuncias = async (req, res) => {
  try {
    // console.log('Grupo ID:', req.params.grupoId); // Log para ver o ID do grupo
    const denuncias = await DenunciaGrupo.findAll({
      where: { grupo_id: req.params.grupoId },
      include: [
        {
          model: User,
          as: 'denunciante',
          attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
        }
      ]
    });
    res.json(denuncias);
  } catch (error) {
    console.error('Erro ao buscar denúncias:', error); // Log do erro completo
    res.status(500).json({ error: 'Erro ao buscar denúncias' });
  }
};

// Buscar uma denúncia de grupo por ID
denunciaGrupoController.detail = async (req, res) => {
  try {
    const denuncia = await DenunciaGrupo.findByPk(req.params.id, {
      include: [
        {
          model: User,
          as: 'denunciante',
          attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
        },
        {
          model: Grupo,
          attributes: ['id', 'nome']
        }
      ]
    });
    if (denuncia) {
      res.json(denuncia);
    } else {
      res.status(404).json({ error: 'Denúncia não encontrada' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar denúncia' });
  }
};

// Atualizar uma denúncia de grupo
denunciaGrupoController.update = async (req, res) => {
  try {
    await DenunciaGrupo.update(req.body, { where: { id: req.params.id } });
    res.json({ message: 'Denúncia atualizada com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao atualizar denúncia' });
  }
};

// Excluir uma denúncia de grupo
denunciaGrupoController.delete = async (req, res) => {
  try {
    await DenunciaGrupo.destroy({ where: { id: req.params.id } });
    res.json({ message: 'Denúncia excluída com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao excluir denúncia' });
  }
};

module.exports = denunciaGrupoController;
