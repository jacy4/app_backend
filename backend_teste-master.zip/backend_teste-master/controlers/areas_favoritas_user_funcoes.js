const AreasFavoritasUser = require('../models/areas_favoritas_user');
const User = require('../models/user');
const Area = require('../models/areas');
const areafavoritasuserController = {};



// Função para criar uma área favorita
areafavoritasuserController.create = async (req, res) => {
    const { usuario_id, area_id } = req.body;

    try {
        // Verifica se o usuário e a área existem
        const userExists = await User.findByPk(usuario_id);
        const areaExists = await Area.findByPk(area_id);

        if (!userExists || !areaExists) {
            return res.status(404).json({ message: 'Usuário ou área não encontrados' });
        }

      
        const alreadyFavorite = await AreasFavoritasUser.findOne({
            where: { usuario_id, area_id }
        });

        if (alreadyFavorite) {
            return res.status(400).json({ message: 'A área já está definida como favorita para este usuário.' });
        }

       
        await AreasFavoritasUser.create({ usuario_id, area_id });

       
        res.status(201).json({ message: 'Área definida como favorita com sucesso.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Erro ao adicionar área favorita.' });
    }
};



// Função para listar áreas favoritas 

areafavoritasuserController.list = async (req, res) => {
    const { usuario_id } = req.params;

    try {
        // Verifica se o usuário existe
        const userExists = await User.findByPk(usuario_id);

        if (!userExists) {
            return res.status(404).json({ message: 'Usuário não encontrado' });
        }

        
        const favoriteAreas = await User.findOne({
            where: { id: usuario_id },
            attributes: ['id'], 
            include: [{
                model: Area,
                as: 'areas_favoritas',
                attributes: ['id', 'nome']
            }]
        });

        // Verifica 
        if (!favoriteAreas || favoriteAreas.areas_favoritas.length === 0) {
            return res.status(200).json({ message: 'Usuário não tem áreas favoritas.' });
        }

        res.status(200).json(favoriteAreas);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Erro ao listar áreas favoritas' });
    }
};

areafavoritasuserController.listAll = async (req, res) => {
    try {
        // Consulta todas as linhas da tabela areas_favoritas_user
        const allFavoriteAreas = await AreasFavoritasUser.findAll({
            attributes: ['id', 'usuario_id', 'area_id'], // Seleciona apenas os atributos desejados
        });

        if (allFavoriteAreas.length === 0) {
            return res.status(200).json({ message: 'Nenhuma área favorita encontrada.' });
        }

        res.status(200).json(allFavoriteAreas);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Erro ao listar todas as áreas favoritas.' });
    }
};



// Função para apagar uma área favorita
areafavoritasuserController.delete = async (req, res) => {
    const { usuario_id, area_id } = req.body;

    try {
        const favorite = await AreasFavoritasUser.findOne({
            where: { usuario_id, area_id }
        });

        if (!favorite) {
            return res.status(404).json({ message: 'Área favorita não encontrada' });
        }

        await favorite.destroy();
        res.status(200).json({ message: 'Área favorita removida com sucesso' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Erro ao remover área favorita' });
    }
};

module.exports = areafavoritasuserController;