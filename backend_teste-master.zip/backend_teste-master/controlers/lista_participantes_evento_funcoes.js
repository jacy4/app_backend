const ListaParticipantesEvento = require('../models/lista_participantes_evento'); // Ajuste conforme o caminho correto do seu modelo
const User = require('../models/user');
const Evento = require('../models/eventos');
const Centro=require('../models/centro');
const participantesEventosController = {};
const notificacaoController = require('../controlers/notificacoes_funcoes');

// Adicionar um participante a um evento
participantesEventosController.adicionarParticipante = async (req, res) => {
    const { usuario_id, evento_id } = req.body;

    try {
        // Verificar se o participante já está registrado no evento
        const exists = await ListaParticipantesEvento.findOne({
            where: {
                usuario_id: usuario_id,
                evento_id: evento_id
            }
        });

        if (exists) {
            return res.status(409).json({ error: 'Participante já registrado neste evento' });
        }

        // Criar a nova entrada
        const novoParticipante = await ListaParticipantesEvento.create({
            usuario_id,
            evento_id
        });

        // Recuperar informações do evento e do criador do evento
        const evento = await Evento.findByPk(evento_id, {
            include: [{
                model: User,
                as: 'user', // alias da associação do evento com o criador
                attributes: ['id', 'nome'] // somente os campos necessários
            }]
        });

        if (evento) {
            // Preparar a notificação
            const reqNotificacao = {
                body: {
                    usuario_id: evento.user.id, 
                    tipo: 'Novo Participante',
                    mensagem: `Um novo user registou-se no seu evento "${evento.nome}" !`
                }
            };

            // Enviar a notificação para o criador do evento
            await notificacaoController.create(reqNotificacao);
        }

        res.status(201).json({ message: 'Participante adicionado com sucesso e notificação enviada', participante: novoParticipante });
    } catch (error) {
        console.error('Erro ao adicionar participante:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao adicionar participante' });
    }
};

participantesEventosController.removerParticipante = async (req, res) => {
    const { usuario_id, evento_id } = req.params; // Suponha que estes valores vêm como parâmetros da URL

    try {
        const deleted = await ListaParticipantesEvento.destroy({
            where: { 
                usuario_id: usuario_id, 
                evento_id: evento_id 
            }
        });
        if (deleted) {
            res.json({ message: 'Participante removido com sucesso do evento' });
        } else {
            res.status(404).json({ error: 'Participante não encontrado para remoção' });
        }
    } catch (error) {
        console.error('Erro ao remover participante:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao remover participante' });
    }
};

participantesEventosController.removerTodosParticipantes = async (req, res) => {
    const { evento_id } = req.params; // Suponha que o ID do evento venha como parâmetro da URL

    try {
        const deleted = await ListaParticipantesEvento.destroy({
            where: { 
                evento_id: evento_id 
            }
        });
        if (deleted) {
            res.json({ message: `Todos os participantes foram removidos do evento ${evento_id} com sucesso.` });
        } else {
            res.status(404).json({ error: 'Nenhum participante encontrado para este evento' });
        }
    } catch (error) {
        console.error('Erro ao remover todos os participantes:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao remover participantes' });
    }
};

// Listar todos os participantes de todos os eventos
participantesEventosController.listarTodosParticipantes = async (req, res) => {
    try {
        const participantes = await ListaParticipantesEvento.findAll({
            include: [
                {
                    model: User, // Suponha que você tenha um modelo User associado
                    as: 'usuario',
                    attributes: ['id', 'nome', 'sobrenome']
                },
                {
                    model: Evento, // Suponha que você tenha um modelo Evento associado
                    as: 'evento',
                    attributes: ['id', 'nome']
                }
            ]
        });

        if (participantes.length > 0) {
            res.json(participantes);
        } else {
            res.status(404).json({ error: 'Nenhum participante encontrado' });
        }
    } catch (error) {
        console.error('Erro ao listar todos os participantes:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao listar participantes' });
    }
};

// Listar todos os participantes de eventos de um centro específico
participantesEventosController.listarParticipantesPorCentro = async (req, res) => {
    const { centro_id } = req.params;

    try {
        const participantes = await ListaParticipantesEvento.findAll({
            include: [{
                model: User,
                as: 'usuario',
                attributes: ['id', 'nome', 'sobrenome']
            }, {
                model: Evento,
                as: 'evento',
                required: true,  // Adicione esta linha para garantir que apenas eventos com correspondência são incluídos
                include: [{
                    model: Centro,
                    as: 'centro',
                    where: { id: centro_id },  // Garante a filtragem por centro_id
                    attributes: []
                }],
                attributes: ['id', 'nome']
            }]
        });

        if (participantes.length > 0) {
            res.json(participantes);
        } else {
            res.status(404).json({ message: 'Nenhum participante encontrado para este centro' });
        }
    } catch (error) {
        console.error('Erro ao listar participantes por centro:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao listar participantes' });
    }
};

participantesEventosController.listarParticipantesPorCentroEAutor = async (req, res) => {
    const { centro_id, autor_id } = req.params;

    try {
        // Consulta 1: Participantes de eventos de um centro específico
        const participantesCentro = await ListaParticipantesEvento.findAll({
            include: [{
                model: User,
                as: 'usuario',
                attributes: ['id', 'nome', 'sobrenome']
            }, {
                model: Evento,
                as: 'evento',
                where: { centro_id: centro_id },
                attributes: ['id', 'nome']
            }]
        });

        // Consulta 2: Participantes de eventos criados por um autor específico
        const participantesAutor = await ListaParticipantesEvento.findAll({
            include: [{
                model: User,
                as: 'usuario',
                attributes: ['id', 'nome', 'sobrenome']
            }, {
                model: Evento,
                as: 'evento',
                where: { autor_id: autor_id },
                attributes: ['id', 'nome']
            }]
        });

        // Combina os dois resultados em um conjunto único para evitar duplicações
        const participantesMap = new Map();

        participantesCentro.forEach(participante => {
            const participanteId = participante.usuario.id;
            const eventoId = participante.evento.id;
            participantesMap.set(`${participanteId}-${eventoId}`, participante);
        });

        participantesAutor.forEach(participante => {
            const participanteId = participante.usuario.id;
            const eventoId = participante.evento.id;
            participantesMap.set(`${participanteId}-${eventoId}`, participante);
        });

        // Converter o map para um array
        const resultadoFinal = Array.from(participantesMap.values());

        // Verifica se há resultados e responde
        if (resultadoFinal.length > 0) {
            res.json(resultadoFinal);
        } else {
            res.status(404).json({ message: 'Nenhum participante encontrado para este centro ou autor' });
        }
    } catch (error) {
        console.error('Erro ao listar participantes por centro e autor:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao listar participantes' });
    }
};


participantesEventosController.listarParticipantesPorEvento = async (req, res) => {
    const eventoId = req.params.evento_id;  // Obtem o ID do evento da URL

    try {
        const participantes = await ListaParticipantesEvento.findAll({
            where: { evento_id: eventoId },  // Filtra os participantes pelo evento_id
            include: [
                {
                    model: User, // Suponha que você tenha um modelo User associado
                    as: 'usuario',
                    attributes: ['id', 'nome', 'sobrenome','caminho_foto']
                }
            ]
        });

        if (participantes.length > 0) {
            res.json(participantes);
        } else {
            res.status(404).json({ error: 'Nenhum participante encontrado para o evento especificado' });
        }
    } catch (error) {
        console.error('Erro ao listar participantes do evento:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao listar participantes do evento' });
    }
};

module.exports = participantesEventosController;
