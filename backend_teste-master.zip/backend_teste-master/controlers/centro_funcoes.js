const Centro = require('../models/centro');
const centroController={}

centroController.list = async(req, res) => {
        try {
            const centros = await Centro.findAll();
            if (centros.length === 0) {
                res.status(404).json({ message: 'Nenhum centro encontrado' });
            } else {
                res.json(centros);
            }
        } catch (error) {
            console.error('Erro ao listar centros:', error);
            res.status(500).json({ error: 'Erro interno do servidor' });
        }
    };

    centroController.create = async (req, res) => {
        const { nome, morada } = req.body
        try {
            const centro = await Centro.create({
                nome:nome,
                morada:morada,
            })
            if(centro) {
                res.status(200).json({
                  success: true,
                  message:"Registado",
                  data: centro
                });
              }
        } catch (error) {
            console.error('Erro ao criar centro:', error);
            res.status(500).json({ error: 'Erro interno do servidor' });
        }
    };
    
    centroController.detail = async (req, res) =>{
        const { id } = req.params;
        try {
            const centro = await Centro.findByPk(id);
            if (centro) {
                res.json(centro);
            } else {
                res.status(404).json({ error: 'Centro não encontrado' });
            }
        } catch (error) {
            console.error('Erro ao obter centro:', error);
            res.status(500).json({ error: 'Erro interno do servidor' });
        }
    };

    centroController.update = async (req, res) =>{
        const { id } = req.params;
        try {
            const [updated] = await Centro.update(req.body, {
                where: { id }
            });
            if (updated) {
                res.json({ message: 'Centro atualizado com sucesso' });
            } else {
                res.status(404).json({ error: 'Centro não encontrado' });
            }
        } catch (error) {
            console.error('Erro ao atualizar centro:', error);
            res.status(500).json({ error: 'Erro interno do servidor' });
        }
    };

    centroController.delete = async (req, res) =>{
        const { id } = req.params;
        try {
            const deleted = await Centro.destroy({
                where: { id }
            });
            if (deleted) {
                res.json({ message: 'Centro deletado com sucesso' });
            } else {
                res.status(404).json({ error: 'Centro não encontrado' });
            }
        } catch (error) {
            console.error('Erro ao deletar centro:', error);
            res.status(500).json({ error: 'Erro interno do servidor' });
        }
    };

    centroController.getCentroById = async (req, res) => {
        const { id } = req.params;
        try {
            const centro = await Centro.findByPk(id);
            if (centro) {
                res.json(centro);
            } else {
                res.status(404).json({ error: 'Centro não encontrado' });
            }
        } catch (error) {
            console.error('Erro ao obter centro:', error);
            res.status(500).json({ error: 'Erro interno do servidor' });
        }
    };


module.exports = centroController;
