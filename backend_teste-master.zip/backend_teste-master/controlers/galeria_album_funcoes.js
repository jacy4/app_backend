const GaleriaAlbum = require('../models/galeria_album');
const Album = require('../models/albuns');
const galeriaAlbumController = {};
const ComentariosGaleriaAlbuns = require('../models/comentarios_albuns');
const LikeComentarioGaleriaAlbum = require('../models/likes_comentarios_albuns');
const DenunciasComentariosGaleriaAlbuns = require('../models/denuncias_comentarios_de_albuns');

// Criar uma nova imagem em um álbum
galeriaAlbumController.create = async (req, res) => {
    const { caminho_imagem, album_id } = req.body;

    try {
        const novaImagem = await GaleriaAlbum.create({
            caminho_imagem,
            album_id
        });
        res.status(201).json({
            message: "Imagem adicionada com sucesso ao álbum",
            data: novaImagem
        });
    } catch (error) {
        console.error('Erro ao criar imagem:', error);
        res.status(500).json({ error: 'Erro ao adicionar imagem ao álbum' });
    }
};

// Criar uma nova partilha com album_id definido igual ao area_id
galeriaAlbumController.createPartilhaAPP = async (req, res) => {
    const {
        titulo,
        descricao,
        caminho_imagem, // Capa ou imagem principal da partilha
        area_id,
        centro_id,
        id_user // ID do usuário que está criando a partilha
    } = req.body;

    try {
        // Definir album_id como igual ao area_id
        const album_id = area_id;

        // Criar a nova partilha (novo registro no álbum)
        const novaPartilha = await GaleriaAlbum.create({
            titulo,
            descricao,
            caminho_imagem,
            area_id,
            centro_id,
            id_user,
            album_id // Definindo album_id como igual ao area_id
        });

        res.status(201).json({
            message: "Partilha criada com sucesso",
            data: novaPartilha
        });
    } catch (error) {
        console.error('Erro ao criar partilha:', error);
        res.status(500).json({ error: 'Erro ao criar a partilha' });
    }
};

galeriaAlbumController.criarVarias = async (req, res) => {
    const { album_id, imagens } = req.body; // Recebe um array de URLs de imagens e o album_id

    try {
        if (!imagens || !Array.isArray(imagens)) {
            return res.status(400).json({ error: 'A lista de imagens é necessária e deve ser um array.' });
        }

        const imagensCriadas = [];

        for (const caminho_imagem of imagens) {
            const novaImagem = await GaleriaAlbum.create({
                caminho_imagem,
                album_id
            });
            imagensCriadas.push(novaImagem);
        }

        res.status(201).json({
            message: "Imagens adicionadas com sucesso ao álbum",
            data: imagensCriadas
        });
    } catch (error) {
        console.error('Erro ao criar imagens:', error);
        res.status(500).json({ error: 'Erro ao adicionar imagens ao álbum' });
    }
};

// Listar todas as imagens de um álbum específico
galeriaAlbumController.listarImagensPorAlbum = async (req, res) => {
    const { album_id } = req.params;

    try {
        const imagens = await GaleriaAlbum.findAll({
            where: { album_id }
        });
        if (imagens.length === 0) {
            res.status(404).json({ message: 'O álbum ainda não tem imagens' });
        } else {
            res.json(imagens);
        }
    } catch (error) {
        console.error('Erro ao listar imagens do álbum:', error);
        res.status(500).json({ error: 'Erro ao buscar imagens do álbum' });
    }
};

// Nova função para listar todas as imagens de um álbum específico
galeriaAlbumController.listarImagensPorAlbumV2 = async (req, res) => {
    const albumId = req.params.album_id;  // Obtém o ID do álbum da URL

    try {
        const imagens = await GaleriaAlbum.findAll({
            where: { album_id: albumId },  // Filtra as imagens pelo album_id
            include: [
                {
                    model: Album,  // Supondo que você tenha um modelo Album associado
                    as: 'album',
                    attributes: ['id', 'nome']  // Apenas o ID e nome do álbum são retornados
                }
            ]
        });

        if (imagens.length > 0) {
            res.json(imagens);
        } else {
            res.status(404).json({ error: 'O álbum ainda não tem imagens' });
        }
    } catch (error) {
        console.error('Erro ao listar imagens do álbum:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao listar imagens do álbum' });
    }
};

// Listar todas as imagens de álbuns de um centro específico
galeriaAlbumController.listarImagensPorCentro = async (req, res) => {
    const { centro_id } = req.params;

    try {
        const albuns = await Album.findAll({
            where: { centro_id },
            include: [{
                model: GaleriaAlbum,
                as: 'imagens'
            }]
        });

        const imagens = albuns.flatMap(album => album.imagens);

        if (imagens.length > 0) {
            res.json(imagens);
        } else {
            res.status(404).json({ message: 'Nenhuma imagem encontrada para os álbuns deste centro.' });
        }
    } catch (error) {
        console.error('Erro ao listar imagens dos álbuns do centro:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

galeriaAlbumController.listarImagensPorCentroAPP = async (req, res) => {
    const { centro_id } = req.params;

    try {
        const imagens = await GaleriaAlbum.findAll({
            where: { centro_id }
        });

        if (imagens.length > 0) {
            res.json(imagens);
        } else {
            res.status(404).json({ message: 'Nenhuma imagem encontrada para este centro.' });
        }
    } catch (error) {
        console.error('Erro ao listar imagens diretamente pelo centro_id:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};


// Deletar uma imagem específica da galeria de um álbum
galeriaAlbumController.delete = async (req, res) => {
    const { id } = req.params;

    try {
        // Buscar todos os comentários associados à imagem na galeria
        const comentarios = await ComentariosGaleriaAlbuns.findAll({ where: { galeria_album_id: id } });

        if (comentarios.length > 0) {
            // Para cada comentário, excluir os likes associados e as denúncias
            for (let comentario of comentarios) {
                await LikeComentarioGaleriaAlbum.destroy({ where: { comentario_galeria_album_id: comentario.id } });
                await DenunciasComentariosGaleriaAlbuns.destroy({ where: { comentario_galeria_album_id: comentario.id } });
            }

            // Excluir todos os comentários associados à imagem na galeria
            await ComentariosGaleriaAlbuns.destroy({ where: { galeria_album_id: id } });
        }

        // Agora, excluir a própria imagem da galeria
        const deleted = await GaleriaAlbum.destroy({ where: { id } });

        if (deleted) {
            res.json({ message: 'Imagem removida com sucesso' });
        } else {
            res.status(404).json({ error: 'Imagem não encontrada' });
        }
    } catch (error) {
        console.error('Erro ao deletar imagem da galeria:', error);
        res.status(500).json({ error: 'Erro interno ao tentar deletar imagem' });
    }
};


// Atualizar dados de uma imagem
galeriaAlbumController.update = async (req, res) => {
    const { id } = req.params;
    const { caminho_imagem } = req.body;

    try {
        const [updated] = await GaleriaAlbum.update({
            caminho_imagem
        }, {
            where: { id }
        });
        if (updated) {
            res.json({ message: 'Imagem atualizada com sucesso' });
        } else {
            res.status(404).json({ error: 'Imagem não encontrada para atualizar' });
        }
    } catch (error) {
        console.error('Erro ao atualizar imagem:', error);
        res.status(500).json({ error: 'Erro interno ao atualizar imagem' });
    }
};

// Remover todas as imagens de um álbum específico
galeriaAlbumController.removerTodasImagensDoAlbum = async (req, res) => {
    const { album_id } = req.params; // ID do álbum

    try {
        const deleted = await GaleriaAlbum.destroy({
            where: { album_id } // Condição para selecionar as imagens do álbum
        });
        if (deleted) {
            res.json({ message: `Todas as imagens do álbum ${album_id} foram removidas com sucesso.` });
        } else {
            res.status(404).json({ error: 'Nenhuma imagem encontrada para esse álbum ou álbum inexistente.' });
        }
    } catch (error) {
        console.error('Erro ao remover imagens do álbum:', error);
        res.status(500).json({ error: 'Erro interno ao tentar remover imagens do álbum' });
    }
};

// Listar todas as imagens de álbuns por centro e autor
galeriaAlbumController.listarImagensPorCentroEAutor = async (req, res) => {
    const { centro_id, autor_id } = req.params;

    try {
        // Consulta 1: Imagens de álbuns de um centro específico
        const albunsCentro = await Album.findAll({
            where: { centro_id },
            include: [{
                model: GaleriaAlbum,
                as: 'imagens'
            }]
        });

        // Consulta 2: Imagens de álbuns criados por um autor específico
        const albunsAutor = await Album.findAll({
            where: { autor_id },
            include: [{
                model: GaleriaAlbum,
                as: 'imagens'
            }]
        });

        // Combinar os resultados das imagens de álbuns por centro e por autor
        const imagensMap = new Map();

        albunsCentro.forEach(album => {
            album.imagens.forEach(imagem => {
                imagensMap.set(imagem.id, {
                    ...imagem.dataValues,
                    album: { id: album.id, nome: album.nome }
                });
            });
        });

        albunsAutor.forEach(album => {
            album.imagens.forEach(imagem => {
                imagensMap.set(imagem.id, {
                    ...imagem.dataValues,
                    album: { id: album.id, nome: album.nome }
                });
            });
        });

        // Converter o map para um array
        const resultadoFinal = Array.from(imagensMap.values());

        // Verifica se há resultados e responde
        if (resultadoFinal.length > 0) {
            res.json(resultadoFinal);
        } else {
            res.status(404).json({ message: 'Nenhuma imagem encontrada para este centro ou autor' });
        }
    } catch (error) {
        console.error('Erro ao listar imagens por centro e autor:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao listar imagens' });
    }
};

galeriaAlbumController.countByArea = async (req, res) => {
    const { areaId } = req.params; // Obtém o ID da área a partir dos parâmetros da requisição
    try {
      // Conta a quantidade de imagens na galeria associadas a álbuns de uma área específica
      const count = await GaleriaAlbum.count({
        include: [{
          model: Album, // Faz o join com a tabela de álbuns
          as: 'album',
          where: {
            area_id: areaId // Filtra os álbuns pela área
          }
        }]
      });
  
      // Retorna a contagem das imagens na galeria
      res.json({ areaId, totalImagens: count });
    } catch (error) {
      console.error('Erro ao contar imagens na galeria por área:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  };

module.exports = galeriaAlbumController;
