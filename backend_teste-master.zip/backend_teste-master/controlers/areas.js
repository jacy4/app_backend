const Area = require('../models/areas');

// Exemplo de um controlador que lista todas as áreas
const areaController = {
    list: async (req, res) => {
        try {
            const areas = await Area.findAll();
            res.json(areas);
        } catch (error) {
            console.error('Erro ao listar áreas:', error);
            res.status(500).json({ error: 'Erro interno do servidor' });
        }
    }
};

module.exports = areaController;
