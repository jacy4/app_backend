const Eventos = require('../models/eventos');
const Topico = require('../models/topicos');
const eventosController = {};
const User = require('../models/user');
const Area = require('../models/areas');
const notificacaoController = require('../controlers/notificacoes_funcoes');
const TipoEvento = require('../models/tipo_de_evento');
const GaleriaEvento = require('../models/galeria_evento');
const ComentariosEventos = require('../models/comentarios_eventos'); 
const ListaParticipantesEvento = require('../models/lista_participantes_evento');
const Participantes = require('../models/lista_participantes_evento');
const TopicosFavoritosUser= require('../models/topicos_favoritos_user');
const LikeComentarioEvento = require('../models/likes_comentarios_eventos'); 
const Foruns = require('../models/forum'); 
const Grupos = require('../models/grupos'); 
const Publicacoes = require('../models/publicacoes'); 
const Centro = require('../models/centro');
const Sequelize = require('sequelize');


// Listar todas as publicações para um determinado centro
eventosController.listAPP = async (req, res) => {
    const { centroId } = req.params;
    try {
        const eventos = await Eventos.findAll({
            where: { centro_id: centroId },
            
            include: [{
                model: Topico,
                as: 'topico',
                attributes: ['id', 'nome'] // Inclui o nome do tópico
            },
            {
                model: User,
                as: 'user',
                attributes: ['id', 'nome', 'sobrenome','caminho_foto']
              },
              {
                model: TipoEvento, // Adicione esta parte
                as: 'tipo_evento',
                attributes: ['id', 'nome_tipo'] // Inclua os atributos que você quer
            },
            {
                model: GaleriaEvento, // Adiciona a galeria de imagens
                as: 'imagens',
                attributes: ['id', 'caminho_imagem'] // Inclui apenas o caminho da imagem
            },
            ]
        });
        if (eventos.length === 0) {
            res.status(404).json({ message: 'Nenhum Evento encontrado' });
        } else {
            res.json(eventos);
        }
    } catch (error) {
        console.error('Erro ao listar eventos:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};










eventosController.list = async (req, res) => {
    const { areaId } = req.params;
    try {
        const eventos = await Eventos.findAll({
            where: {
                area_id: areaId, // Filtra eventos pelo areaId
            },
            include: [{
                model: Topico,
                as: 'topico',
                attributes: ['id', 'nome'] // Inclui o nome do tópico
            },
            {
                model: User,
                as: 'user',
                attributes: ['id', 'nome', 'sobrenome','caminho_foto']
              },
              {
                model: TipoEvento, // Adicione esta parte
                as: 'tipo_evento',
                attributes: ['id', 'nome_tipo'] // Inclua os atributos que você quer
            },
            {
                model: GaleriaEvento, // Adiciona a galeria de imagens
                as: 'imagens',
                attributes: ['id', 'caminho_imagem'] // Inclui apenas o caminho da imagem
            },
            {
                model: Centro, // Adiciona o relacionamento com o modelo de Centros
                as: 'centro',  // Nome do relacionamento definido no belongsTo
                attributes: ['id', 'nome'] // Inclui o nome do centro
            }
            ]
        });
        if (eventos.length === 0) {
            res.status(404).json({ message: 'Nenhum Evento encontrado' });
        } else {
            res.json(eventos);
        }
    } catch (error) {
        console.error('Erro ao listar eventos:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Listar todos os eventos criados por um determinado usuário
eventosController.getEventosPorUsuario = async (req, res) => {
    const { usuarioId } = req.params;
    try {
        const eventos = await Eventos.findAll({
            where: { autor_id: usuarioId },
            include: [
                {
                    model: Topico,
                    as: 'topico',
                    attributes: ['id', 'nome'] 
                },
                {
                    model: User,
                    as: 'user',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto'] 
                },
                {
                    model: Area,
                    as: 'area',
                    attributes: ['id', 'nome'] 
                },
                {
                    model: TipoEvento, // Adicione esta parte
                    as: 'tipo_evento',
                    attributes: ['id', 'nome_tipo'] // Inclua os atributos que você quer
                },
                {
                    model: GaleriaEvento, // Adiciona a galeria de imagens
                    as: 'imagens',
                    attributes: ['caminho_imagem'] // Inclui apenas o caminho da imagem
                }
            ]
        });

        if (eventos.length === 0) {
            res.status(404).json({ message: 'Nenhum Evento encontrado para este usuário' });
        } else {
            res.json(eventos);
        }
    } catch (error) {
        console.error('Erro ao listar eventos por usuário:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};



// Criar um novo evento
eventosController.create = async (req, res) => {
    const {
        nome,
        descricao,
        topico_id,
        datainicioatividade,
        datafimatividade,
        estado,
        centro_id,
        autor_id,
        capa_imagem_evento,
        latitude,
        longitude,
        localizacao,
        area_id,
        tipodeevento_id
    } = req.body;

    try {
      const evento = await Eventos.create({
        nome,
        descricao,
        topico_id,
        datainicioatividade,
        datafimatividade,
        estado,
        centro_id,
        autor_id,
        capa_imagem_evento,
        latitude,
        longitude,
        localizacao,
        area_id,
        tipodeevento_id
      });

      res.status(201).json(evento);
    } catch (error) {
      console.error('Erro ao criar evento:', error);
      res.status(500).json({ error: 'Erro ao criar evento' });
    }
};


// Atualização da visibilidade da publicação
eventosController.updateVisibility = async (req, res) => {
    const { id } = req.params;
    const { visivel } = req.body;
    try {
        const [updated] = await Eventos.update({ visivel }, {
            where: { id }
        });
        if (updated) {
            res.json({ message: 'Visibilidade do evento atualizado com sucesso' });
        } else {
            res.status(404).json({ error: 'Evento não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao atualizar visibilidade do evento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};


// Detalhe do evento
eventosController.detail = async (req, res) => {
    const { id } = req.params;
    try {
        const evento = await Eventos.findByPk(id, {
            include: [
                {
                    model: Topico,
                    as: 'topico',
                    attributes: ['id', 'nome']
                },
                {
                    model: User,
                    as: 'user',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                },
                {
                    model: Area,
                    as: 'area', 
                    attributes: ['id', 'nome'] 
                },
                {
                    model: TipoEvento, // Adicione esta parte
                    as: 'tipo_evento',
                    attributes: ['id', 'nome_tipo'] // Inclua os atributos que você quer
                },
                {
                    model: GaleriaEvento, // Adiciona a galeria de imagens
                    as: 'imagens',
                    attributes: ['caminho_imagem'] // Inclui apenas o caminho da imagem
                }
            ]
        });

        if (evento) {
            res.json(evento);
        } else {
            res.status(404).json({ error: 'Evento não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao obter detalhes do evento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};




eventosController.aprovarEventoPeloAdmin = async (req, res) => {
    const { id } = req.params;
  
    try {
      const evento = await Eventos.findByPk(id);
      if (!evento) {
        return res.status(404).json({ message: 'Evento não encontrado' });
      }
  
      evento.estado = 'Ativa';
      await evento.save();
  
      req.body = {
        usuario_id: evento.autor_id,
        tipo: 'Evento Aprovado',
        mensagem: `O seu Evento "${evento.nome}" foi aprovado!`
      };
  
      const notificacaoAutor = await notificacaoController.create(req);
  
      const topicoFavoritoUsuarios = await User.findAll({
        include: {
          model: Topico,
          as: 'topicos_favoritos',
          where: { id: evento.topico_id },
          through: { attributes: [] }
        }
      });
  
      const notificacoesCriadas = [];
      for (let usuario of topicoFavoritoUsuarios) {
        const reqNotificacao = {
          body: {
            usuario_id: usuario.id,
            tipo: 'Novo Evento no seu Tópico Favorito',
            mensagem: `Um novo evento "${evento.nome}" foi criado no seu tópico favorito!`
          }
        };
        const notificacao = await notificacaoController.create(reqNotificacao);
        notificacoesCriadas.push(notificacao);
      }
  
      res.status(200).json({
        message: 'Evento aprovado com sucesso e notificações enviadas',
        evento: {
          id: evento.id,
          nome: evento.nome,
          estado: evento.estado
        },
        notificacaoAutor: {
          id: notificacaoAutor.id,
          tipo: notificacaoAutor.tipo,
          mensagem: notificacaoAutor.mensagem
        },
        notificacoes: notificacoesCriadas
      });
    } catch (error) {
      console.error('Erro ao aprovar o evento:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  };



eventosController.update = async (req, res) => {
    const { id } = req.params;
    const { imagensRemovidas, ...eventoData } = req.body;

    try {
        // Atualiza o evento com os novos dados
        const [updated] = await Eventos.update(eventoData, {
            where: { id }
        });
        

        if (updated) {
            // Recupera o evento atualizado
            const eventoAtualizado = await Eventos.findByPk(id);

            if (!eventoAtualizado) {
                return res.status(404).json({ error: 'Evento não encontrado após a atualização' });
            }
            // Remove as imagens da galeria que foram excluídas no frontend
            if (imagensRemovidas && imagensRemovidas.length > 0) {
                await GaleriaEvento.destroy({
                    where: {
                        id: imagensRemovidas
                    }
                });
            }

            // Obtém a lista de participantes do evento
            const participantes = await Participantes.findAll({
                where: { evento_id: id }
            });

            // Para armazenar o resultado das notificações
            const notificacoesCriadas = [];

            // Para cada participante, crie uma notificação
            for (let participante of participantes) {
                const reqNotificacao = {
                    body: {
                        usuario_id: participante.usuario_id,
                        tipo: 'Atualização de Evento',
                        mensagem: `O evento "${eventoAtualizado.nome}" no qual se encontra incrito foi atualizado ! `
                    }
                };

                // Chama a função de criação de notificação e armazena a notificação criada
                const notificacao = await notificacaoController.create(reqNotificacao);
                notificacoesCriadas.push(notificacao);
            }

            // Depois que todas as notificações forem criadas, envie uma resposta única
            res.status(200).json({
                message: 'Evento atualizado com sucesso e notificações enviadas',
                evento: eventoAtualizado,
                notificacoes: notificacoesCriadas
            });
        } else {
            res.status(404).json({ error: 'Evento não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao atualizar evento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};



eventosController.delete = async (req, res) => {
    const { id } = req.params;
    try {

         // Buscar todos os comentários associados ao evento
         const comentarios = await ComentariosEventos.findAll({ where: { evento_id: id } });

        if (comentarios.length > 0) {
            // Para cada comentário, excluir os likes associados
            for (let comentario of comentarios) {
                await LikeComentarioEvento.destroy({ where: { comentario_evento_id: comentario.id } });
            }

            // Depois, excluir todos os comentários associados ao evento
            await ComentariosEventos.destroy({ where: { evento_id: id } });
        }
        // Deletar os comentários associados ao evento
        await ComentariosEventos.destroy({
            where: { evento_id: id }
        });

        // Deletar os participantes associados ao evento
        await ListaParticipantesEvento.destroy({
            where: { evento_id: id }
        });

        // Deletar as imagens associadas ao evento na galeria
        await GaleriaEvento.destroy({
            where: { evento_id: id }
        });

        // Agora, deletar o evento
        const deleted = await Eventos.destroy({
            where: { id }
        });

        if (deleted) {
            res.json({ message: 'Evento deletado com sucesso' });
        } else {
            res.status(404).json({ error: 'Evento não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao deletar evento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

eventosController.list_calendar = async (req, res) => {
    try {
        const eventos = await Eventos.findAll(); 

        if (eventos.length === 0) {
            res.status(404).json({ message: 'Nenhum Evento encontrado' });
        } else {
            res.json(eventos); 
        }
    } catch (error) {
        console.error('Erro ao listar todos os eventos:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

eventosController.getModelCounts = async (req, res) => {
    try {
        
      const models = [
        { name: "Eventos", model: Eventos },
        { name: "Tópicos", model: Topico },
        { name: "Users", model: User },
        { name: "Áreas", model: Area },
        { name: "Fóruns", model: Foruns },
        { name: "Grupos", model: Grupos },
        { name: "Publicações", model: Publicacoes }
      ];
  
      const modelNames = [];
      const modelCounts = [];
  
      for (const entry of models) {
        const count = await entry.model.count(); 
        modelNames.push(entry.name); 
        modelCounts.push(count); 
      }
  
      res.json({ labels: modelNames, values: modelCounts });
  
    } catch (error) {
      console.error('Erro ao obter contagem de models:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  };

  eventosController.getMonthlyEventCounts = async (req, res) => {
    try {
      // Obtém todos os eventos com data de início
      const events = await Eventos.findAll({
        attributes: ['dataInicio'],
        where: {
          dataInicio: {
            [Op.not]: null // Garante que apenas eventos com data de início não nula sejam considerados
          }
        }
      });
      // console.log(events)
      // Inicializa o objeto para armazenar eventos por ano e mês
      const eventCounts = {};
  
      // Itera sobre cada evento
      events.forEach(event => {
        const startDate = new Date(event.dataInicio);
        const year = startDate.getFullYear();
        const month = startDate.getMonth(); // Obtém o índice do mês (0-11)
        const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
        const monthName = months[month]
        // Inicializa o ano e mês no objeto se ainda não existirem
        if (!eventCounts[year]) {
          eventCounts[year] = {};
        }
  
        if (!eventCounts[year][monthName]) {
          eventCounts[year][monthName] = 0;
        }
  
        // Incrementa o contador para o mês e ano correspondente
        eventCounts[year][monthName]++;
      });
  
      res.json(eventCounts);
    } catch (error) {
      console.error('Erro ao obter contagem de eventos mensais:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  };


  eventosController.countAll = async (req, res) => {
    const { areaId } = req.params; // Obtém o ID da área a partir dos parâmetros da requisição
    try {
      // Conta o número de eventos onde o 'area_id' é igual ao 'areaId' fornecido
      const count = await Eventos.count({
        where: {
          area_id: areaId
        }
      });
  
      // Retorna a contagem dos eventos
      res.json({ areaId, totalEventos: count });
    } catch (error) {
      console.error('Erro ao contar eventos por área:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  };

  eventosController.countPendingApprovalByArea = async (req, res) => {
    const { areaId } = req.params; // Obtém o ID da área a partir dos parâmetros da requisição
    try {
      // Conta o número de eventos onde o 'area_id' é igual ao 'areaId' fornecido e o estado é 'Por aprovar'
      const count = await Eventos.count({
        where: {
          area_id: areaId,
          estado: 'Por validar' // Filtro para eventos que estão 'Por aprovar'
        }
      });
  
      // Retorna a contagem dos eventos 'Por aprovar'
      res.json({ areaId, totalEventosPorAprovar: count });
    } catch (error) {
      console.error('Erro ao contar eventos por área com estado "Por aprovar":', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  };
  
  eventosController.getEventoComMaisComentariosPorArea = async (req, res) => {
    const { areaId } = req.params; // Obtém o ID da área a partir dos parâmetros da requisição
    try {
      // Faz a contagem de comentários e seleciona o evento com mais comentários
      const eventoComMaisComentarios = await ComentariosEventos.findOne({
        attributes: [
          'evento_id',
          [Sequelize.fn('COUNT', Sequelize.col('comentario_evento.id')), 'totalComentarios']
        ],
        include: [{
          model: Eventos,
          as: 'evento',
          attributes: ['id', 'nome'],
          where: { area_id: areaId }
        }],
        group: ['evento_id', 'evento.id', 'evento.nome'], // Adiciona evento.id ao GROUP BY
        order: [[Sequelize.fn('COUNT', Sequelize.col('comentario_evento.id')), 'DESC']],
        limit: 1 // Limita para obter apenas o evento com mais comentários
      });
  
      if (eventoComMaisComentarios) {
        res.json({
          areaId,
          nomeEvento: eventoComMaisComentarios.evento.nome,
          totalComentarios: eventoComMaisComentarios.dataValues.totalComentarios
        });
      } else {
        res.json({ areaId, message: 'Nenhum comentário encontrado para essa área' });
      }
    } catch (error) {
      console.error('Erro ao buscar evento com mais comentários por área:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  };
  

module.exports = eventosController;
