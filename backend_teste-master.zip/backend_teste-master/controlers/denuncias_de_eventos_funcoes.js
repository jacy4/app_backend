const DenunciasDeEventos = require('../models/denuncias_de_eventos');
const Evento = require('../models/eventos');
const User = require('../models/user');
const denunciasEventosController = {};

// Criar uma denúncia sobre um evento
denunciasEventosController.create = async (req, res) => {
    const { id_evento_denunciado, id_denunciador, motivo_denuncia, descricao_denuncia } = req.body;

    try {
        const denuncia = await DenunciasDeEventos.create({
            id_evento_denunciado,
            id_denunciador,
            motivo_denuncia,
            descricao_denuncia,
            data_denuncia: new Date()
        });

        res.status(201).json({
            message: "Denúncia sobre o evento criada com sucesso",
            denuncia: denuncia
        });
    } catch (error) {
        console.error('Erro ao criar denúncia sobre o evento:', error);
        res.status(500).json({ error: 'Erro ao criar denúncia sobre o evento' });
    }
};

// Listar todas as denúncias de um evento específico
denunciasEventosController.listarDenunciasDeEvento = async (req, res) => {
    const { id_evento_denunciado } = req.params;

    try {
        const denuncias = await DenunciasDeEventos.findAll({
            where: { id_evento_denunciado },
            include: [
                {
                    model: Evento,
                    as: 'evento_denunciado', 
                    attributes: ['id', 'nome', 'descricao']
                },
                {
                    model: User,
                    as: 'denunciador', 
                    attributes: ['id', 'nome', 'sobrenome']
                }
            ]
        });

        if (denuncias.length > 0) {
            res.json(denuncias);
        } else {
            res.status(404).json({ error: 'Nenhuma denúncia encontrada para o evento especificado' });
        }
    } catch (error) {
        console.error('Erro ao listar denúncias do evento:', error);
        res.status(500).json({ error: 'Erro ao buscar denúncias do evento' });
    }
};

// Excluir uma denúncia específica
denunciasEventosController.deleteDenuncia = async (req, res) => {
    const { id } = req.params;

    try {
        const deleted = await DenunciasDeEventos.destroy({ where: { id } });
        if (deleted) {
            res.json({ message: 'Denúncia excluída com sucesso' });
        } else {
            res.status(404).json({ error: 'Denúncia não encontrada para exclusão' });
        }
    } catch (error) {
        console.error('Erro ao deletar denúncia:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Excluir todas as denúncias de um evento específico
denunciasEventosController.deleteAllDenunciasDeEvento = async (req, res) => {
    const { id_evento_denunciado } = req.params;

    try {
        const deleted = await DenunciasDeEventos.destroy({ where: { id_evento_denunciado } });
        if (deleted) {
            res.json({ message: 'Todas as denúncias do evento foram excluídas com sucesso' });
        } else {
            res.status(404).json({ error: 'Nenhuma denúncia encontrada para o evento especificado' });
        }
    } catch (error) {
        console.error('Erro ao deletar denúncias do evento:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

module.exports = denunciasEventosController;
