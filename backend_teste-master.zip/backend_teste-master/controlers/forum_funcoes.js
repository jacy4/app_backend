const Forum = require('../models/forum');
const Area = require('../models/areas');
const MensagemForum = require('../models/mensagem_forum');
const DenunciaMensagemForum = require('../models/denuncias_mensagens_forum'); // Importar o modelo de MensagemForum
const Centro=require('../models/centro');
const forumController = {};

// Criar um novo fórum
forumController.create = async (req, res) => {
  const { area_id, centro_id, nome, estado } = req.body;

  try {
    const novoForum = await Forum.create({
      area_id,
      centro_id,
      nome,
      estado
    });

    res.status(201).json(novoForum);
  } catch (error) {
    console.error('Erro ao criar fórum:', error);
    res.status(500).json({ error: 'Erro ao criar fórum' });
  }
};

// Listar todos os fóruns
forumController.list = async (req, res) => {
  const { areaId } = req.params;
    try {
      const foruns = await Forum.findAll({
        where: {
          area_id: areaId, // Filtra eventos pelo areaId
      },
        include: [{ model: Area, as: 'area', attributes: ['id', 'nome'] }]
      });
  
      res.json(foruns);
    } catch (error) {
      console.error('Erro ao listar fóruns:', error);
      res.status(500).json({ error: 'Erro ao listar fóruns' });
    }
  };
// Listar todos os fóruns por centro_id
// Listar todos os fóruns por centro_id
forumController.listByCentroAPP = async (req, res) => {
  const { centroId } = req.params; // Pega o centro_id dos parâmetros da URL
  try {
    const foruns = await Forum.findAll({
      where: {
        centro_id: centroId, // Filtra fóruns pelo centro_id
      },
      include: [
        { 
          model: Area, 
          as: 'area', 
          attributes: ['id', 'nome'] // Inclui os detalhes da área associada
        },
        {
          model: Centro,
          as: 'centro',
          attributes: ['id', 'nome'] // Inclui os detalhes do centro associado, se necessário
        }
      ]
    });

    res.json(foruns);
  } catch (error) {
    console.error('Erro ao listar fóruns:', error);
    res.status(500).json({ error: 'Erro ao listar fóruns' });
  }
};


  // Obter detalhes de um fórum específico
forumController.detail = async (req, res) => {
    const { id } = req.params;
  
    try {
      const forum = await Forum.findByPk(id, {
        include: [{ model: Area, as: 'area', attributes: ['id', 'nome'] }]
      });
  
      if (forum) {
        res.json(forum);
      } else {
        res.status(404).json({ error: 'Fórum não encontrado' });
      }
    } catch (error) {
      console.error('Erro ao obter detalhes do fórum:', error);
      res.status(500).json({ error: 'Erro ao obter detalhes do fórum' });
    }
  };

  // Atualizar um fórum
forumController.update = async (req, res) => {
    const { id } = req.params;
    const { area_id } = req.body;
  
    try {
      const [updated] = await Forum.update({ area_id }, {
        where: { id }
      });
  
      if (updated) {
        const forumAtualizado = await Forum.findByPk(id);
        res.json(forumAtualizado);
      } else {
        res.status(404).json({ error: 'Fórum não encontrado' });
      }
    } catch (error) {
      console.error('Erro ao atualizar fórum:', error);
      res.status(500).json({ error: 'Erro ao atualizar fórum' });
    }
  };

  // Excluir um fórum
 

  forumController.delete = async (req, res) => {
    const { id } = req.params;

    try {
        // Primeiro, excluir todas as denúncias relacionadas às mensagens do fórum
        await DenunciaMensagemForum.destroy({
            where: {
                forum_id: id
            }
        });

        // Em seguida, excluir todas as mensagens relacionadas ao fórum
        await MensagemForum.destroy({
            where: {
                forum_id: id
            }
        });

        // Por fim, excluir o fórum
        const deleted = await Forum.destroy({
            where: {
                id
            }
        });

        if (deleted) {
            res.json({ message: 'Fórum excluído com sucesso' });
        } else {
            res.status(404).json({ error: 'Fórum não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao excluir fórum:', error);
        res.status(500).json({ error: 'Erro ao excluir fórum' });
    }
};

  
  module.exports = forumController;
  
