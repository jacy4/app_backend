const Publicacao = require('../models/publicacoes');
const Topico = require('../models/topicos');
const publicacaoController = {};
const User = require('../models/user');
const Area = require('../models/areas');
const ComentariosPublicacoes = require('../models/comentarios');
const notificacaoController = require('../controlers/notificacoes_funcoes');
const LikeComentarioPublicacao = require('../models/likes_comentarios_publicacoes');
const Administradores = require('../models/administradores');
const Centro = require('../models/centro');




// const { Area } = require('../models');


// Listar todas as publicações para um determinado centro
publicacaoController.listporcentroAPP = async (req, res) => {
    const { centroId } = req.params;
    console.log(`Recebendo requisição para listar publicações do centroId: ${centroId}`);
    try {
        const publicacoes = await Publicacao.findAll({
            where: { centro_id: centroId },
            include: [{
                model: Topico,
                as: 'topico',
                include: ['area']
            },

            {
                model: Area,
                as: 'area',
                attributes: ['id', 'nome'] // Aqui, você deve listar 'nome' como um atributo, não uma associação
            },
            {
                model: User,
                as: 'autor',
                attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
            }]
        });
        if (publicacoes.length === 0) {
            res.status(404).json({ message: 'Nenhuma publicação encontrada' });
        } else {
            res.json(publicacoes);
        }
    } catch (error) {
        console.error('Erro ao listar publicações:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};




publicacaoController.list = async (req, res) => {
    const { areaId } = req.params;
    try {
        const publicacoes = await Publicacao.findAll({
            where: {
                area_id: areaId, // Filtra eventos pelo areaId
            },
            include: [{
                model: Topico,
                as: 'topico',
                include: ['area']
            },

            {
                model: Area,
                as: 'area',
                attributes: ['id', 'nome'] // Aqui, você deve listar 'nome' como um atributo, não uma associação
            },
            {
                model: User,
                as: 'autor',
                attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
            },
            {
                model: Centro, // Adiciona o relacionamento com o modelo de Centros
                as: 'centro',  // Nome do relacionamento definido no belongsTo
                attributes: ['id', 'nome'] // Inclui o nome do centro
            }
        ]
        });
        if (publicacoes.length === 0) {
            res.status(404).json({ message: 'Nenhuma publicação encontrada' });
        } else {
            res.json(publicacoes);
        }
    } catch (error) {
        console.error('Erro ao listar publicações:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Criar uma nova publicação
publicacaoController.createAPP = async (req, res) => {
    const {
        topico_id,
        titulo,
        descricao,
        horario,
        localizacao,
        paginaweb,
        telemovel,
        email,
        galeria,
        centro_id,
        autor_id,
        area_id
    } = req.body;

    try {
        // Verifica se o autor é administrador
        const isAdmin = await Administradores.findOne({ where: { user_id: autor_id } });

        // Define o estado da publicação com base no resultado da busca
        const estado = isAdmin ? 'Ativa' : 'Por validar';
        // Cria a nova publicação
        const publicacao = await Publicacao.create({
            topico_id,
            titulo,
            descricao,
            horario,
            localizacao,
            paginaweb,
            telemovel,
            email,
            galeria,
            centro_id,
            autor_id,
            area_id,

            estado,
        });

        // Busca todos os usuários que têm o tópico como favorito
        const topicoFavoritoUsuarios = await User.findAll({
            include: {
                model: Topico,
                as: 'topicos_favoritos',
                where: { id: topico_id },
                through: { attributes: [] }
            }
        });

        // Armazena as notificações criadas
        const notificacoesCriadas = [];
        for (let usuario of topicoFavoritoUsuarios) {
            const reqNotificacao = {
                body: {
                    usuario_id: usuario.id,
                    tipo: 'Nova Publicação no seu Tópico Favorito',
                    mensagem: `Uma nova publicação "${titulo}" foi criada no seu tópico favorito!`
                }
            };
            const notificacao = await notificacaoController.create(reqNotificacao);
            notificacoesCriadas.push(notificacao);
        }

        // Envia a resposta com a publicação criada e as notificações enviadas
        res.status(201).json({
            message: 'Publicação criada com sucesso e notificações enviadas',
            publicacao,
            notificacoes: notificacoesCriadas
        });

    } catch (error) {
        console.error('Erro ao criar publicação:', error);
        res.status(500).json({ error: 'Erro ao criar publicação' });
    }
};

// Criar uma nova publicação
publicacaoController.create = async (req, res) => {
    const {
        topico_id,
        titulo,
        descricao,
        horario,
        localizacao,
        paginaweb,
        telemovel,
        email,
        latitude,
        longitude,
        galeria,
        centro_id,
        autor_id,
        area_id
    } = req.body;

    try {
        // Cria a nova publicação
        const publicacao = await Publicacao.create({
            topico_id,
            titulo,
            descricao,
            horario,
            localizacao,
            paginaweb,
            telemovel,
            email,
            latitude,
            longitude,
            galeria,
            centro_id,
            autor_id,
            area_id
        });

        // Busca todos os usuários que têm o tópico como favorito
        const topicoFavoritoUsuarios = await User.findAll({
            include: {
                model: Topico,
                as: 'topicos_favoritos',
                where: { id: topico_id },
                through: { attributes: [] }
            }
        });

        // Armazena as notificações criadas
        const notificacoesCriadas = [];
        for (let usuario of topicoFavoritoUsuarios) {
            const reqNotificacao = {
                body: {
                    usuario_id: usuario.id,
                    tipo: 'Nova Publicação no seu Tópico Favorito',
                    mensagem: `Uma nova publicação "${titulo}" foi criada no seu tópico favorito!`
                }
            };
            const notificacao = await notificacaoController.create(reqNotificacao);
            notificacoesCriadas.push(notificacao);
        }

        // Envia a resposta com a publicação criada e as notificações enviadas
        res.status(201).json({
            message: 'Publicação criada com sucesso e notificações enviadas',
            publicacao,
            notificacoes: notificacoesCriadas
        });

    } catch (error) {
        console.error('Erro ao criar publicação:', error);
        res.status(500).json({ error: 'Erro ao criar publicação' });
    }
};


// Atualização da visibilidade da publicação
publicacaoController.updateVisibility = async (req, res) => {
    const { id } = req.params;
    const { visivel } = req.body;
    try {
        const [updated] = await Publicacao.update({ visivel }, {
            where: { id }
        });
        if (updated) {
            res.json({ message: 'Visibilidade da publicação atualizada com sucesso' });
        } else {
            res.status(404).json({ error: 'Publicação não encontrada' });
        }
    } catch (error) {
        console.error('Erro ao atualizar visibilidade da publicação:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};


// Detalhe da publicação
publicacaoController.detail = async (req, res) => {
    const { id } = req.params;
    try {
        const publicacao = await Publicacao.findByPk(id, {
            include: [{
                model: Topico,
                as: 'topico',
                include: ['area']
            },
            {
                model: Area,
                as: 'area',
                attributes: ['id', 'nome'] // Aqui, você deve listar 'nome' como um atributo, não uma associação
            },
            {
                model: User,
                as: 'autor',
                attributes: ['id', 'nome', 'sobrenome']
            }]
        });
        if (publicacao) {
            res.json(publicacao);
        } else {
            res.status(404).json({ error: 'Publicação não encontrada' });
        }
    } catch (error) {
        console.error('Erro ao obter publicação:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};


// Atualização da publicação
publicacaoController.update = async (req, res) => {
    const { id } = req.params;
    try {
        const [updated] = await Publicacao.update(req.body, {
            where: { id }
        });
        if (updated) {
            res.status(201).json({ message: 'Publicação atualizada com sucesso' });
        } else {
            res.status(404).json({ error: 'Publicação não encontrada' });
        }
    } catch (error) {
        console.error('Erro ao atualizar publicação:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Exclusão da publicação
publicacaoController.delete = async (req, res) => {
    const { id } = req.params;
    try {
        // Primeiro, buscar todos os comentários associados à publicação
        const comentarios = await ComentariosPublicacoes.findAll({ where: { publicacao_id: id } });

        if (comentarios.length > 0) {
            // Para cada comentário, excluir os likes associados
            for (let comentario of comentarios) {
                await LikeComentarioPublicacao.destroy({ where: { comentario_publicacao_id: comentario.id } });
            }

            // Depois, excluir todos os comentários associados à publicação
            await ComentariosPublicacoes.destroy({ where: { publicacao_id: id } });
        };

        // Em seguida, excluir a publicação
        const deleted = await Publicacao.destroy({
            where: { id }
        });

        if (deleted) {
            res.json({ message: 'Publicação deletada com sucesso' });
        } else {
            res.status(404).json({ error: 'Publicação não encontrada' });
        }
    } catch (error) {
        console.error('Erro ao deletar publicação:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

publicacaoController.countByArea = async (req, res) => {
    const { areaId } = req.params; // Obtém o ID da área a partir dos parâmetros da requisição
    try {
      // Conta o número de publicações onde o 'area_id' é igual ao 'areaId' fornecido
      const count = await Publicacao.count({
        where: {
          area_id: areaId
        }
      });
  
      // Retorna a contagem das publicações
      res.json({ areaId, totalPublicacoes: count });
    } catch (error) {
      console.error('Erro ao contar publicações por área:', error);
      res.status(500).json({ error: 'Erro interno do servidor' });
    }
  };


module.exports = publicacaoController;
