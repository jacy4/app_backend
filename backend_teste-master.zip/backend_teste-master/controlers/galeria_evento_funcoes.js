const GaleriaEvento = require('../models/galeria_evento');
const Evento=require('../models/eventos')
const galeriaEventoController = {};

// Criar uma nova imagem em um evento
galeriaEventoController.create = async (req, res) => {
    const { caminho_imagem, evento_id } = req.body;

    try {
        const novaImagem = await GaleriaEvento.create({
            caminho_imagem,
            evento_id
        });
        res.status(201).json({
            message: "Imagem adicionada com sucesso ao evento",
            data: novaImagem
        });
    } catch (error) {
        console.error('Erro ao criar imagem:', error);
        res.status(500).json({ error: 'Erro ao adicionar imagem ao evento' });
    }
};

galeriaEventoController.criarVarias = async (req, res) => {
    const { evento_id, imagens } = req.body; // Recebe um array de URLs de imagens e o evento_id

    try {
        if (!imagens || !Array.isArray(imagens)) {
            return res.status(400).json({ error: 'A lista de imagens é necessária e deve ser um array.' });
        }

        const imagensCriadas = [];

        for (const caminho_imagem of imagens) {
            const novaImagem = await GaleriaEvento.create({
                caminho_imagem,
                evento_id
            });
            imagensCriadas.push(novaImagem);
        }

        res.status(201).json({
            message: "Imagens adicionadas com sucesso ao evento",
            data: imagensCriadas
        });
    } catch (error) {
        console.error('Erro ao criar imagens:', error);
        res.status(500).json({ error: 'Erro ao adicionar imagens ao evento' });
    }
};

// Listar todas as imagens de um evento específico
galeriaEventoController.listarImagensPorEvento = async (req, res) => {
    const { evento_id } = req.params;

    try {
        const imagens = await GaleriaEvento.findAll({
            where: { evento_id }
        });
        if (imagens.length === 0) {
            
            res.status(404).json({ message: 'O evento ainda nao tem imagens' });
        } else {
            // Se houver imagens, envia as imagens como resposta
            res.json(imagens);
        }
    } catch (error) {
        console.error('Erro ao listar imagens do evento:', error);
        res.status(500).json({ error: 'Erro ao buscar imagens do evento' });
    }
};

// Nova função para listar todas as imagens de um evento específico
galeriaEventoController.listarImagensPorEventoV2 = async (req, res) => {
        const eventoId = req.params.evento_id;  // Obtém o ID do evento da URL
    
        try {
            const imagens = await GaleriaEvento.findAll({
                where: { evento_id: eventoId },  // Filtra as imagens pelo evento_id
                include: [
                    {
                        model: Evento,  // Supondo que você tenha um modelo Evento associado
                        as: 'evento',
                        attributes: ['id', 'nome']  // Apenas o ID e nome do evento são retornados
                    }
                ]
            });
    
            if (imagens.length > 0) {
                res.json(imagens);
            } else {
                res.status(404).json({ error: 'O evento ainda não tem imagens' });
            }
        } catch (error) {
            console.error('Erro ao listar imagens do evento:', error);
            res.status(500).json({ error: 'Erro interno do servidor ao listar imagens do evento' });
        }
    };
    

// controllers/galeria_evento_controller.js
galeriaEventoController.listarImagensPorCentro = async (req, res) => {
    const { centro_id } = req.params;

    try {
        const eventos = await Evento.findAll({
            where: { centro_id },
            include: [{
                model: GaleriaEvento,
                as: 'imagens'
            }]
        });

        const imagens = eventos.flatMap(evento => evento.imagens);

        if (imagens.length > 0) {
            res.json(imagens);
        } else {
            res.status(404).json({ message: 'Nenhuma imagem encontrada para os eventos deste centro.' });
        }
    } catch (error) {
        console.error('Erro ao listar imagens dos eventos do centro:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};


// Deletar uma imagem específica
galeriaEventoController.delete = async (req, res) => {
    const { id } = req.params;

    try {
        const deleted = await GaleriaEvento.destroy({
            where: { id }
        });
        if (deleted) {
            res.json({ message: 'Imagem removida com sucesso' });
        } else {
            res.status(404).json({ error: 'Imagem não encontrada' });
        }
    } catch (error) {
        console.error('Erro ao deletar imagem:', error);
        res.status(500).json({ error: 'Erro interno ao tentar deletar imagem' });
    }
};

// Atualizar dados de uma imagem
galeriaEventoController.update = async (req, res) => {
    const { id } = req.params;
    const { caminho_imagem } = req.body;

    try {
        const [updated] = await GaleriaEvento.update({
            caminho_imagem
        }, {
            where: { id }
        });
        if (updated) {
            res.json({ message: 'Imagem atualizada com sucesso' });
        } else {
            res.status(404).json({ error: 'Imagem não encontrada para atualizar' });
        }
    } catch (error) {
        console.error('Erro ao atualizar imagem:', error);
        res.status(500).json({ error: 'Erro interno ao atualizar imagem' });
    }
};

// Remover todas as imagens de um evento específico
galeriaEventoController.removerTodasImagensDoEvento = async (req, res) => {
    const { evento_id } = req.params; // ID do evento

    try {
        const deleted = await GaleriaEvento.destroy({
            where: { evento_id } // Condição para selecionar as imagens do evento
        });
        if (deleted) {
            res.json({ message: `Todas as imagens do evento ${evento_id} foram removidas com sucesso.` });
        } else {
            res.status(404).json({ error: 'Nenhuma imagem encontrada para esse evento ou evento inexistente.' });
        }
    } catch (error) {
        console.error('Erro ao remover imagens do evento:', error);
        res.status(500).json({ error: 'Erro interno ao tentar remover imagens do evento' });
    }
};
// controllers/galeria_evento_controller.js

galeriaEventoController.listarImagensPorCentroEAutor = async (req, res) => {
    const { centro_id, autor_id } = req.params;

    try {
        // Consulta 1: Imagens de eventos de um centro específico
        const eventosCentro = await Evento.findAll({
            where: { centro_id },
            include: [{
                model: GaleriaEvento,
                as: 'imagens'
            }]
        });

        // Consulta 2: Imagens de eventos criados por um autor específico
        const eventosAutor = await Evento.findAll({
            where: { autor_id },
            include: [{
                model: GaleriaEvento,
                as: 'imagens'
            }]
        });

        // Combinar os resultados das imagens de eventos por centro e por autor
        const imagensMap = new Map();

        eventosCentro.forEach(evento => {
            evento.imagens.forEach(imagem => {
                imagensMap.set(imagem.id, {
                    ...imagem.dataValues,
                    evento: { id: evento.id, nome: evento.nome }
                });
            });
        });

        eventosAutor.forEach(evento => {
            evento.imagens.forEach(imagem => {
                imagensMap.set(imagem.id, {
                    ...imagem.dataValues,
                    evento: { id: evento.id, nome: evento.nome }
                });
            });
        });

        // Converter o map para um array
        const resultadoFinal = Array.from(imagensMap.values());

        // Verifica se há resultados e responde
        if (resultadoFinal.length > 0) {
            res.json(resultadoFinal);
        } else {
            res.status(404).json({ message: 'Nenhuma imagem encontrada para este centro ou autor' });
        }
    } catch (error) {
        console.error('Erro ao listar imagens por centro e autor:', error);
        res.status(500).json({ error: 'Erro interno do servidor ao listar imagens' });
    }
};


module.exports = galeriaEventoController;