const Grupo = require('../models/grupos');
const Area = require('../models/areas');
const Topico = require('../models/topicos');
const Evento = require('../models/eventos');
const User = require('../models/user');
const DenunciaGrupo = require('../models/denuncias_grupos'); // Supondo que você tenha um modelo lista_grupo para os membros
const grupoController = {};

// Listar todos os grupos para um determinado centro (ou outro filtro relevante)
grupoController.list = async (req, res) => {
    const { areaId } = req.params;
    try {
        const grupos = await Grupo.findAll({where: {
            area_id: areaId, // Filtra eventos pelo areaId
        },
            include: [
                {
                    model: Area,
                    as: 'area',
                    attributes: ['id', 'nome']
                },
                {
                    model: Topico,
                    as: 'topico',
                    attributes: ['id', 'nome']
                },
                {
                    model: User,
                    as: 'autor',
                    attributes: ['id', 'nome', 'sobrenome', 'caminho_foto']
                },
                {
                  model: Evento,
                  as: 'evento', // Inclui o evento associado
                  attributes: ['id', 'nome']
                }
            ]
        });
        if (grupos.length === 0) {
            res.status(404).json({ message: 'Nenhum grupo encontrado' });
        } else {
            res.json(grupos);
        }
    } catch (error) {
        console.error('Erro ao listar grupos:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Criar um novo grupo
grupoController.create = async (req, res) => {
    const { nome, area_id, topico_id, centro_id, descricao, autor_id, capa, estado, evento_id } = req.body;
    try {
        const grupo = await Grupo.create({
            nome,
            area_id,
            topico_id,
            centro_id,
            descricao,
            autor_id,
            capa,
            estado,
            evento_id
        });

        res.status(201).json(grupo);
    } catch (error) {
        console.error('Erro ao criar grupo:', error);
        res.status(500).json({ error: 'Erro ao criar grupo' });
    }
};

// Atualizar os detalhes de um grupo
grupoController.update = async (req, res) => {
    const { id } = req.params;
    try {
        const [updated] = await Grupo.update(req.body, {
            where: { id }
        });
        if (updated) {
            res.status(201).json({ message: 'Grupo atualizado com sucesso' });
        } else {
            res.status(404).json({ error: 'Grupo não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao atualizar grupo:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Detalhe de um grupo específico
grupoController.detail = async (req, res) => {
    const { id } = req.params;
    try {
        const grupo = await Grupo.findByPk(id, {
            include: [
                {
                    model: Area,
                    as: 'area',
                    attributes: ['id', 'nome']
                },
                {
                    model: Topico,
                    as: 'topico',
                    attributes: ['id', 'nome']
                },
                {
                    model: User,
                    as: 'autor',
                    attributes: ['id', 'nome', 'sobrenome']
                },
            ]
        });
        if (grupo) {
            res.json(grupo);
        } else {
            res.status(404).json({ error: 'Grupo não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao obter grupo:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Exclusão de um grupo
grupoController.delete = async (req, res) => {
    const { id } = req.params;

    try {
        // Primeiro, exclua todas as denúncias relacionadas ao grupo
        await DenunciaGrupo.destroy({
            where: { grupo_id: id }
        });

        // Em seguida, exclua o grupo
        const deleted = await Grupo.destroy({
            where: { id }
        });

        if (deleted) {
            res.json({ message: 'Grupo deletado com sucesso' });
        } else {
            res.status(404).json({ error: 'Grupo não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao deletar grupo:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};
module.exports = grupoController;
