const Administradores = require('../models/administradores');
const adminController = {};
const bcrypt = require('bcrypt');
const User = require('../models/user');
const jwt = require('jsonwebtoken');
const Centro = require('../models/centro');


// Listar todos os administradores
adminController.list = async (req, res) => {
    try {
        const administradores = await Administradores.findAll();
        if (administradores.length === 0) {
            res.status(404).json({ message: 'Nenhum administrador encontrado' });
        } else {
            res.json(administradores);
        }
    } catch (error) {
        console.error('Erro ao listar administradores:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Criar um novo administrador
adminController.create = async (req, res) => {
    const { administrador, email, pass, centro_id, user_id } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(pass, 10);
        
        const admin = await Administradores.create({
            administrador,
            email,
            pass: hashedPassword,
            centro_id,
            user_id
        });
        if (admin) {
            res.status(200).json({
                success: true,
                message: "Administrador registado com sucesso",
                data: admin
            });
        }
    } catch (error) {
        console.error('Erro ao criar administrador:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

adminController.detail = async (req, res) => {
    const { id } = req.params;
    try {
        const admin = await Administradores.findByPk(id, {
            include: [
                {
                    model: Centro,
                    as: 'centro',
                    attributes: ['id', 'nome']  // Ajuste os atributos conforme necessário
                },
                {
                    model: User,
                    as: 'user',
                    attributes: ['id', 'nome', 'sobrenome', 'email', 'sobre_min']  // Ajuste os atributos conforme necessário
                }
            ]
        });

        if (admin) {
            res.json(admin); 
        } else {
            res.status(404).json({ error: 'Administrador não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao obter administrador:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};


// Atualizar um administrador específico
adminController.update = async (req, res) => {
    const { id } = req.params;
    try {
        const [updated] = await Administradores.update(req.body, {
            where: { id }
        });
        if (updated) {
            res.json({ message: 'Administrador atualizado com sucesso' });
        } else {
            res.status(404).json({ error: 'Administrador não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao atualizar administrador:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// Deletar um administrador específico
adminController.delete = async (req, res) => {
    const { id } = req.params;
    try {
        const deleted = await Administradores.destroy({
            where: { id }
        });
        if (deleted) {
            res.json({ message: 'Administrador deletado com sucesso' });
        } else {
            res.status(404).json({ error: 'Administrador não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao deletar administrador:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};

// adminController.login = async (req, res) => {
//     const { email, password } = req.body; // Certifique-se de que está usando "password"
//     try {
//         const admin = await Administradores.findOne({ where: { email } });
//         // console.log('Admin:', admin);  // Verifique se o admin foi encontrado
        
//         if (admin) {
//             // console.log('Password:', password);  // Verifique a senha fornecida
//             // console.log('Hashed Password:', admin.pass);  // Verifique a senha hashada

//             if (!password || !admin.pass) {
//                 res.status(400).json({ error: 'Dados de entrada inválidos' });
//                 return;
//             }

//             const isPasswordValid = await bcrypt.compare(password, admin.pass);
//             // console.log('Password Valid:', isPasswordValid);

//             if (isPasswordValid) {
//                 const user = await User.findByPk(admin.user_id);
//                 // console.log('User:', user);
//                 const token = jwt.sign({ id: user.id, email: user.email }, process.env.ACCESS_TOKEN_SECRET, { expiresIn: '1h' });
//                 res.status(200).json({ 
//                     message: 'Login bem-sucedido',
//                     centro_id: admin.centro_id, 
//                     user_id: user.id,
//                     token: token
//                 });
//             } else {
//                 res.status(401).json({ error: 'Senha incorreta' });
//             }
//         } else {
//             res.status(404).json({ error: 'Administrador não encontrado' });
//         }
//     } catch (error) {
//         console.error('Erro ao fazer login:', error);
//         res.status(500).json({ error: 'Erro interno do servidor' });
//     }
// };

adminController.login = async (req, res) => {
    const { email, password } = req.body;
    try {
        const admin = await Administradores.findOne({ where: { email } });
        if (admin) {
            const isPasswordValid = await bcrypt.compare(password, admin.pass);
            if (isPasswordValid) {
                const user = await User.findByPk(admin.user_id);
                const token = jwt.sign(
                    { id: admin.id, email: admin.email },
                    process.env.ACCESS_TOKEN_SECRET,
                    { expiresIn: '1460h' }
                );
                // console.log('Token gerado:', token); // Log do token gerado
                res.status(200).json({ message: 'Login bem-sucedido', centro_id: admin.centro_id, user_id: user.id, token });
            } else {
                res.status(401).json({ error: 'Senha incorreta' });
            }
        } else {
            res.status(404).json({ error: 'Administrador não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao fazer login:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
};



module.exports = adminController;
