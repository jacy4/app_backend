
const { Sequelize } = require('sequelize');

const flag = process.env.DB_FLAG;
let sequelize;

if (flag === '0') {
  // Conexão com o banco de dados PostgreSQL local
  sequelize = new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASSWORD, {
    host: process.env.DB_HOST,
    dialect: 'postgres',
    port: 5432
  });
} else {
  // Conexão com o banco de dados PostgreSQL no Render
  sequelize = new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASSWORD, {
    host: process.env.DB_HOST,
    dialect: 'postgres',
    dialectOptions: {
      ssl: {
        require: false,
        rejectUnauthorized: false
      }
    }
  });
}

sequelize.authenticate()
  .then(() => {
    // console.log('Conectado ao banco de dados com sucesso.');
  })
  .catch(err => {
    console.error('Erro ao conectar ao banco de dados:', err);
  });

module.exports = sequelize;
